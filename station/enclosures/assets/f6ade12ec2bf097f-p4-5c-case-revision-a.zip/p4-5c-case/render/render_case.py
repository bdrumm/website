"""Render revision A geometry without altering the printable CAD.
Run: /Applications/Blender.app/Contents/MacOS/Blender -b --python render_case.py
"""
from pathlib import Path
import math
import bpy
from mathutils import Vector, Matrix

ROOT = Path(__file__).resolve().parents[1]
OUT = Path(__file__).resolve().parent
bpy.ops.object.select_all(action='SELECT')
bpy.ops.object.delete(use_global=False)
scene=bpy.context.scene
scene.render.engine='CYCLES'
scene.cycles.samples=48
scene.cycles.use_denoising=True
scene.render.resolution_x=1400
scene.render.resolution_y=1000
scene.render.resolution_percentage=100
scene.render.image_settings.file_format='PNG'
scene.world.color=(0.8,0.8,0.8)
scene.view_settings.view_transform='AgX'
scene.view_settings.look='AgX - Medium High Contrast'
scene.render.film_transparent=False

def material(name,col,metallic=0,roughness=.5):
    m=bpy.data.materials.new(name)
    m.diffuse_color=(*col,1)
    m.use_nodes=True
    p=m.node_tree.nodes.get('Principled BSDF')
    p.inputs['Base Color'].default_value=(*col,1)
    p.inputs['Metallic'].default_value=metallic
    p.inputs['Roughness'].default_value=roughness
    return m

shell=material('Warm white printed enclosure',(.66,.68,.66),0,.42)
glassmat=material('Touch glass black border',(.008,.015,.019),.05,.21)
screenmat=material('Muted cyan active screen',(.035,.13,.17),.07,.36)
battmat=material('Battery envelope amber',(.83,.43,.095),.15,.36)
speakerma=material('Speaker envelope charcoal',(.032,.042,.047),0,.5)
camerama=material('Camera carrier amber flex',(.45,.20,.05),.1,.5)
lensma=material('Camera lens',(.006,.014,.02),0,.28)
lensma.node_tree.nodes.get('Principled BSDF').inputs['Specular IOR Level'].default_value=.12
pcbma=material('PCB',(.024,.15,.15),.1,.48)
metalma=material('Metal modules and receptacles',(.31,.38,.42),.6,.3)
floor_mat=material('Backdrop',(.85,.865,.84),0,.8)

def import_stl(name,mat,path=None):
    bpy.ops.wm.stl_import(filepath=str(path or ROOT/'exports'/f'{name}-preview.stl'))
    o=bpy.context.object
    o.name=name
    o.data.materials.append(mat)
    return o

case=import_stl('case',shell)
glass=import_stl('glass',glassmat)
battery=import_stl('battery',battmat)
speaker=import_stl('speaker',speakerma)
camera=import_stl('camera',camerama)
camera.data.materials.append(lensma)
for p in camera.data.polygons:
    if p.center.z>17.0: p.material_index=1
pcb=import_stl('pcb',pcbma)
modules=import_stl('modules',metalma)
pcb.hide_render=True
modules.hide_render=True
vendor=import_stl('Vendor display assembly',pcbma,ROOT/'reference'/'board-preview-only.stl')
vendor.data.materials.append(glassmat)
vendor.data.materials.append(metalma)
for p in vendor.data.polygons:
    z=p.center.z
    if z<5.9:p.material_index=1
    elif z>7.6:p.material_index=2

def cube(name,center,size,mat):
    bpy.ops.mesh.primitive_cube_add(size=1,location=center)
    o=bpy.context.object; o.name=name
    o.dimensions=size
    bpy.ops.object.transform_apply(location=False,rotation=False,scale=True)
    o.data.materials.append(mat)
    return o

active=cube('Active display area',(8.29+110.32/2,4.21+62.28/2,-.035),(110.32,62.28,.045),screenmat)
objects=[case,glass,battery,speaker,camera,active,vendor]
canonical={o.name:o.matrix_world.copy() for o in objects}
# Avoid coincident surfaces between simplified presentation glass and vendor glass.
canonical[glass.name]=Matrix.Translation((0,0,-.012)) @ canonical[glass.name]

# Give true curved STL faces smooth normals, preserving the CAD sharp edges.
for obj in [case,glass,camera,speaker]:
    for p in obj.data.polygons: p.use_smooth=True
    obj.data.set_sharp_from_angle(angle=math.radians(32))
    n=obj.modifiers.new('Weighted corner normals','WEIGHTED_NORMAL')
    n.keep_sharp=True
    n.weight=30

bpy.ops.mesh.primitive_plane_add(size=2000,location=(0,0,-24.3))
floor=bpy.context.object;floor.name='Studio floor';floor.data.materials.append(floor_mat)
lights=[]
for name,location,energy,size in [
    ('Large key',(-120,-100,230),1300000,220),
    ('Soft fill',(200,80,190),900000,180),
    ('Edge light',(10,200,110),550000,150),
]:
    bpy.ops.object.light_add(type='AREA',location=location)
    l=bpy.context.object;l.name=name;l.data.energy=energy;l.data.shape='DISK';l.data.size=size
    l.rotation_euler=(Vector((60,35,0))-l.location).to_track_quat('-Z','Y').to_euler()
    lights.append(l)

bpy.ops.object.camera_add()
cam=bpy.context.object;cam.name='Orthographic camera';scene.camera=cam
cam.data.type='ORTHO';cam.data.lens=50;cam.data.clip_end=3000

flip=Matrix.Translation((0,70.7,0)) @ Matrix.Rotation(math.pi,4,'X')
def pose(front=True):
    for o in objects:
        o.hide_render=False
        o.matrix_world=(flip if front else Matrix.Identity(4)) @ canonical[o.name]

def render(name,pos,target,scale,floor_z):
    floor.location.z=floor_z
    cam.location=pos
    cam.rotation_euler=(Vector(target)-cam.location).to_track_quat('-Z','Y').to_euler()
    cam.data.ortho_scale=scale
    scene.render.filepath=str(OUT/name)
    bpy.ops.render.render(write_still=True)

pose(True)
render('case-front-revision-a.png',(-100,-130,180),(62,35,-8),178,-24.2)
pose(False)
render('case-rear-revision-a.png',(-100,-135,200),(62,35,12),178,-.6)
pose(True)
for o in [glass,active,vendor]:o.hide_render=True
render('case-open-revision-a.png',(-77,-122,235),(62,35,-9),180,-24.2)

# A detached display assembly beside the open cup, shown PCB-side upward.
# Vendor STEP-derived mesh is used only as an appearance reference.
vendor.hide_render=False
vendor.matrix_world=Matrix.Translation((150,0,-11.6)) @ canonical[vendor.name]
render('case-separated-revision-a.png',(-80,-160,330),(140,35,-9),328,-24.2)
bpy.ops.wm.save_as_mainfile(filepath=str(OUT/'revision-a-render.blend'))
