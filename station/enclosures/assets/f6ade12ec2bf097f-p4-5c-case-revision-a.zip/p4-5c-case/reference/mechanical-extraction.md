# Official CAD extraction (2026-09-13)

Sources: downloaded Waveshare board.stp and board.dxf alongside this file. This records nominal vendor geometry, not measurements of the purchased unit. The STEP contains 1,201 solids. Image dimensions are useful for orientation; STEP and DXF control the numerical extraction.

## Coordinate convention

Looking at the **rear** with USB ports on the left and the three buttons at the top: glass lower-left = (0,0), x increases right, y increases upward, z=0 is the front glass surface and +z points toward the rear.

Native STEP coordinate transform:

```
x = native_y + 63.45
y = native_x + 35.35
z = 3 - native_z
```

CadQuery equivalent: `.rotate((0,0,0),(1,1,0),180).translate((63.45,35.35,3))`.

`board-aligned.brep` and `board-aligned.stl` use this frame. `aligned-solid-bounds.json` records every solid's conservative axis-aligned box as `[xmin,ymin,zmin,xmax,ymax,zmax]` and original stable index. Bounding boxes are useful for conservative packing but are not substitutes for intersection testing.

## Nominal major dimensions

| Feature | mm |
|---|---|
| Glass outline | 126.90 x 70.70, corner radius 3.0 |
| Active/view area | 110.32 x 62.28; centered margins x8.29, y4.21 |
| View-area drawing tolerance | ±0.15 (CG VA) |
| PCB outline, nominal | x1.55..120.05; y3.10..67.60 |
| PCB thickness | 1.60 |
| PCB front/back planes | z6.00 / z7.60 |
| Rear mounting face | z11.60 |
| Complete STEP assembly maximum | z12.80, GPIO header |
| Rear mounting points | 112.00 x 57.00 pattern, 4x M2.5 thread (explicit DXF text) |
| Nominal mount centers | (4.80,6.85), (4.80,63.85), (116.80,6.85), (116.80,63.85) |
| Mount outer diameter | 5.50 |
| Mount projection past PCB rear | 4.00 |

The STEP PCB and mounted components have a tiny in-plane rotation (~0.00425 degrees), introducing under 0.009mm differences from rounded nominal board dimensions. The glass remains axis aligned. Actual mount centers in STEP are (4.80020,63.85021), (4.80443,6.85018), (116.80029,63.85850), (116.80451,6.85847). Either a 0.1mm nominal engineering model or the exact transform can be used; print clearance must exceed the discrepancy.

**Depth warning:** the DXF's 11.6mm side dimension is to the mounting faces; the STEP GPIO header reaches 12.8mm. The 13x10x5cm shopping-page package size is not a device outline dimension.

## USB and other protrusions

- Lower USB shell mouth: center y26.36485, z9.26952, mouth x≈0.2296.
- Upper USB shell mouth: center y44.31491, z9.26952, mouth x≈0.2282.
- Each shell mouth's outer cross-section: 8.94 along y x 3.16 along z. These dimensions come from the forward annular shell face, excluding mounting tabs. A case cutout must provide larger clearance and allow the actual cable overmold to reach the sockets.
- Main ESP module: x53.35167..74.75296, y26.60376..44.00535, reaches z10.12.
- GPIO header: x56.10293..107.40332, y4.22140..10.82498, reaches z12.80.
- Battery connector solid: x32.40442..40.10462, y4.12035..9.32058, reaches z10.951.
- Speaker connector solid: x27.86341..33.62370, y61.03553..65.88580, reaches z11.89903.
- Camera FPC connector, combined broad envelope: x91.05205..96.85282, y29.80670..40.91704, reaches z9.62.
- RTC holder/cell assembly at lower-right: x113.668..117.668, y16.473..19.873, reaches z11.00.
- Wi-Fi module shield: x104.09014..114.04099, y44.93936..56.89006, reaches z10.06487. Allow antenna clearance beside this module; no electrical RF keepout has been inferred from mechanical CAD alone.

## Initial exploratory packing checks (not final accessory layout)

These initial component-bounding-box checks were used to explore planar supports above the board. The final layout keeps the battery at x8/y17, moves the provisional speaker to x66/y37, and places the provisional camera at x98/y17. See exports/independent-clearance-notes.md for final clearances. The checks below are retained as initial options, before adding isolation, cable paths and installation clearance.

- Battery at x8..60, y17..53 (52x36) sees max board z10.12. The pack itself is 10mm thick per the user. A shelf over the board therefore needs at least z10.12 plus board-to-shelf clearance and shelf thickness.
- Provisional 40x30 speaker at x77,y12 encounters the RTC holder at z11.00. Moving its x origin to 72 avoids that holder but overlaps the ESP module at z10.12. Actual speaker dimensions must be measured; a shopping-page “50mm” listing may mean cable length or a different speaker enclosure.
- Provisional 16x16 camera at x103,y47 overlaps the upper-right mount, whose rear face is z11.60. Moving it to x94,y46 avoids the mount and encounters the Wi-Fi module around z10.065. Camera dimensions, lens protrusion, flex length and bend space remain unverified.

Mount thread annotation is sufficient for nominal M2.5 design, but physical thread condition, usable engagement depth and suitable screw length should be checked before fastening. Avoid screw tips extending forward past the PCB into the display stack.

## Buttons and microphone geometry

Top-edge actuator faces point toward +y. Centers are x74.3151 RESET, x85.9991 BOOT and x97.6831 POWER, y≈68.094, z8.50. Each visible actuator tip is nominally 2.0 wide in x and 1.0 tall in z; its rounded rectangular planar central region is 1.8x0.8. Allow clearance for finger/tool access and actuator travel.

Microphone packages are centered approximately (16.1086,65.2729) and (16.1129,5.4758), with 2.65x3.50mm footprints and rear caps at z8.58. The vendor STEP mic subcomponent is a **bottom-port** package: modeled acoustic bores point toward the PCB at z7.60, centers (16.10854,65.98288) and (16.11292,4.76577), diameter0.375mm. The top/rear metal cap is solid. This is a component-model observation, not proof that the finished board exposes sound on its rear side. Do not assume that holes directly above the rear metal caps provide a sealed acoustic path. Physical confirmation of the assembled board's port direction and path is required before designing tightly sealed microphone ducts.
