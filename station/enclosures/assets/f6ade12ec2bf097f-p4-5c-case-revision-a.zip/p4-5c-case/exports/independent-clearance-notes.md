# Independent nominal clearance check

Checked 2026-09-13 after the final layout revision: battery x8/y17, speaker x66/y37, camera x98/y17. Validated against the generated `case-measurement-prototype.step` and official vendor geometry in `reference/board-aligned.brep`. Numerical results are in `independent-clearance-checks.json`.

**Result: no nominal plastic/component collisions found.** The case is a valid, single connected solid.

Method: the script extracts the lowest interior plastic directly from the actual case STEP. Component bounding boxes wholly inside the rounded cavity and below that height are proven separate. Every remaining possible board/case collision candidate receives an exact OpenCascade intersection. Exact case/accessory intersections and accessory/accessory intersections all returned zero cubic millimeters. Conservative accessory envelopes are also checked for protrusion beyond the outer case envelope.

| Accessory envelope | Closest conservative board height | Accessory front | Minimum conservative vertical gap |
|---|---:|---:|---:|
| 52x36x10 battery, x8/y17 | 10.120 | 11.700 | 1.580mm |
| Provisional 40x30x6 speaker, x66/y37 | 10.120 | 15.700 | 5.580mm |
| Provisional camera at x98/y17 | 11.000 | 15.700 | 4.700mm |

The battery and speaker checks used full rectangular envelopes; these are conservative relative to rounded corners. Camera geometry used the specified 16x16x1.2 PCB and 10mm diameter lens extending to z23.7. Accessories do not collide with one another or their printed cradles/lands.

The glass has nominal 0.35mm perimeter clearance. Factory rear mounts contact the case seats at z11.6. Rounding the mounting pattern introduces under 0.009mm of positional discrepancy from the official STEP and remains inside the 2.9mm case screw clearance around an M2.5 screw. The GPIO header reaches z12.8 but is clear of all posts, battery and speaker. The display inserts through the open front; its axial insertion motion moves its components away from the fixed rear accessories until the final position, so the checked clearances also support a straight insertion path.

The 2mm screw web means an M2.5x5 screw would nominally engage the factory mount by 3mm, assuming screw length is measured below the head. Actual screw head diameter, usable factory thread depth and fit should be checked. The 5.6mm diameter driver well is approximately 10.4mm deep from the exterior rear surface to the screw bearing plane.

These checks cover nominal rigid solids only. They do not validate the unmeasured speaker/camera, battery lead tabs, mating connector plugs, flex bend radius, cable overmolds, adhesive thickness, acoustic paths, printing tolerances or thermal behavior. The 52x36x10 battery was supplied by the user; the accessory packing remains a measurement prototype.

## Reproduce after changes

From this folder, run `python case.py` and then `python validate_clearances.py` in the CadQuery environment. The validator reads current accessory dimensions and positions from `exports/design-checks.json`, uses paths relative to its own file, and records SHA256 hashes of the checked STEP and parameter JSON. It uses the locally retained `reference/board-aligned.brep` when present; otherwise it aligns the included official `reference/board.stp` directly. The JSON is the authoritative generated check output; update this prose after changing the design.

The strongest conclusion is absence of collisions between the supplied nominal rigid geometry and the generated case, established by exact intersections plus bounding-volume separation proofs. Reported vertical gaps are conservative bounds rather than measured closest-surface distances. This does not increase confidence in unmeasured accessory dimensions or physical assembly tolerances.
