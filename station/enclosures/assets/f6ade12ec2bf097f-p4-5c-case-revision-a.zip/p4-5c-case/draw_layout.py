"""Static dimensioned planning drawing; reads the actual exported parameters."""
from pathlib import Path
import json
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, Rectangle, Circle

ROOT=Path(__file__).resolve().parent
D=json.loads((ROOT/"exports/design-checks.json").read_text())
P=D["parameters"]
colors={"battery":"#edc784","speaker":"#bedacf","camera":"#c9c4e0"}
fig=plt.figure(figsize=(12,9),facecolor="white")
gs=fig.add_gridspec(2,1,height_ratios=[3.2,1.25],hspace=.35)
ax=fig.add_subplot(gs[0])
ax.set_aspect("equal")
ext=P["wall"]+P["perimeter_gap"]
ax.add_patch(FancyBboxPatch((-ext,-ext),*D["case_mm"][:2],
    boxstyle=f"round,pad=0,rounding_size={3+ext}",lw=1.6,fc="#f6f6f4",ec="#343b42"))
ax.add_patch(FancyBboxPatch((0,0),126.9,70.7,
    boxstyle="round,pad=0,rounding_size=3",lw=1,fc="white",ec="#717880"))
ax.add_patch(Rectangle((1.55,3.1),118.5,64.5,fill=False,lw=1,ls="--",ec="#7998aa"))
ax.add_patch(Rectangle((53.35,26.60),21.4,17.4,fc="#ededed",ec="#999",lw=.8))
for name in ("battery","speaker","camera"):
    x,y=P[name+"_xy"]
    w,h,t=P[name]
    ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle="round,pad=0,rounding_size=1.5",
        lw=1.1,fc=colors[name],ec="#59616a"))
    if name=="battery":
        label="BATTERY\n52 × 36 × 10 mm\nUser dimensions"
    elif name=="speaker":
        label="SPEAKER\n40 × 30 × 6 mm*"
    else:
        label="CAMERA*"
        ax.add_patch(Circle((x+w/2,y+h/2),P["lens_diameter"]/2,fc="#726c87",ec="none"))
    ax.text(x+w/2,y+h/2 if name!="camera" else y-3.7,label,
        ha="center",va="center",fontsize=11 if name!="camera" else 9,color="#27303a",linespacing=1.6)
for x in (4.8,116.8):
    for y in (6.85,63.85):
        ax.add_patch(Circle((x,y),4,fc="white",ec="#6e7680",lw=1))
        ax.add_patch(Circle((x,y),1.45,fc="#c4c7ca",ec="#565f68",lw=.6))
        ax.plot([x-1.2,x+1.2],[y,y],color="#565f68",lw=.5)
        ax.plot([x,x],[y-1.2,y+1.2],color="#565f68",lw=.5)
for y,tag in [(26.365,"OTG"),(44.315,"UART")]:
    ax.add_patch(Rectangle((-ext-.2,y-7),2.2,14,fc="white",ec="#447997",lw=1))
    ax.text(-5,y,tag,ha="right",va="center",fontsize=10,color="#447997")
ax.text(31,63.4,"SPK",ha="center",va="center",fontsize=8,color="#576573")
ax.add_patch(Rectangle((27.86,61.04),5.76,4.85,fill=False,ec="#647987",lw=.7))
ax.add_patch(Rectangle((91.05,29.81),5.8,11.11,fill=False,ec="#647987",lw=.7))
ax.text(94,35.4,"CSI",ha="center",va="center",rotation=90,fontsize=8,color="#647987")
ax.annotate("131.2 mm",xy=(-ext,79.5),xytext=(63.45,79.5),ha="center",va="center",fontsize=12,
    arrowprops=dict(arrowstyle="->",lw=.8,color="#424b55"))
ax.annotate("",xy=(126.9+ext,79.5),xytext=(76,79.5),arrowprops=dict(arrowstyle="->",lw=.8,color="#424b55"))
for x in (-ext,126.9+ext):ax.plot([x,x],[73.5,82],color="#8c9298",lw=.7)
ax.annotate("",xy=(135,-ext),xytext=(135,70.7+ext),arrowprops=dict(arrowstyle="<->",lw=.8,color="#424b55"))
ax.text(139,35.35,"75.0 mm",rotation=90,ha="center",va="center",fontsize=12)
ax.text(63.45,-9,"Four M2.5 seats · 112 × 57 mm centers · USB boots assumed 14 × 8 mm",
        ha="center",fontsize=10,color="#444d58")
ax.set_xlim(-15,145);ax.set_ylim(-13,85);ax.axis("off")
ax.set_title("Rear-view packing plan",loc="left",fontsize=16,pad=15,fontweight="medium")

side=fig.add_subplot(gs[1]);side.set_aspect("equal")
side.add_patch(Rectangle((-ext,-.4),131.2,24.4,fc="#f6f6f4",ec="#343b42",lw=1.2))
side.add_patch(Rectangle((-.35,-.4),127.6,22.6,fc="white",ec="none"))
side.add_patch(Rectangle((0,0),126.9,1.3,fc="#344150",ec="none"))
side.add_patch(Rectangle((1.55,6),118.5,1.6,fc="#abc9d9",ec="none"))
side.add_patch(Rectangle((53.35,7.6),21.4,2.52,fc="#bbbbbb",ec="none"))
bx,by=P["battery_xy"];bw,bh,bt=P["battery"]
side.add_patch(Rectangle((bx,D["battery_front_z"]),bw,bt,fc=colors["battery"],ec="#7c6c50",lw=.7))
side.text(bx+bw/2,D["battery_front_z"]+bt/2,"10 mm battery",ha="center",va="center",fontsize=10)
side.text(92,16,"1.8 mm rear wall\n0.5 mm adhesive behind battery",ha="center",va="center",fontsize=9,linespacing=1.7)
side.annotate("",xy=(137,-.4),xytext=(137,24),arrowprops=dict(arrowstyle="<->",lw=.8))
side.text(141,11.8,"24.4 mm",rotation=90,ha="center",va="center",fontsize=12)
side.text(63.45,-5.7,"Battery clears highest overlapped board component by 1.58 mm before added insulation",
          ha="center",fontsize=10,color="#444d58")
side.set_xlim(-15,148);side.set_ylim(-9,28);side.axis("off")
side.set_title("Thickness section · schematic electronics",loc="left",fontsize=13,pad=7)
fig.suptitle("WAVESHARE P4 · 5-INCH CASE / REV A",x=.075,y=.98,ha="left",fontsize=18,fontweight="medium")
fig.text(.075,.925,"MEASUREMENT PROTOTYPE · *Accessory envelopes and cable routing await physical measurements.",
         fontsize=10,color="#725b34")
fig.text(.075,.025,"Board interfaces: official Waveshare STEP/DXF. Case, cradles and clearances: proposed design. Units: mm.",
         fontsize=9,color="#58616b")
fig.subplots_adjust(left=.075,right=.94,top=.87,bottom=.09)
fig.savefig(ROOT/"exports/layout-and-thickness.png",dpi=180)
fig.savefig(ROOT/"exports/layout-and-thickness.svg")
print(ROOT/"exports/layout-and-thickness.png")
