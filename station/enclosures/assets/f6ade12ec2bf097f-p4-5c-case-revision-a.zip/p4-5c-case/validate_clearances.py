"""Validate the generated case against the aligned official Waveshare board.

Run case.py first, then run this script with the same CadQuery environment.
Paths are relative to this file; no firmware or hardware is accessed.

Uses the current exports/design-checks.json accessory parameters and actual
case STEP. Uses the local aligned BREP when available, otherwise aligns the
included official reference/board.stp directly.
"""
from pathlib import Path
import hashlib
import json
import time

import cadquery as cq


HERE = Path(__file__).resolve().parent
OUT = HERE / "exports"
CASE_PATH = OUT / "case-measurement-prototype.step"
BOARD_PATH = HERE / "reference" / "board-aligned.brep"
SOURCE_BOARD_PATH = HERE / "reference" / "board.stp"
PARAM_PATH = OUT / "design-checks.json"

# Stable manufacturer dimensions in the documented rear-view coordinate frame.
GLASS_W, GLASS_H, GLASS_R = 126.9, 70.7, 3.0
VOLUME_EPSILON = 1e-6  # mm³; numerical residue is not a physical overlap.


def box(x, y, z, sx, sy, sz):
    return (cq.Workplane("XY").box(sx, sy, sz, centered=False)
            .translate((x, y, z)).val())


def bounds(shape):
    b = shape.BoundingBox()
    return [b.xmin, b.ymin, b.zmin, b.xmax, b.ymax, b.zmax]


def overlap_xy(a, b):
    return a[0] < b[3] and a[3] > b[0] and a[1] < b[4] and a[4] > b[1]


def intersection_volume(a, b):
    overlap = a.intersect(b)
    return overlap.Volume() if overlap else 0.0


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    started = time.time()
    settings = json.loads(PARAM_PATH.read_text())
    p = settings["parameters"]
    case = cq.importers.importStep(str(CASE_PATH)).val()
    if BOARD_PATH.exists():
        board = cq.Shape.importBrep(str(BOARD_PATH))
        board_source = BOARD_PATH
    elif SOURCE_BOARD_PATH.exists():
        board = (cq.importers.importStep(str(SOURCE_BOARD_PATH)).val()
                 .rotate((0, 0, 0), (1, 1, 0), 180)
                 .translate((63.45, 35.35, 3)))
        board_source = SOURCE_BOARD_PATH
    else:
        raise SystemExit("Missing both reference/board.stp and board-aligned.brep")
    solids = board.Solids()
    board_boxes = [bounds(s) for s in solids]
    floor_z = p["rear_z"] - p["back"]

    report = {
        "frame": "rear view; glass lower-left(0,0), front z=0, rearward +z",
        "case_step_sha256": sha256(CASE_PATH),
        "board_source": str(board_source.relative_to(HERE)),
        "parameters_json_sha256": sha256(PARAM_PATH),
        "layout": {name + "_xy": p[name + "_xy"]
                   for name in ("battery", "speaker", "camera")},
        "case_valid": case.isValid(),
        "case_solids": len(case.Solids()),
        "candidate_intersections": [],
        "accessory_intersections": [],
        "accessory_protrusions": [],
        "clearances": {},
        "confidence": {
            "modeled_rigid_collisions": (
                "Exact OpenCascade intersections for every possible board/case "
                "collision candidate; strict geometric separation proves "
                "remaining board solids clear. Exact accessory/case and "
                "accessory/accessory intersections."
            ),
            "reported_vertical_gaps": (
                "Conservative lower bounds from projected component bounding "
                "boxes. They can underestimate the actual local free space."
            ),
            "physical_fit": (
                "Unverified: real speaker/camera dimensions, leads, mating "
                "plugs, flex bends, adhesive, tolerances, acoustic paths and "
                "thermal behavior are outside these rigid-solid checks."
            ),
        },
    }

    # Determine the lowest interior plastic from the actual case, rather than
    # duplicating post/cradle heights from case.py. Erode the inner XY profile
    # by 0.001mm to exclude coincident faces on the side walls.
    inset_gap = p["perimeter_gap"] - 0.001
    if inset_gap <= -GLASS_R:
        raise ValueError("Invalid perimeter gap for the rounded cavity")
    safe_r = GLASS_R + inset_gap
    safe = (cq.Workplane("XY")
            .box(GLASS_W + 2 * inset_gap, GLASS_H + 2 * inset_gap,
                 p["rear_z"] + p["rim_proud"] + 2, centered=False)
            .translate((-inset_gap, -inset_gap, -p["rim_proud"] - 1))
            .edges("|Z").fillet(safe_r).val())
    interior = case.intersect(safe)
    if not interior.Solids():
        raise ValueError("Could not locate interior case plastic")
    interior_zmin = interior.BoundingBox().zmin
    report["first_interior_plastic_z"] = interior_zmin

    def inside_safe_xy(x, y):
        if not (-inset_gap <= x <= GLASS_W + inset_gap and
                -inset_gap <= y <= GLASS_H + inset_gap):
            return False
        qx = min(max(x, GLASS_R), GLASS_W - GLASS_R)
        qy = min(max(y, GLASS_R), GLASS_H - GLASS_R)
        return (x - qx) ** 2 + (y - qy) ** 2 <= safe_r ** 2

    cleared_by_separation = 0
    lateral_candidates = []
    for i, (solid, b) in enumerate(zip(solids, board_boxes)):
        lateral_inside = all(inside_safe_xy(x, y)
                             for x in (b[0], b[3]) for y in (b[1], b[4]))
        if not lateral_inside:
            lateral_candidates.append(i)
        if lateral_inside and b[5] < interior_zmin - 1e-5:
            cleared_by_separation += 1
            continue
        report["candidate_intersections"].append({
            "solid": i, "bbox": b,
            "volume_mm3": intersection_volume(case, solid),
        })
    report["board_solids_cleared_by_separation"] = cleared_by_separation
    report["lateral_candidates_checked_exactly"] = lateral_candidates

    accessories = {}
    for name, pad_name in (("battery", "battery_rear_pad"),
                           ("speaker", "speaker_gasket")):
        x, y = p[name + "_xy"]
        w, h, thickness = p[name]
        z = floor_z - p[pad_name] - thickness
        # Full rectangles are conservative for the speaker's rounded corners.
        accessories[name] = box(x, y, z, w, h, thickness)
    cx, cy = p["camera_xy"]
    cw, ch, ct = p["camera"]
    cz = p["rear_z"] - p["lens_recess"] - ct
    camera_board = box(cx, cy, cz, cw, ch, p["camera_pcb"])
    lens = (cq.Workplane("XY").center(cx + cw / 2, cy + ch / 2)
            .circle(p["lens_diameter"] / 2)
            .extrude(ct - p["camera_pcb"])
            .translate((0, 0, cz + p["camera_pcb"])).val())
    accessories["camera"] = camera_board.fuse(lens)

    # Collision absence alone would not catch an accessory accidentally moved
    # entirely outside the case. Also require the reference volumes to remain
    # inside the designed outer envelope.
    ext = p["perimeter_gap"] + p["wall"]
    envelope = (cq.Workplane("XY")
                .box(GLASS_W + 2 * ext, GLASS_H + 2 * ext,
                     p["rear_z"] + p["rim_proud"], centered=False)
                .translate((-ext, -ext, -p["rim_proud"]))
                .edges("|Z").fillet(GLASS_R + ext).val())

    for name, accessory in accessories.items():
        outside = accessory.cut(envelope)
        report["accessory_protrusions"].append({
            "accessory": name,
            "volume_outside_case_envelope_mm3": outside.Volume() if outside else 0,
        })
        report["accessory_intersections"].append({
            "a": "case", "b": name,
            "volume_mm3": intersection_volume(case, accessory),
        })
        ab = bounds(accessory)
        projected = []
        for i, (solid, bb) in enumerate(zip(solids, board_boxes)):
            if not overlap_xy(ab, bb):
                continue
            projected.append((bb[5], i))
            if bb[5] > ab[2] and bb[2] < ab[5]:
                report["accessory_intersections"].append({
                    "a": name, "b": "board_solid" + str(i),
                    "volume_mm3": intersection_volume(accessory, solid),
                })
        if projected:
            nearest_z, nearest_i = max(projected)
            report["clearances"][name] = {
                "conservative_board_zmax": nearest_z,
                "nearest_bbox_solid": nearest_i,
                "minimum_front_z": ab[2],
                "conservative_z_gap": ab[2] - nearest_z,
            }
        else:
            report["clearances"][name] = {"board_projection_overlap": False}

    for a, b in (("battery", "speaker"), ("battery", "camera"),
                 ("speaker", "camera")):
        report["accessory_intersections"].append({
            "a": a, "b": b,
            "volume_mm3": intersection_volume(accessories[a], accessories[b]),
        })

    all_intersections = (report["candidate_intersections"] +
                         report["accessory_intersections"])
    report["nonzero_intersections"] = [r for r in all_intersections
                                       if r["volume_mm3"] > VOLUME_EPSILON]
    report["passed"] = (report["case_valid"] and report["case_solids"] == 1
                        and not report["nonzero_intersections"]
                        and all(r["volume_outside_case_envelope_mm3"] <= VOLUME_EPSILON
                                for r in report["accessory_protrusions"]))
    report["elapsed_seconds"] = time.time() - started
    (OUT / "independent-clearance-checks.json").write_text(
        json.dumps(report, indent=2) + "\n")
    print(json.dumps({k: report[k] for k in
                      ("passed", "layout", "clearances", "nonzero_intersections",
                       "board_solids_cleared_by_separation")}, indent=2))
    if not report["passed"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
