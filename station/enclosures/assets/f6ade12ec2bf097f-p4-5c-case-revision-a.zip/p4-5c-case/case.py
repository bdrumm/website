"""Waveshare ESP32-P4-WIFI6-Touch-LCD-5-C compact enclosure, revision A.

MEASUREMENT PROTOTYPE. Speaker, camera, cable boot and adhesive dimensions
are explicit assumptions. Do not commit a final print until they are measured.
Run with Python + requirements.txt. Coordinates: rear view, glass lower-left
(0,0), x right, y up, glass front z=0, rearward +z; all dimensions in mm.
Exports include manufacturing STEP/STL and simplified component volumes.
"""
from pathlib import Path
import json
import cadquery as cq

HERE = Path(__file__).resolve().parent
OUT = HERE / "exports"
OUT.mkdir(exist_ok=True)

# Manufacturer drawing / STEP values. See reference/mechanical-extraction.md.
GLASS = (126.9, 70.7)
GLASS_RADIUS = 3.0
MOUNTS = [(x, y) for x in (4.8, 116.8) for y in (6.85, 63.85)]
MOUNT_Z = 11.6
USB_Y = (26.365, 44.315)
USB_Z = 9.270

# Case choices, adjustable for a calibrated printer and measured accessories.
# User confirmed battery dimensions include casing; speaker wire length = 50 mm.
# Lead exit points and body dimensions still require measurement.
P = dict(
    perimeter_gap=0.35, wall=1.8, back=1.8, rim_proud=0.4, rear_z=24.0,
    screw_clearance=2.9, screw_well=5.6, screw_post=8.0, screw_web=2.0,
    battery=[52.0, 36.0, 10.0], battery_xy=[8.0, 17.0],
    battery_side_gap=0.4, battery_rear_pad=0.5,
    speaker=[40.0, 30.0, 6.0], speaker_xy=[66.0, 37.0],
    speaker_side_gap=0.5, speaker_gasket=0.5,
    camera=[16.0, 16.0, 8.0], camera_xy=[98.0, 17.0],
    camera_pcb=1.2, lens_diameter=10.0, lens_recess=0.3,
    usb_boot_width=14.0, usb_boot_height=8.0,
)

def box(x, y, z, sx, sy, sz):
    return cq.Workplane("XY").box(sx, sy, sz, centered=False).translate((x, y, z))

def rounded_box(x, y, z, sx, sy, sz, radius):
    obj = box(x, y, z, sx, sy, sz)
    return obj.edges("|Z").fillet(radius) if radius else obj

def cyl(x, y, z, d, h):
    return cq.Workplane("XY").center(x, y).circle(d / 2).extrude(h).translate((0, 0, z))

def union_all(items):
    result = items[0]
    for item in items[1:]:
        result = result.union(item)
    return result

def side_open_x(y, z, w, h):
    # Rounded opening for the entire plug boot, all the way to the receptacle.
    return (cq.Workplane("YZ").center(y, z).rect(w, h).extrude(7.0)
            .edges("|X").fillet(1.4).translate((-3.0, 0, 0)))

def rim_cradle(x, y, sx, sy, gap, z, height, thickness=1.0):
    outer = rounded_box(x-gap-thickness, y-gap-thickness, z,
                        sx+2*(gap+thickness), sy+2*(gap+thickness), height, 1.2)
    inner = rounded_box(x-gap, y-gap, z-0.1,
                        sx+2*gap, sy+2*gap, height+0.2, 0.6)
    return outer.cut(inner)

gap, wall = P["perimeter_gap"], P["wall"]
ext = gap + wall
width, height = GLASS[0]+2*ext, GLASS[1]+2*ext
floor_z = P["rear_z"] - P["back"]
front_z = -P["rim_proud"]
depth = P["rear_z"] - front_z

# One rear cup. The complete display inserts through the unobstructed front.
# Its four factory threaded posts rest against these rear supports; the glass
# has a clearance fit and is not clamped between two faces.
outer = rounded_box(-ext, -ext, front_z, width, height, depth,
                    GLASS_RADIUS+ext)
cavity = rounded_box(-gap, -gap, front_z-0.1,
                     GLASS[0]+2*gap, GLASS[1]+2*gap,
                     floor_z-front_z+0.1, GLASS_RADIUS+gap)
case = outer.cut(cavity)

for x, y in MOUNTS:
    post = cyl(x, y, MOUNT_Z, P["screw_post"], P["rear_z"]-MOUNT_Z)
    post = post.cut(cyl(x,y,MOUNT_Z-0.1,P["screw_clearance"],depth))
    post = post.cut(cyl(x,y,MOUNT_Z+P["screw_web"],P["screw_well"],depth))
    case = case.union(post)
    # Continue the head/driver well through the back wall.
    case = case.cut(cyl(x,y,MOUNT_Z+P["screw_web"],P["screw_well"],depth))

for y in USB_Y:
    case = case.cut(side_open_x(y, USB_Z, P["usb_boot_width"], P["usb_boot_height"]))

# Power/boot/reset service access. Nominal XY from manufacturer drawing.
# Power has a wider opening; verify finger/tool reach on the real board.
for x, w, h in [(74.32, 5.5, 4.5), (86.00, 5.5, 4.5), (97.68, 12.0, 6.0)]:
    case = case.cut(box(x-w/2, 66.0, 8.5-h/2, w, 9.0, h))

bx, by = P["battery_xy"]
bw, bh, bt = P["battery"]
battery_z = floor_z - P["battery_rear_pad"] - bt
battery = box(bx, by, battery_z, bw, bh, bt)
cradle = rim_cradle(bx,by,bw,bh,P["battery_side_gap"],floor_z-3.5,3.5)
# Wire/pull-tab exit: no sharp lip across the lead end.
cradle = cradle.cut(box(bx-2.0,by+bh/2-5.0,floor_z-3.6,4.0,10.0,3.8))
case = case.union(cradle)

sx, sy = P["speaker_xy"]
sw, sh, st = P["speaker"]
speaker_z = floor_z - P["speaker_gasket"] - st
speaker = rounded_box(sx,sy,speaker_z,sw,sh,st,1.0)
case = case.union(rim_cradle(sx,sy,sw,sh,P["speaker_side_gap"],floor_z-3.0,3.0))
# Assumes the broad face radiates rearward: measure actual sound outlet first.
for dx in range(-12, 13, 3):
    vent = rounded_box(sx+sw/2+dx-0.8, sy+sh/2-10.0, floor_z-0.1,
                       1.6,20.0,P["back"]+0.2,0.7)
    case = case.cut(vent)

cx, cy = P["camera_xy"]
cw, ch, ct = P["camera"]
camera_z = P["rear_z"] - P["lens_recess"] - ct
lens_x, lens_y = cx+cw/2, cy+ch/2
camera_board = box(cx,cy,camera_z,cw,ch,P["camera_pcb"])
lens = cyl(lens_x,lens_y,camera_z+P["camera_pcb"],P["lens_diameter"],ct-P["camera_pcb"])
camera = camera_board.union(lens)
# Four small adhesive lands support the rigid camera section around the lens.
# A 0.3mm removable adhesive pad sits between each land and camera PCB rear.
land_z = camera_z + P["camera_pcb"] + 0.3
for dx in (0.3, cw-3.1):
    for dy in (0.3, ch-3.1):
        case = case.union(box(cx+dx,cy+dy,land_z,2.8,2.8,floor_z-land_z))
case = case.cut(cyl(lens_x,lens_y,floor_z-0.2,P["lens_diameter"]+2.0,P["back"]+0.4))
# Outward flare keeps the short recessed opening clear around the lens.
flare = cq.Solid.makeCone((P["lens_diameter"]+2)/2,(P["lens_diameter"]+4)/2,
                          1.0,cq.Vector(lens_x,lens_y,P["rear_z"]-1.0))
case = case.cut(flare)

# Small rear ventilation field away from the battery and speaker chamber.
for x in (67.0, 70.0, 73.0, 76.0, 79.0):
    case = case.cut(rounded_box(x,15.0,floor_z-0.1,1.2,8.0,P["back"]+0.2,0.5))

# STEP models bottom-port MEMS mics through the PCB, not rear-facing ports.
# Preserve short-edge air access around both mic regions; do not seal ducts
# against the solid rear caps. The actual acoustic path needs a hardware check.
case = case.cut(box(13.0,-3.0,4.8,6.2,7.0,3.0))
case = case.cut(box(13.0,67.0,4.8,6.2,8.0,3.0))

# Reference volumes only, not manufacturing parts.
glass = rounded_box(0,0,0,*GLASS,1.3,GLASS_RADIUS)
pcb = box(1.55,3.10,6.0,118.5,64.5,1.6)
for x, y in MOUNTS:
    pcb = pcb.cut(cyl(x,y,5.9,2.8,2.0))
modules = union_all([
    box(53.0,25.0,7.6,26.0,18.5,2.52),
    box(103.0,44.0,7.6,16.0,13.7,2.465),
    box(55.7,5.0,7.6,52.0,5.1,5.2),
    box(91.05,29.81,7.6,5.8,11.11,2.02),
])

# Rear-face-down print orientation: underside flat on z=0, cup opens upward.
def print_pose(obj):
    return obj.rotate((0,0,0),(1,0,0),180).translate((ext,GLASS[1]+ext,P["rear_z"]))

objects = dict(case=case,battery=battery,speaker=speaker,camera=camera,
               glass=glass,pcb=pcb,modules=modules)
checks = {"status": "MEASUREMENT PROTOTYPE — not fit approved", "parameters": P,
          "case_mm": [width,height,depth], "board_mount_pattern_mm": [112,57],
          "battery_front_z":battery_z,"speaker_front_z":speaker_z,
          "camera_front_z":camera_z,"valid_solids":{}}
for name, obj in objects.items():
    shape = obj.val()
    checks["valid_solids"][name] = bool(shape.isValid())
    if not shape.isValid():
        raise ValueError(f"Invalid CAD solid: {name}")
    cq.exporters.export(obj, str(OUT / f"{name}-preview.stl"), tolerance=0.06, angularTolerance=0.15)

if len(case.solids().vals()) != 1:
    raise ValueError("Case must be one connected solid")
for a,b in [("battery","speaker"),("battery","camera"),("speaker","camera")]:
    overlap=objects[a].intersect(objects[b]).val().Volume()
    if overlap>1e-5:
        raise ValueError(f"Accessory overlap: {a}, {b}: {overlap}")

cq.exporters.export(case,str(OUT/"case-measurement-prototype.step"))
cq.exporters.export(print_pose(case),str(OUT/"case-measurement-prototype.stl"),tolerance=0.04,angularTolerance=0.1)

# Low-material first prints, exported as separate pieces on their own z=0.
# The USB strip checks cable-boot cross-sections; the full cup is still needed
# to verify insertion depth relative to the mounted board.
usb_coupon = case.intersect(box(-3,15,4.0,5.0,41.0,10.0))
def normalize(obj):
    bb=obj.val().BoundingBox()
    return obj.translate((-bb.xmin,-bb.ymin,-bb.zmin))
usb_coupon = normalize(usb_coupon.rotate((0,0,0),(0,1,0),90))
cq.exporters.export(usb_coupon,str(OUT/"usb-clearance-coupon.stl"),tolerance=0.04)
rim_coupon = normalize(case.intersect(box(-3,-3,-0.5,width+2,height+2,1.7)))
cq.exporters.export(rim_coupon,str(OUT/"glass-fit-ring.stl"),tolerance=0.04)
template = union_all([cyl(x,y,0,7.0,1.6) for x,y in MOUNTS] + [
    box(4.8,y-1.0,0,112.0,2.0,1.6) for y in (6.85,63.85)] + [
    box(x-1.0,6.85,0,2.0,57.0,1.6) for x in (4.8,116.8)])
for x,y in MOUNTS:
    template = template.cut(cyl(x,y,-0.1,P["screw_clearance"],2.0))
cq.exporters.export(normalize(template),str(OUT/"mount-pattern-template.stl"),tolerance=0.04)

checks["case_volume_cm3"]=round(case.val().Volume()/1000,2)
checks["case_connected_solids"]=len(case.solids().vals())
(OUT/"design-checks.json").write_text(json.dumps(checks,indent=2)+"\n")
print(json.dumps(checks,indent=2))
