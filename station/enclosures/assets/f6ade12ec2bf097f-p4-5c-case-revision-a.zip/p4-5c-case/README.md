# Compact case for Waveshare ESP32-P4-WIFI6-Touch-LCD-5-C

**Revision A — measurement prototype, 2026-09-13.** The board interfaces are
based on official mechanical CAD. The user's battery is 52 × 36 × 10 mm.
The user confirmed that the battery dimensions include its casing and the
speaker wire is 50 mm long. Speaker, camera and USB cable-body dimensions still need physical
confirmation. The enclosed STL is a review/fit prototype, not a fit-approved
production print. No firmware or hardware was changed.

## Proposed design

One open-front rear cup, **131.2 × 75.0 × 24.4 mm** overall. The existing
glass supplies the black front bezel, so a second printed bezel is unnecessary.
The case rim stands 0.4 mm above the glass; the complete glass outline is
exposed, including the full active screen. Rounded corners follow the glass.

The complete display/PCB assembly enters through the front. Four recessed
M2.5 screws enter from the back and engage the factory threaded mounting
posts. Printed seats contact those posts; the case does not clamp the glass.
There is 0.35 mm nominal clearance around each glass edge, 1.8 mm side walls,
and a 1.8 mm rear wall. The four screw heads are accessible through 5.6 mm
driver wells; their nominal mounting pattern is 112 × 57 mm.

Battery, speaker and camera occupy separate footprints in one rear layer.
The battery is beside the tall GPIO header, allowing its lower face to sit
at z11.7 instead of above the header's z12.8 plus clearance. This avoids
approximately 2.7 mm of otherwise unnecessary thickness. This is a practical
starting thickness, not a proven global minimum.

- Battery: left-middle, 52 × 36 × 10 mm. Shallow smooth cradle, 0.4 mm side
  clearance and 0.5 mm **removable adhesive retention** behind the pack. The
  cradle alone does not retain the battery along its thickness. Leave the
  adhesive pull tab accessible. Reserve the remaining front gap for insulation,
  pack tolerance and installation; do not use a screw or rigid clamp across it.
- Speaker: upper-right, **assumed 40 × 30 × 6 mm**. Perimeter adhesive foam
  gasket holds it to the back and directs sound through nine grille slots.
  The gasket must not cover the outlet. This assumes its broad face emits
  toward the rear. Location is closer to the speaker header than the initial
  lower-right arrangement; shortest header-to-body-edge distance is about
  35 mm before connector geometry, wire exit and service slack. The user
  confirmed a 50 mm lead; the remaining approximately 15 mm is not proof of
  reach because the actual exit point and routed path are still unknown.
- Camera: lower-right near the CSI connector, **assumed 16 × 16 × 8 mm**
  rigid/lens envelope and 10 mm lens diameter. Rear aperture is 12 mm with
  a flare to 14 mm; nominal lens tip is recessed 0.3 mm. Four small adhesive
  lands support the rigid section. Flexible ribbon geometry is not modeled;
  final aperture position depends on its usable length and permitted bends.
- USB: two direct openings on the left short edge, **assumed 14 × 8 mm cable
  boot envelopes**, centered on the actual ports 17.95 mm apart. Openings
  pass through the wall to the sockets. Both cable bodies must be checked
  together for full insertion; receptacle dimensions alone are insufficient.
- Power, boot and reset have top-edge service openings. Power opening is
  wider, but finger access versus tool access remains to be tried on hardware.
  MicroSD remains accessible with the display lifted out.
- Short-edge vents preserve air access near the two microphones. The vendor
  microphone model has bottom-facing acoustic ports through the PCB; these
  vents are provisional. No sealed duct is placed against its solid rear cap.
  A small rear ventilation field occupies the gap between accessories.

The antenna area contains no battery pouch or speaker body directly over its
outer end in this proposed arrangement. Exact RF clearance and the nearby
camera/ribbon route still require checking against the actual assembly.

## What is verified

Manufacturer drawings give a 126.9 × 70.7 mm glass outline (R3 corners),
110.32 × 62.28 mm active area, and four M2.5 mounts. The CAD also establishes
the PCB's asymmetric position behind the glass, port heights, button locations
and mounting-seat depth. The shopping-page **13 × 10 × 5 cm package size**
was not used as a board measurement.

The final case is one valid connected CAD solid. Independent checks against
the manufacturer's aligned board geometry found no nominal plastic/board
or plastic/accessory intersections, and no accessory overlaps. Conservative
minimum gaps between modeled rigid accessories and board components are:

| Accessory | Gap toward PCB components |
|---|---:|
| Battery | 1.58 mm |
| Assumed speaker | 5.58 mm |
| Assumed camera | 4.70 mm |

The checks cover the vendor's rigid geometry and the stated accessory
assumptions. They exclude cable boots, mating plugs, lead tabs, ribbon bends,
adhesive tolerances, acoustic performance, battery expansion and thermal/RF
performance. The battery partially overlaps the processor footprint; its
temperature during operation and charging must be evaluated before accepting
this compact layout. A need for more thermal separation changes the thickness
or accessory arrangement.

## Measurements needed to finish

1. **Speaker:** body length × width × maximum thickness, including lips;
   actual sound outlet face and wire exit. The user confirmed the wire is
   50 mm long; this is not the speaker body size.
2. **Camera:** rigid section length × width, full rear height through the
   lens, lens diameter and position relative to its edges; free flex length
   measured from the fully seated connector to the rigid camera section.
   A rear/side photo would help confirm the allowed route and outlet direction.
3. **USB cables:** width × thickness of each molded plug housing, and any
   shoulder that prevents it entering the opening. Try both simultaneously.
4. **Battery:** the user confirmed 52 × 36 × 10 mm includes the casing.
   Identify lead exit edge and lead length. The current cradle relief is left-middle
   and must move if the real leads exit elsewhere.
5. **Mounts and microphones:** confirm the supplied board matches the drawing;
   check usable M2.5 thread depth and identify the actual mic acoustic path.
   Hole positions do not need to be re-measured unless the fit template fails.

## Files and first prints

| File | Purpose |
|---|---|
| `case.py` | Editable parametric CadQuery source; dimensions and assumptions at top |
| `requirements.txt` | CAD environment dependencies |
| `validate_clearances.py` | Repeat independent rigid-geometry checks after regeneration |
| `exports/case-measurement-prototype.step` | Solid CAD model, original engineering coordinates |
| `exports/case-measurement-prototype.stl` | One-piece cup, rear face down, already placed on z=0 |
| `exports/glass-fit-ring.stl` | Low-material check of glass perimeter and corner fit |
| `exports/mount-pattern-template.stl` | Low-material check of the four mounting centers |
| `exports/usb-clearance-coupon.stl` | Flat 1.8 mm strip checking both cable cross-sections |
| `exports/design-checks.json` | Dimensions and model-validity results |
| `exports/independent-clearance-notes.md` | Independent final geometry check and limits |
| `exports/independent-clearance-checks.json` | Detailed checks, final STEP hash and gaps |
| `exports/mesh-checks.json` | All four print meshes are watertight, connected and placed on z=0 |
| `reference/mechanical-extraction.md` | Exact vendor geometry extraction and provenance |

Print the ring, mounting template and USB strip first. The strip tests boot
cross-sections; final insertion depth still requires the complete case with
the board installed. STL units are millimeters. Do not scale the STL to fit.

Provisional FDM starting settings: PETG, 0.4 mm nozzle, 0.2 mm layers, four
perimeters and five bottom layers. Print the cup rear-face down, opening up.
Inspect the slicer for USB/button opening roofs; use local support if your
printer cannot bridge them. Keep supports out of screw wells and accessory
cradles where possible. Remove any sharp edges near the battery and flex.
These settings have not been physically printed or calibrated on your printer.

Nominal fasteners: **four M2.5 × 5 mm pan/button-head screws**, head diameter
under 5.6 mm. With the 2 mm printed web this gives approximately 3 mm thread
engagement. Check actual thread depth and head/driver fit; a longer screw may
bottom against the PCB/display stack. Do not force a screw to pull a gap closed.

Assembly order: trial-fit the empty shell; install camera, speaker and battery
with removable adhesive; route and connect their leads with sufficient slack;
lower the intact display/PCB through the front; check that no wire is trapped;
engage the four rear screws. For servicing, support the lifted display before
disconnecting the short ribbon or leads. Final battery installation follows
successful rigid fit and cable checks.

Regenerate with Python 3.12 and the dependencies in `requirements.txt`:

```sh
python3 -m venv /tmp/p4-case-env
/tmp/p4-case-env/bin/python -m pip install -r requirements.txt
/tmp/p4-case-env/bin/python case.py
/tmp/p4-case-env/bin/python validate_clearances.py
```

Rerun the independent geometric checks after changing the layout; old results
are tied to the SHA256 recorded in the independent JSON.

## Sources

- [Waveshare board documentation](https://docs.waveshare.com/ESP32-P4-WIFI6-Touch-LCD-5)
- [Official mechanical files: STEP, DXF and PDF](https://github.com/waveshareteam/ESP32-P4-WIFI6-Touch-LCD-5/tree/main/hardware/mechanical)
- [Manufacturer dimensional image](https://docs.waveshare.com/assets/images/ESP32-P4-WIFI6-Touch-LCD-5-details-size-592c28b7d56e8d4d2858da3a529e2642.webp)
- [Official product and bundle contents](https://www.waveshare.com/product/iot-communication/short-range-wireless/esp32-p4-wifi6-touch-lcd-5.htm)

Reference downloads: `ESP32-P4-WIFI6-Touch-LCD-5_3d-20260812.stp` and
`ESP32-P4-WIFI6-Touch-LCD-5-dimensions-20260408.dxf`, retrieved 2026-09-13.
The local `.brep` and aligned STL preserve vendor geometry. The smaller
`board-preview-only.stl` is decimated for illustration and must not be used
for dimensional measurements. Vendor references are technical evidence,
not instructions to operate hardware or modify the project.
