"""Measured 4.3-inch battery wall (K43) and batteryless switch (L43) pairs.

The mounting spring and hook sections retain the reinforced I/S3 physical
dimensions. Only their placement and surrounding enclosure change.
"""
from pathlib import Path
import argparse, json, math
from types import SimpleNamespace
import cadquery as cq
from OCP.BRepBndLib import BRepBndLib
from OCP.Bnd import Bnd_Box
import case_geometry as base
import mount_geometry as mount
from outer_finish import finish_outer

ROOT=Path(__file__).resolve().parent
V=cq.Vector
box=base.box; rounded=base.rounded_box
W,H=base.GLASS[1],base.GLASS[0]
R=16.0

def portrait(obj): return obj.rotate((0,0,0),(0,0,1),90).translate((W,0,0))
def canonical(obj): return obj.translate((-W,0,0)).rotate((0,0,0),(0,0,1),-90)
def bounds(obj):
    b=Bnd_Box(); BRepBndLib.AddOptimal_s(obj.val().wrapped,b,False,False)
    return b.Get()
def dims(obj):
    b=bounds(obj); return [round(b[i+3]-b[i],4) for i in range(3)]
def volume(a,b): return max(0.,a.val().intersect(b.val()).Volume())
def print_pose(obj):
    p=obj.rotate((0,0,0),(1,0,0),180); b=bounds(p)
    return p.translate((-b[0],-b[1],-b[2]))

def configuration(kind):
    battery=kind=='battery'
    g=SimpleNamespace(R=R,GLASS=base.GLASS,base=base,box=box,rounded=rounded,
        portrait=portrait,canonical=canonical,union_all=base.union_all,dims=dims,
        SWITCH_BAY=9.2 if battery else 7.5,HOLDER_BOTTOM=-1.15 if battery else -15.15,
        RELEASE_SIDE='right' if battery else 'left',PLATE_CENTRE=H/2 if battery else H/2-7,
        STANDOFF_POSITIONS=(58,105),LATCH_ANCHOR_BOTTOM=6. if battery else 15.5,
        MOUNT_HEAD_RECESS=1.2,
        RECEIVERS=[(20.,6.),(45.,6.),(W/2,H-1.9)] if battery else [(10.,18.),(W-10.,18.),(W/2,H-1.9)])
    if battery:
        g.POD_RELIEF=(-1.3,13.4,R-.1,4.2,45.5,24.85-R+.1)
        g.LATCH_ANCHOR_WIDTH=10.3
    mount.install(g)
    p=dict(base.P,revision='K43' if battery else 'L43',rear_z=R,
        battery_enabled=battery,camera_enabled=False,dock_enabled=False,
        battery=[36.,52.,10.],battery_xy=[16.,12.9],battery_rear_z=24.5 if battery else R,
        battery_rotated_90_degrees=True,
        speaker=[26.,26.,5.],speaker_xy=[59.,31.],
        speaker_rear_z=18.5 if battery else 17.2,
        speaker_dimensions_confirmed=True,speaker_leaf_root_outset=2.,
        speaker_fixed_lip_offsets=[12.,20.],usb_coupon_enabled=False,
        design_update='2026-09-14: actual 4.3-inch board, measured glass/depth and speaker')
    return g,p

def modify_case(case,g,p,kind):
    if kind=='battery':
        floor=R-p['back'];top=p['battery_rear_z']
        wire=rounded(10.2,28.5,floor,6.3,8,top-floor,1.4).faces('>Z').edges().fillet(.35)
        case=case.union(wire).cut(rounded(11.8,30.1,11.1,5,4.8,top-p['back']-11.1,.6))
        bx,by=p['battery_xy'];bw,bh,_=p['battery'];gap=p['battery_side_gap']
        case=case.cut(rounded(bx-gap,by-gap,floor-.1,bw+2*gap,bh+2*gap,top-p['back']-floor+.1,.6))
    else:
        # Lower chin and rear entry permit the already-connected display to dock.
        chin=rounded(-16.15,-2.15,-.4,H+18.3,W+4.3,R+.4,4.65)
        chin,_=finish_outer(chin,.6,.15,wall_mm=1.8)
        chin=chin.cut(rounded(-14.35,-.35,1.4,H+14.7,W+.7,R+1,2.85))
        chin=chin.cut(rounded(-.35,-.35,-.5,H+.7,W+.7,R+1,2.85))
        case=case.union(chin.intersect(box(-20,-5,-1,28,W+10,R+2)))
        for y in base.USB_Y:
            case=case.cut(rounded(-3.5,y-8,5.,11.5,16,R-4.9,1.))
        case=case.cut(rounded(22.,14.,R-1.7,32.,39.,2.,2.))
        # Broad entry ends before the lower post seats. Separate port corridors
        # continue inward while leaving their washer and driver paths intact.
        case=case.cut(canonical(rounded(10.5,-3.5,2.,44.,6.3,R-1.9,1.)))
    adds,cuts=g.receiver_parts()
    return case.union(adds).cut(cuts)

def bottom_plug(y):
    boot=rounded(-21.95,y-6,base.USB_Z-3.5,18,12,7,1.)
    # Exposed plug portion ends just outside the nominal socket mouth (2.05).
    # Internal mated shell/contact geometry is outside this boot-clearance model.
    metal=box(-3.95,y-4.2,base.USB_Z-1.3,5.99,8.4,2.6)
    return portrait(boot.union(metal))

def bent_cable(y):
    u=W-y;direction=1 if u>W/2 else -1
    original=portrait(rounded(-10.45,y-6.5,6,11.7,13,15,1))
    elbow=original.rotate((u,0,base.USB_Z),(u,1,base.USB_Z),direction*90)
    metal=portrait(box(1.25,y-4.2,base.USB_Z-1.3,.79,8.4,2.6))
    elbow=elbow.union(metal)
    a=V(u+direction*(21-base.USB_Z),-4.95,base.USB_Z)
    b=V(a.x+direction*6,a.y,a.z+6)
    edges=[cq.Edge.makeThreePointArc(a,V(a.x+direction*6*math.sin(math.pi/4),a.y,a.z+6*(1-math.cos(math.pi/4))),b)]
    c=V(b.x,b.y+6,b.z+6)
    edges.append(cq.Edge.makeThreePointArc(b,V(b.x,b.y+6*(1-math.cos(math.pi/4)),b.z+6*math.sin(math.pi/4)),c))
    d=V(c.x-direction*6,c.y+6,c.z)
    edges.append(cq.Edge.makeThreePointArc(c,V(c.x-direction*6*(1-math.cos(math.pi/4)),c.y+6*math.sin(math.pi/4),c.z),d))
    e=V(u+direction*6,d.y,c.z)
    edges.append(cq.Edge.makeLine(d,e))
    f=V(u,e.y+6,c.z)
    edges.append(cq.Edge.makeThreePointArc(e,V(u+direction*6*(1-math.sin(math.pi/4)),e.y+6*(1-math.cos(math.pi/4)),c.z),f))
    h=V(u,35,c.z);j=V(u,41,c.z+6)
    edges += [cq.Edge.makeLine(f,h),cq.Edge.makeThreePointArc(h,V(u,35+6*math.sin(math.pi/4),c.z+6*(1-math.cos(math.pi/4))),j)]
    path=cq.Wire.assembleEdges(edges)
    lead=cq.Workplane(cq.Plane(origin=a,normal=(direction,0,0))).circle(1.75).sweep(path)
    return elbow,lead

def main(kind):
    g,p=configuration(kind);out=ROOT/kind/'exports';out.mkdir(parents=True,exist_ok=True)
    objects,checks=base.build_case(p,out,body_modifier=lambda c:modify_case(c,g,p,kind))
    case=portrait(objects['case']);holder,fixed,latch,bay=g.holder('switch')
    cq.exporters.export(canonical(holder),str(out/'holder.step'))
    cq.exporters.export(print_pose(holder),str(out/'holder.stl'),tolerance=.04,angularTolerance=.1)
    cq.exporters.export(canonical(holder),str(out/'holder-preview.stl'),tolerance=.06,angularTolerance=.15)
    report=dict(revision=p['revision'],board='ESP32-P4-WIFI6-Touch-LCD-4.3',
        case_mm_portrait=dims(case),holder_mm_portrait=dims(holder),mounted_depth_mm=round(R+.4+bay+3,4),
        main_rim_depth_mm=R+.4,holder_gap_mm=bay,mount_plate_mm=3,
        measured_glass_mm=[114,65],confirmed_mount_pattern_mm=[92,50],
        case_holder_overlap_mm3=volume(case,holder),accessories=[],usb=[],motion=[],
        mount_design=mount.METADATA,physical_fit='prototype; template, cable and bench validation required')
    for n in ['battery','speaker','insulator']:
        if n in objects:report['accessories'].append(dict(part=n,holder_overlap_mm3=volume(portrait(objects[n]),holder)))
    if kind=='switch':
        pocket=rounded(22.8,17.,13.5,30.4,31.,10.,2.)
        cq.exporters.export(pocket,str(out/'pocket-preview.stl'),tolerance=.06,angularTolerance=.15)
        report['shared_cable_bay_mm']=[30.4,31.,10.]
        report['shared_depth_inside_case_mm']=2.5
        for n,obj in [('case',case),('holder',holder),('speaker',portrait(objects['speaker']))]:
            report[n+'_pocket_overlap_mm3']=volume(portrait(pocket),obj)
    plugs=[]
    for i,y in enumerate(base.USB_Y):
        rigid=bottom_plug(y) if kind=='battery' else bent_cable(y)[0]
        plug=rigid if kind=='battery' else rigid.union(bent_cable(y)[1])
        plugs.append(plug)
        cq.exporters.export(canonical(plug),str(out/f'cable-{i}-preview.stl'),tolerance=.07,angularTolerance=.15)
        report['usb'].append(dict(port=i,case_overlap_mm3=volume(case,plug),holder_overlap_mm3=volume(holder,plug)))
    report['two_cable_envelopes_overlap_mm3']=volume(*plugs)
    for lift in [0,.5,1,2,3,4]:
        row=dict(lift_mm=lift,fixed_overlap_mm3=volume(case.translate((0,lift,0)),fixed))
        if kind=='battery':row['battery_overlap_mm3']=volume(portrait(objects['battery']).translate((0,lift,0)),holder)
        else:row['rigid_plug_overlaps_mm3']=[volume(bent_cable(y)[0].translate((0,lift,0)),holder) for y in base.USB_Y]
        report['motion'].append(row)
    for pull in [-1,-3,-6,-10]:report['motion'].append(dict(pull_mm=pull,fixed_overlap_mm3=volume(case.translate((0,4,pull)),fixed)))
    report['locked_lift_interference_mm3']=volume(case.translate((0,1,0)),latch)
    checks['case_mm']=dims(objects['case']);checks['installation']=report
    checks['mechanical_profile']=json.loads((ROOT/'mechanical-profile.json').read_text())
    (out/'design-checks.json').write_text(json.dumps(checks,indent=2)+'\n')
    (out/'assembly-checks.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2),flush=True)
    def check_all(node):
        if isinstance(node,dict):
            for k,v in node.items():
                if k.endswith('_overlap_mm3'):assert v<1e-6,(k,v)
                elif k.endswith('_overlaps_mm3'):assert max(v)<1e-6,(k,v)
                else:check_all(v)
        elif isinstance(node,list):
            for item in node:check_all(item)
    check_all(report)
    assert report['locked_lift_interference_mm3']>1

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('kind',choices=['battery','switch']);main(parser.parse_args().kind)
