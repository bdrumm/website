"""Use the proven rigid-placement exporter for the new, unscaled 4.3 pairs."""
from pathlib import Path
import importlib.util

ROOT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('exporter',ROOT.parent/'p4-5c-case/wall-install-v2/export_3mf.py')
e=importlib.util.module_from_spec(spec);spec.loader.exec_module(e)
e.ROOT=ROOT
for kind,rev in [('battery','k43'),('switch','l43')]:
    out=ROOT/kind/'exports'
    e.OUT=out/f'p4-43-{kind}-{rev}.3mf'
    e.SOURCES=[(f'{rev.upper()} 4.3-inch device case',out/'case-measurement-prototype.stl'),
               (f'{rev.upper()} matching wall holder',out/'holder.stl')]
    e.main()
e.OUT=ROOT/'p4-43-fit-coupons.3mf'
e.SOURCES=[('Measured glass and screw-depth jig',ROOT/'battery/exports/fit-jig.stl'),
           ('26 x 26 x 5 speaker clip',ROOT/'battery/exports/speaker-clip-coupon.stl')]
e.main()
