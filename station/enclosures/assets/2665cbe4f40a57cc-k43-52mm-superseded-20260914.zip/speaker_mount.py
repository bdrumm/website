"""Integral speaker seat and long in-plane leaf catches, revision D prototype.

Speaker dimensions are supplied per revision. Current K43/L43 use the measured
26 x 26 x 5 mm housing; historical defaults are retained for reproducibility.
Each catch is carried by a tall, thin leaf running along the speaker side.
U-shaped slots continue through the rear wall so the leaf is supported at its
end only, rather than acting as a short upright clip. Prints with the cup,
rear-face down; no additional assembly part. Physical coupon validation required.
"""
import cadquery as cq


def box(x, y, z, sx, sy, sz):
    return cq.Workplane("XY").box(sx, sy, sz, centered=False).translate((x, y, z))


def rounded_box(x, y, z, sx, sy, sz, radius):
    result = box(x, y, z, sx, sy, sz)
    return result.edges("|Z").fillet(radius) if radius else result


def rim_cradle(x, y, sx, sy, gap, z, height, thickness=1.):
    outer = rounded_box(x-gap-thickness, y-gap-thickness, z,
                        sx+2*(gap+thickness), sy+2*(gap+thickness), height, 1.2)
    inner = rounded_box(x-gap, y-gap, z-.1,
                        sx+2*gap, sy+2*gap, height+.2, .6)
    return outer.cut(inner)


def add_speaker(case, P, floor_z):
    """Return (case, speaker_reference, design_info) in original rear-view XYZ.

    The caller must not add the earlier short upright speaker clips or grille.
    Leave space at x=speaker_right+.25..+3.25 and y=sy-2.5..sy+sh+2.5.
    Through-wall leaf reliefs are essential: closing them immobilizes the clip.
    """
    sx, sy = P["speaker_xy"]
    sw, sh, st = P["speaker"]
    recess = P.get("speaker_recess", .4)
    gasket = P.get("speaker_gasket", .25)
    side_gap = P.get("speaker_side_gap", .5)
    rear_z = P["rear_z"]
    seat_z = floor_z + recess
    assert rear_z-seat_z >= 1.19, "Speaker grille must retain at least 1.2 mm nominal wall"
    # Move roots outward for a shorter housing instead of shortening/stiffening
    # the proven-length leaves. Keep a gap between the opposed free ends.
    root_outset = P.get("speaker_leaf_root_outset", 0.)
    assert sh+2*root_outset >= 29.5, "Opposed leaves need at least 4.5 mm between free ends"
    speaker_z = seat_z-gasket-st
    speaker = rounded_box(sx, sy, speaker_z, sw, sh, st, 1.)

    seat_pocket = rounded_box(sx-.5, sy-.5, floor_z-.1, sw+1, sh+1,
                             recess+.1, 1.2)
    case = case.cut(seat_pocket)
    cradle = rim_cradle(sx, sy, sw, sh, side_gap, floor_z-3., 3.)
    cradle = cradle.cut(box(sx-2, sy+sh-8, floor_z-3.1, 3, 8, 3.3))
    # The long leaf must not be braced by the old right cradle wall.
    cradle = cradle.cut(box(sx+sw-.1, sy-1., floor_z-3.1, 4., sh+2., 3.3))
    case = case.union(cradle)

    left_stop_gap = P.get("speaker_left_stop_gap", .10)
    axial_play = P.get("speaker_axial_play", .25)
    hook_overlap = P.get("speaker_hook_overlap", .25)
    assert hook_overlap > left_stop_gap, "Left float must not release the right teeth"
    fixed_lip_offsets = P.get("speaker_fixed_lip_offsets", (5.,20.))
    assert all(0 <= float(o) <= sh-4 for o in fixed_lip_offsets)
    for yy in (sy+float(offset) for offset in fixed_lip_offsets):
        upright = box(sx-1.2, yy, speaker_z-.9, 1.2-left_stop_gap, 4.,
                      floor_z-speaker_z+.9)
        lip = box(sx-.4, yy, speaker_z-.9, .8, 4., .9-axial_play)
        case = case.union(upright).union(lip)

    # Flex is along x; leaf length is along y. The full-height wall leaf also
    # reduces twisting compared with a thin horizontal strip carrying a tall peg.
    leaf_thickness = .8
    leaf_length = 12.5
    tooth_width = 3.
    root_length = 2.5
    release_gap = 1.1
    beam_x = sx+sw+.25
    beam_outer = beam_x+leaf_thickness
    catch_z = speaker_z-axial_play
    tip_z = speaker_z-1.35
    root_starts = (sy-root_outset, sy+sh+root_outset)
    leaf_records = []
    for anchor_y, direction in ((root_starts[0], 1), (root_starts[1], -1)):
        free_y = anchor_y+direction*leaf_length
        leaf_y = min(anchor_y, free_y)
        root_y = anchor_y-root_length if direction == 1 else anchor_y
        tooth_y = free_y-tooth_width if direction == 1 else free_y
        end_slot_y = free_y if direction == 1 else free_y-.8

        # Reliefs cut the full rear wall before adding the freestanding leaf.
        # Rounded ends avoid a sharp notch in the supporting rear wall.
        slot_y = leaf_y if direction == 1 else leaf_y-.4
        for slot_x, slot_width in ((beam_x-.6, .6), (beam_outer, release_gap)):
            slot = rounded_box(slot_x, slot_y, tip_z-.1, slot_width, leaf_length+.4,
                               rear_z-tip_z+.2, .24)
            case = case.cut(slot)
        end_slot = rounded_box(beam_x-.6, end_slot_y, tip_z-.1,
                               leaf_thickness+.6+release_gap, .8,
                               rear_z-tip_z+.2, .24)
        case = case.cut(end_slot)

        root = box(beam_x, root_y, tip_z, leaf_thickness+2.2, root_length,
                   rear_z-tip_z)
        leaf = box(beam_x, leaf_y, tip_z, leaf_thickness, leaf_length,
                   rear_z-tip_z)
        # Small in-plane outside root rounding. It ends within the release slot;
        # the rest of that slot stays open so the leaf bends along its length.
        r = .5
        if direction == 1:
            root_round = (cq.Workplane("XY").moveTo(beam_outer,anchor_y+r)
                .threePointArc((beam_outer+r*.2928932,anchor_y+r*.2928932),
                               (beam_outer+r,anchor_y))
                .lineTo(beam_outer,anchor_y).close().extrude(rear_z-tip_z)
                .translate((0,0,tip_z)))
        else:
            root_round = (cq.Workplane("XY").moveTo(beam_outer,anchor_y-r)
                .threePointArc((beam_outer+r*.2928932,anchor_y-r*.2928932),
                               (beam_outer+r,anchor_y))
                .lineTo(beam_outer,anchor_y).close().extrude(rear_z-tip_z)
                .translate((0,0,tip_z)))
        # Flat rear-facing catch, sloped insertion lead-in; 0.5 mm tooth reach.
        hook = (cq.Workplane("XZ").polyline([
            (beam_x,tip_z), (beam_x,catch_z), (sx+sw-hook_overlap,catch_z)])
            .close().extrude(tooth_width).translate((0,tooth_y+tooth_width,0)))
        case = case.union(root).union(leaf).union(root_round).union(hook)
        leaf_records.append(dict(anchor_y=anchor_y, free_y=free_y,
                                 hook_y=[tooth_y,tooth_y+tooth_width]))

    # Retain a perimeter around the smaller measured housing. Keeping the old
    # 25.6 mm-wide grille in a 26 mm body would leave almost no side margin.
    max_dx=min(12, int((sw/2-3)/3)*3)
    grille_length=min(20.,sh-6.)
    for dx in range(-max_dx, max_dx+1, 3):
        case = case.cut(rounded_box(sx+sw/2+dx-.8, sy+sh/2-grille_length/2, seat_z-.1,
                                    1.6, grille_length, rear_z-seat_z+.2, .7))

    info = dict(type="two integral long in-plane leaf catches and two fixed lips",
        revision="D" if root_outset==0 else "26-square", measured_speaker_thickness_mm=st,
        housing_mm=[sw,sh,st], housing_dimensions_confirmed=P.get('speaker_dimensions_confirmed',False),
        leaf_root_outset_mm=root_outset, opposed_free_end_gap_mm=sh+2*root_outset-2*leaf_length,
        grille_slot_count=2*max_dx//3+1, grille_side_margin_mm=sw/2-max_dx-.8,
        speaker_front_z=speaker_z, radiating_face_z=speaker_z+st,
        grille_thickness_mm=rear_z-seat_z,
        radiating_face_to_exterior_mm=rear_z-(speaker_z+st),
        axial_free_play_mm=axial_play, snap_engagement_mm=hook_overlap,
        left_stop_gap_mm=left_stop_gap,
        fixed_lip_offsets_mm=list(fixed_lip_offsets),
        minimum_nominal_hook_overlap_after_left_float_mm=hook_overlap-left_stop_gap,
        leaf_thickness_mm=leaf_thickness, leaf_length_mm=leaf_length,
        conservative_root_to_load_mm=9.0,
        leaf_rear_relief_outer_gap_mm=release_gap,
        estimated_insertion_travel_mm=.5,
        estimated_free_tip_travel_mm=.75,
        simple_bending_surface_strain_percent=100*1.5*leaf_thickness*.5/9.0**2,
        leaves=leaf_records,
        physical_clip_fit="requires PETG coupon with actual housing; wire exit and corner profile still need checking",
        limitations=["Rear-wall U slots must remain open for the leaves to flex",
                     "Ideal bending estimate excludes torsion, notch/layer effects and print tolerances",
                     "Axial play retains the speaker but does not provide gasket preload",
                     "No physical retention force, load rating or cycle-life validation"])
    if not case.val().isValid() or len(case.solids().vals()) != 1:
        raise ValueError("Speaker mount must leave one valid connected case solid")
    if case.intersect(speaker).val().Volume() > 1e-6:
        raise ValueError("Integral speaker mount overlaps the nominal seated speaker")
    return case, speaker, info
