"""Soft 45-degree perimeter chamfer, applied to the solid cup blank.

Apply before hollowing, ports, screw wells and docking features. Only the two
outside perimeter loops are treated; internal and interface edges stay sharp
where their fit depends on it. Units are millimetres.
"""
from math import pi, tan, sqrt
import cadquery as cq


class _LevelEdges(cq.Selector):
    """Edges on a constant-Z level, including the rounded-corner arcs."""

    def filter(self, objects):
        return [edge for edge in objects
                if isinstance(edge, cq.Edge)
                and edge.BoundingBox().zlen < 1e-6]


def finish_outer(outer, chamfer_mm=0.6, blend_radius_mm=0.15, wall_mm=None):
    """Return ``(finished_blank, info)`` for an upright rounded-rectangle blank.

    Each front/rear perimeter gets an equal-distance 45-degree chamfer. A small
    tangent fillet then softens both borders of each bevel. The original long
    side faces and overall dimensions remain in place. No accessory, cavity or
    mounting geometry is passed to this helper.
    """
    if len(outer.solids().vals()) != 1 or not outer.val().isValid():
        raise ValueError("Outer finishing needs one valid solid blank")
    if chamfer_mm <= 0 or blend_radius_mm <= 0:
        raise ValueError("Chamfer and blend radius must be positive")
    blend_setback = blend_radius_mm * tan(pi / 8)
    bevel_straight = chamfer_mm * sqrt(2) - 2 * blend_setback
    if bevel_straight <= 0:
        raise ValueError("Blend radius consumes the entire 45-degree bevel")
    rim_remaining = (wall_mm - chamfer_mm - blend_setback
                     if wall_mm is not None else None)
    if rim_remaining is not None and rim_remaining <= 0:
        raise ValueError("Finishing would remove the front rim")

    original = outer.val()
    bounds_before = original.BoundingBox()
    beveled = outer.faces(">Z or <Z").edges().chamfer(chamfer_mm)
    level_edges = beveled.edges(_LevelEdges())
    edge_count = len(level_edges.vals())
    finished = level_edges.fillet(blend_radius_mm)
    shape = finished.val()
    bounds_after = shape.BoundingBox()
    if len(finished.solids().vals()) != 1 or not shape.isValid():
        raise ValueError("Outer finishing produced an invalid or disconnected blank")
    bound_names = ("xmin", "xmax", "ymin", "ymax", "zmin", "zmax")
    bounds_error = max(abs(getattr(bounds_before, name) - getattr(bounds_after, name))
                       for name in bound_names)
    if bounds_error > 1e-5:
        raise ValueError(f"Outer finishing changed the envelope by {bounds_error} mm")
    added_volume = finished.cut(outer).val().Volume()
    if added_volume > 1e-6:
        raise ValueError(f"Outer finishing added {added_volume} mm^3 of material")

    return finished, {
        "profile": "0.6 mm 45-degree outer chamfer with 0.15 mm tangent blends"
                   if chamfer_mm == 0.6 and blend_radius_mm == 0.15
                   else "45-degree outer chamfer with tangent blends",
        "scope": "Front and rear outside perimeter of the cup blank only",
        "chamfer_equal_setback_mm": chamfer_mm,
        "chamfer_angle_deg": 45,
        "blend_radius_mm": blend_radius_mm,
        "blend_tangent_setback_mm": blend_setback,
        "straight_bevel_face_width_mm": bevel_straight,
        "minimum_front_rim_width_mm": rim_remaining,
        "blended_boundary_edge_count": edge_count,
        "maximum_envelope_change_mm": bounds_error,
        "material_added_mm3": added_volume,
        "material_removed_mm3": original.Volume() - shape.Volume(),
        "valid_solid": True,
        "solid_count": 1,
    }
