"""4.3-inch measured-case geometry. User outline takes priority over newer vendor glass.
Never scale physical interfaces. See mechanical-profile.json for provenance.
"""
from pathlib import Path
import json
import importlib.util
import cadquery as cq
from outer_finish import finish_outer

HERE = Path(__file__).resolve().parent
OUT = HERE / "exports"
OUT.mkdir(exist_ok=True)

# Actual glass and depth measured by owner; 92 x 50 pattern confirmed.
# Nominal centers assume a centered glass substitution; slots allow X +/-0.35, Y +/-1.0.
# Board/USB native positions are rebased from the 4.3-inch STEP, never scaled.
GLASS = (114.0, 65.0)
GLASS_RADIUS = 2.5
MOUNTS = [(x, y) for x in (8.75, 100.75) for y in (7.5, 57.5)]
MOUNT_Z = 11.5
USB_Y = (23.898, 41.098)
USB_Z = 8.6695

# Case choices, adjustable for a calibrated printer and measured accessories.
# User confirmed battery dimensions include casing; speaker wire length = 50 mm.
# Speaker housing is measured at 26 x 26 x 5 mm; lead exit remains unmeasured.
P = dict(
    revision="4.3-template", outer_chamfer_mm=0.6, outer_blend_radius_mm=0.15,
    perimeter_gap=0.35, wall=1.8, back=1.6, rim_proud=0.4, rear_z=23.3,
    screw_clearance=2.9, screw_well=7.6, screw_post=11.5, screw_web=2.0,
    battery=[52.0, 36.0, 10.0], battery_xy=[9.0, 17.0],
    battery_side_gap=0.4, battery_rear_pad=0.25, battery_insulator=0.25,
    speaker=[26.0, 26.0, 5.0], speaker_xy=[65.0, 34.0],
    speaker_dimensions_confirmed=True, speaker_leaf_root_outset=2.0,
    speaker_fixed_lip_offsets=[10.,20.], usb_coupon_enabled=False,
    speaker_side_gap=0.5, speaker_left_stop_gap=0.1, speaker_gasket=0.25, speaker_recess=0.4,
    battery_enabled=True, camera_enabled=False, dock_enabled=False,
    camera=[16.0, 16.0, 8.0], camera_xy=[98.0, 17.0],
    camera_pcb=1.2, lens_diameter=10.0, lens_recess=0.3, camera_mount_pad=0.3,
    usb_boot_width=14.0, usb_boot_height=8.0,
)

def box(x, y, z, sx, sy, sz):
    return cq.Workplane("XY").box(sx, sy, sz, centered=False).translate((x, y, z))

def rounded_box(x, y, z, sx, sy, sz, radius):
    obj = box(x, y, z, sx, sy, sz)
    return obj.edges("|Z").fillet(radius) if radius else obj

def cyl(x, y, z, d, h):
    return cq.Workplane("XY").center(x, y).circle(d / 2).extrude(h).translate((0, 0, z))

def mount_slot(x, y, z, diameter, depth):
    return rounded_box(x-diameter/2-.35,y-diameter/2-1.,z,diameter+.7,diameter+2.,depth,diameter/2-.001)

def union_all(items):
    result = items[0]
    for item in items[1:]:
        result = result.union(item)
    return result

def side_open_x(y, z, w, h):
    # Rounded opening for the entire plug boot, all the way to the receptacle.
    return (cq.Workplane("YZ").center(y, z).rect(w, h).extrude(7.0)
            .edges("|X").fillet(1.4).translate((-3.0, 0, 0)))

def rim_cradle(x, y, sx, sy, gap, z, height, thickness=1.0):
    outer = rounded_box(x-gap-thickness, y-gap-thickness, z,
                        sx+2*(gap+thickness), sy+2*(gap+thickness), height, 1.2)
    inner = rounded_box(x-gap, y-gap, z-0.1,
                        sx+2*gap, sy+2*gap, height+0.2, 0.6)
    return outer.cut(inner)

def build_case(P, OUT=OUT, body_modifier=None):
    """Build and export one cup. Optional dock modifier receives a Workplane.

    Returns (objects, checks); coordinates stay in the manufacturer rear frame.
    """
    OUT = Path(OUT)
    OUT.mkdir(parents=True, exist_ok=True)
    gap, wall = P["perimeter_gap"], P["wall"]
    ext = gap + wall
    width, height = GLASS[0]+2*ext, GLASS[1]+2*ext
    floor_z = P["rear_z"] - P["back"]
    front_z = -P["rim_proud"]
    depth = P["rear_z"] - front_z

    # One rear cup. The complete display inserts through the unobstructed front.
    # Its four factory threaded posts rest against these rear supports; the glass
    # has a clearance fit and is not clamped between two faces.
    outer = rounded_box(-ext, -ext, front_z, width, height, depth,
                        GLASS_RADIUS+ext)
    outer, outer_finish_info = finish_outer(outer, P["outer_chamfer_mm"],
                                            P["outer_blend_radius_mm"], wall_mm=wall)
    cavity = rounded_box(-gap, -gap, front_z-0.1,
                         GLASS[0]+2*gap, GLASS[1]+2*gap,
                         floor_z-front_z+0.1, GLASS_RADIUS+gap)
    case = outer.cut(cavity)

    for x, y in MOUNTS:
        post = cyl(x, y, MOUNT_Z, P["screw_post"], P["rear_z"]-MOUNT_Z)
        post = post.cut(mount_slot(x,y,MOUNT_Z-0.1,P["screw_clearance"],depth))
        post = post.cut(mount_slot(x,y,MOUNT_Z+P["screw_web"],P["screw_well"],depth))
        case = case.union(post)
        # Continue the head/driver well through the back wall.
        case = case.cut(mount_slot(x,y,MOUNT_Z+P["screw_web"],P["screw_well"],depth))

    for y in USB_Y:
        case = case.cut(side_open_x(y, USB_Z, P["usb_boot_width"], P["usb_boot_height"]))

    # Reset, boot and power controls deliberately have no external openings.

    battery = insulator = None
    battery_z = None
    if P.get("battery_enabled", True):
        bx, by = P["battery_xy"]
        bw, bh, bt = P["battery"]
        battery_floor_z = P.get("battery_rear_z", P["rear_z"]) - P["back"]
        if battery_floor_z > floor_z:
            # A closed local pod can occupy an unused docking cavity without
            # thickening the whole rim. Its interior remains accessible from
            # the screen side for assembly; supports are required for printing.
            bg=P["battery_side_gap"];skin=P["wall"]
            pod=rounded_box(bx-bg-skin,by-bg-skin,floor_z,
                            bw+2*(bg+skin),bh+2*(bg+skin),
                            battery_floor_z+P["back"]-floor_z,2.)
            pod=pod.faces(">Z").edges().fillet(.35)
            case=case.union(pod)
            case=case.cut(rounded_box(bx-bg,by-bg,floor_z-.1,
                          bw+2*bg,bh+2*bg,battery_floor_z-floor_z+.1,.6))
        battery_z = battery_floor_z - P["battery_rear_pad"] - bt
        battery = box(bx, by, battery_z, bw, bh, bt)
        # Total board-facing insulating film + any adhesive is limited to this budget.
        # It is a separate consumable, not an extra printed floor or a thermal barrier.
        insulator = box(bx,by,battery_z-P["battery_insulator"],bw,bh,P["battery_insulator"])
        cradle = rim_cradle(bx,by,bw,bh,P["battery_side_gap"],battery_floor_z-3.5,3.5)
        # Wire/pull-tab exit: no sharp lip across the lead end.
        cradle = cradle.cut(box(bx-2.0,by+bh/2-5.0,battery_floor_z-3.6,4.0,10.0,3.8))
        case = case.union(cradle)

    speaker_spec = importlib.util.spec_from_file_location("speaker_mount", HERE/"speaker_mount.py")
    speaker_module = importlib.util.module_from_spec(speaker_spec)
    speaker_spec.loader.exec_module(speaker_module)
    speaker_P=dict(P,rear_z=P.get("speaker_rear_z",P["rear_z"]))
    speaker_floor_z=speaker_P["rear_z"]-P["back"]
    speaker_root_outset=P.get('speaker_leaf_root_outset',0.)
    speaker_support_margin=max(3.,speaker_root_outset+2.5+.6) if speaker_root_outset else 3.
    if speaker_floor_z>floor_z:
        sx,sy=P["speaker_xy"];sw,sh,_=P["speaker"]
        case=case.union(rounded_box(sx-1.5,sy-speaker_support_margin,floor_z,sw+6,sh+2*speaker_support_margin,
                                  speaker_P["rear_z"]-floor_z,1.2))
        case=case.cut(rounded_box(sx-.5,sy-.5,floor_z-.1,sw+1,sh+1,
                                speaker_floor_z-floor_z+.1,1.2))
    case, speaker, speaker_info = speaker_module.add_speaker(case, speaker_P, speaker_floor_z)
    speaker_z = speaker_info["speaker_front_z"]

    camera = None
    camera_z = None
    camera_info = None
    if P.get("camera_enabled", True):
        spec = importlib.util.spec_from_file_location("camera_mount", HERE/"camera_mount.py")
        camera_module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(camera_module)
        case, camera, camera_info = camera_module.add_camera(case, P, floor_z)
        camera_z = camera_info["camera_front_z"]

    # Small rear ventilation field away from the battery and speaker chamber.
    for x in (67.0, 70.0, 73.0, 76.0, 79.0):
        case = case.cut(rounded_box(x,15.0,floor_z-0.1,1.2,8.0,P["back"]+0.2,0.5))

    # The marked small side slot and its opposite-side counterpart are closed.
    # Board connections stay internal; reset/boot/power walls also stay solid.

    # Every cup has the same recessed docking sockets; the holder is optional.
    dock_info = None
    if body_modifier is not None:
        case = body_modifier(case)
    # Receivers may approach the lower factory posts. Relieve their forward
    # faces for the complete post plus adjustment; preserve the z=11.5 seats.
    for x,y in MOUNTS:
        case=case.cut(mount_slot(x,y,0,6.0,MOUNT_Z))
    # Local pods or docking bosses must not close the factory screw/driver
    # paths that were cut before those features were added.
    if P.get("battery_rear_z",P["rear_z"])>P["rear_z"] or P.get("speaker_rear_z",P["rear_z"])>P["rear_z"]:
        well_depth=max(P["rear_z"],P.get("battery_rear_z",0),P.get("speaker_rear_z",0))+1
        for x,y in MOUNTS:
            case=case.cut(mount_slot(x,y,MOUNT_Z-.1,P["screw_clearance"],well_depth))
            case=case.cut(mount_slot(x,y,MOUNT_Z+P["screw_web"],P["screw_well"],well_depth))

    # Reference volumes only, not manufacturing parts.
    glass = rounded_box(0,0,0,*GLASS,1.3,GLASS_RADIUS)
    ref=cq.Shape.importBrep(str(HERE/'reference/board-aligned.brep')).Solids()
    # Translation aligns the vendor PCB/post stack to measured front-to-post depth.
    # The vendor glass is replaced by the actual measured outline above.
    pcb=cq.Workplane(obj=ref[4].translate((-.2,-.9,.35)))
    # Preview omits tiny passives; the independent check uses every vendor solid.
    modules=cq.Workplane(obj=cq.Compound.makeCompound([s.translate((-.2,-.9,.35)) for s in ref[5:] if s.Volume()>.5]))

    # Rear-face-down print orientation: underside flat on z=0, cup opens upward.
    def print_pose(obj):
        posed = obj.rotate((0,0,0),(1,0,0),180)
        bb = posed.val().BoundingBox()
        return posed.translate((-bb.xmin,-bb.ymin,-bb.zmin))

    objects = dict(case=case,battery=battery,speaker=speaker,camera=camera,insulator=insulator,
                   glass=glass,pcb=pcb,modules=modules)
    objects = {k:v for k,v in objects.items() if v is not None}
    checks = {"revision":P.get("revision", "4.3-template"), "status": "MEASUREMENT PROTOTYPE — not fit approved", "parameters": P,
              "case_mm": [width,height,depth], "board_mount_pattern_mm": [92,50],
              "battery_front_z":battery_z,"insulator_front_z":battery_z-P["battery_insulator"] if battery_z is not None else None,"speaker_front_z":speaker_z,
              "camera_front_z":camera_z,"valid_solids":{}}
    for name, obj in objects.items():
        shape = obj.val()
        checks["valid_solids"][name] = bool(shape.isValid())
        if not shape.isValid():
            raise ValueError(f"Invalid CAD solid: {name}")
        cq.exporters.export(obj, str(OUT / f"{name}-preview.stl"), tolerance=0.06, angularTolerance=0.15)

    if len(case.solids().vals()) != 1:
        raise ValueError("Case must be one connected solid")
    for a,b in [("battery","speaker"),("battery","camera"),("speaker","camera")]:
        if a not in objects or b not in objects:
            continue
        overlap=objects[a].intersect(objects[b]).val().Volume()
        if overlap>1e-5:
            raise ValueError(f"Accessory overlap: {a}, {b}: {overlap}")

    cq.exporters.export(case,str(OUT/"case-measurement-prototype.step"))
    cq.exporters.export(print_pose(case),str(OUT/"case-measurement-prototype.stl"),tolerance=0.04,angularTolerance=0.1)

    # Low-material first prints, exported as separate pieces on their own z=0.
    # The USB strip checks cable-boot cross-sections; the full cup is still needed
    # to verify insertion depth relative to the mounted board.
    usb_coupon = case.intersect(box(-3,15,4.0,5.0,41.0,10.0))
    def normalize(obj):
        # Exact bounds avoid lifting the rounded fit ring off the print plane
        # by the conservative bounding-box allowance of its blend surfaces.
        from OCP.BRepBndLib import BRepBndLib
        from OCP.Bnd import Bnd_Box
        bb=Bnd_Box()
        BRepBndLib.AddOptimal_s(obj.val().wrapped,bb,False,False)
        bounds=bb.Get()
        return obj.translate((-bounds[0],-bounds[1],-bounds[2]))
    if P.get("usb_coupon_enabled", True):
        usb_coupon = normalize(usb_coupon.rotate((0,0,0),(0,1,0),90))
        cq.exporters.export(usb_coupon,str(OUT/"usb-clearance-coupon.stl"),tolerance=0.04)
    rim_coupon = normalize(case.intersect(box(-3,-3,-0.5,width+2,height+2,1.7)))
    cq.exporters.export(rim_coupon,str(OUT/"glass-fit-ring.stl"),tolerance=0.04)
    template = union_all([cyl(x,y,0,11.5,1.6) for x,y in MOUNTS] + [
        box(8.75,y-1.6,0,92.,3.2,1.6) for y in (7.5,57.5)] + [
        box(x-1.6,7.5,0,3.2,50.,1.6) for x in (8.75,100.75)])
    for x,y in MOUNTS:
        template = template.cut(mount_slot(x,y,-.1,P['screw_clearance'],2.))
    # Link the pattern to the glass opening so the coupon checks its offset too.
    rim=rounded_box(-ext,-ext,0,width,height,1.6,GLASS_RADIUS+ext).cut(
        rounded_box(-gap,-gap,-.1,GLASS[0]+2*gap,GLASS[1]+2*gap,1.8,GLASS_RADIUS+gap))
    for x,y in MOUNTS:
        yedge=-ext if y<GLASS[1]/2 else y
        span=y+ext if y<GLASS[1]/2 else GLASS[1]+ext-y
        template=template.union(box(x-1.6,yedge,0,3.2,span,1.6))
    template=template.union(rim)
    cq.exporters.export(normalize(template),str(OUT/'mount-pattern-template.stl'),tolerance=.04)

    # Full speaker coupon includes the long leaves and BOTH end roots.
    # Reuse the same feature on a small plate so adjacent camera walls do not
    # produce thin cropped remnants in the coupon.
    sx, sy = P["speaker_xy"]
    sw, sh, st = P["speaker"]
    coupon_plate = box(sx-2,sy-speaker_support_margin,speaker_floor_z,
                       sw+6,sh+2*speaker_support_margin,P["back"])
    clip_coupon, _, _ = speaker_module.add_speaker(coupon_plate, speaker_P, speaker_floor_z)
    cq.exporters.export(print_pose(clip_coupon),
                        str(OUT/"speaker-clip-coupon.stl"),tolerance=.04)
    checks["outer_finish"] = outer_finish_info
    checks["speaker_retention"] = speaker_info
    checks["external_board_button_openings"] = False
    checks["small_side_slots"] = False
    checks["shared_device_case"] = False
    checks["board"] = "ESP32-P4-WIFI6-Touch-LCD-4.3"
    checks["mount_adjustment_xy_mm"] = [.35,1.0]
    bb = case.val().BoundingBox()
    checks["case_bounds_mm"] = [round(bb.xlen,3),round(bb.ylen,3),round(bb.zlen,3)]
    checks["docking_mount"] = dock_info
    checks["camera_mount"] = camera_info

    checks["case_volume_cm3"]=round(case.val().Volume()/1000,2)
    checks["case_connected_solids"]=len(case.solids().vals())
    (OUT/"design-checks.json").write_text(json.dumps(checks,indent=2)+"\n")
    print(json.dumps(checks,indent=2))
    return objects, checks

if __name__ == "__main__":
    raise SystemExit("Use build.py battery or build.py switch for a configured 4.3-inch variant")
