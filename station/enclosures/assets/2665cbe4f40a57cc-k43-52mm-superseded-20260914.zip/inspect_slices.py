"""Draw real slicer extrusion paths for visual review (never sends G-code)."""
from pathlib import Path
import re,sys,math
from collections import defaultdict
from PIL import Image,ImageDraw
source=Path(sys.argv[1]);text=source.read_text()
target_object=int(sys.argv[2]) if len(sys.argv)>2 else 12
label='case' if target_object==8 else 'holder'
kind=sys.argv[3];targets=([2.6,8.6,11.2,13.8] if target_object==8 else [2.6,9.0,14.4,16.2]) if kind=='battery' else ([1.4,3.8,5.8,7.8] if target_object==8 else [2.6,7.6,12.6,14.4]);segments=defaultdict(list)
x=y=z=0.;obj=None;feature='';relative_e=False;eprev=0
for line in text.splitlines():
    if line.startswith('; start printing object'):obj=int(line.rsplit(':',1)[1])
    elif line.startswith('; stop printing object'):obj=None
    elif line.startswith('; FEATURE:'):feature=line.split(': ',1)[1]
    else:
        code=line.split(';')[0].strip()
        if code=='M83':relative_e=True
        elif code=='M82':relative_e=False
        elif code.startswith('G92 E'):eprev=float(code[5:])
        elif code.startswith(('G0 ','G1 ','G2 ','G3 ')):
            vals={k:float(v) for k,v in re.findall(r'([XYZERIJ])(-?(?:\d+(?:\.\d*)?|\.\d+))',code)}
            nx,ny,nz=vals.get('X',x),vals.get('Y',y),vals.get('Z',z)
            e=vals.get('E',0 if relative_e else eprev);de=e if relative_e else e-eprev
            # Bambu model_settings.config maps S3 holder to label 12.
            if obj==target_object and de>0 and (x!=nx or y!=ny):
                points=[(x,y),(nx,ny)]
                if code.startswith(('G2 ','G3 ')):
                    assert 'R' not in vals,'Use I/J arc centers for this review'
                    cx,cy=x+vals.get('I',0),y+vals.get('J',0)
                    radius=math.hypot(x-cx,y-cy)
                    start=math.atan2(y-cy,x-cx);end=math.atan2(ny-cy,nx-cx)
                    angle=(end-start)%(2*math.pi)
                    if code.startswith('G2 '):angle-=2*math.pi
                    count=max(2,min(512,math.ceil(abs(angle)*radius/.35)))
                    points=[(cx+radius*math.cos(start+angle*i/count),
                             cy+radius*math.sin(start+angle*i/count)) for i in range(count+1)]
                for (x1,y1),(x2,y2) in zip(points,points[1:]):
                    segments[round(nz,4)].append((x1,y1,x2,y2,feature))
            x,y,z=nx,ny,nz
            if 'E' in vals:eprev=e
available=[h for h,v in segments.items() if any(not s[-1].startswith('Support') for s in v)]
levels=[min(available,key=lambda h:abs(h-t)) for t in targets]
assert all(abs(h-t)<.21 for h,t in zip(levels,targets)),levels
img=Image.new('RGB',(1200,760),'white');draw=ImageDraw.Draw(img)
support_planes={z:[s for s in paths if s[-1].startswith('Support')] for z,paths in segments.items()}
support_planes={z:paths for z,paths in support_planes.items() if paths}
for i,lv in enumerate(levels):
    support_z=min(support_planes,key=lambda z:abs(z-lv))
    # Support layers are independently spaced in the slicer. Show the nearest
    # support plane explicitly instead of implying absence at the model plane.
    support_paths=support_planes[support_z] if abs(support_z-lv)<=.22 else []
    segs=[s for s in segments[lv] if not s[-1].startswith('Support')]+support_paths
    xs=[q[k] for q in segs for k in [0,2]];ys=[q[k] for q in segs for k in [1,3]]
    xmin,xmax,ymin,ymax=min(xs),max(xs),min(ys),max(ys)
    scale=min(540/(xmax-xmin),295/(ymax-ymin));ox=30+(i%2)*600;oy=45+(i//2)*375
    title=f'{label.capitalize()} model Z {lv} mm'
    if support_paths:title+=f' / support Z {support_z} mm (orange)'
    draw.text((ox,oy-28),title,fill='black')
    for x1,y1,x2,y2,f in segs:
        draw.line((ox+(x1-xmin)*scale,oy+(ymax-y1)*scale,
                   ox+(x2-xmin)*scale,oy+(ymax-y2)*scale),
                  fill=(210,115,30) if f.startswith('Support') else (32,42,47),width=1)
dest=Path(__file__).parent/kind/f'exports/print-check/{label}-toolpaths.png'
img.save(dest)
print(dest)
