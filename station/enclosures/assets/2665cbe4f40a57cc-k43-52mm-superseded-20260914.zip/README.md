# Actual 4.3-inch display cases

The owner confirmed ESP32-P4-WIFI6-Touch-LCD-4.3 after a 5-inch-reference printed case failed to fit. Use the K43 battery wall pair or L43 batteryless switch pair in this directory. Both use the measured 114 × 65 × 11.5 mm display envelope and 26 × 26 × 5 mm speaker.

See each variant README for assembly and fit checks; mechanical-profile.json separates measured and vendor dimensions. Run build.py battery / switch with CadQuery 2.8, then validate_clearances.py, verify_mount.py, make_fit_jig.py and export_3mf.py. The browser viewer remains at ../p4-5c-case/viewer for continuity and carries both current 4.3-inch designs and the labeled 5-inch archive.
