"""Check the exported pair, complete spring sweep, stop and real board.

The variable-width Euler-Bernoulli estimate is a geometry screening model,
not FEA, a material allowables check, or evidence of printed durability.
"""
from pathlib import Path
import json,hashlib,math
import numpy as np
import cadquery as cq
import build as b
import argparse
parser=argparse.ArgumentParser();parser.add_argument("kind",choices=["battery","switch"]);kind=parser.parse_args().kind

g,p=b.configuration(kind);R=g.R;OUT=b.ROOT/kind/"exports"
g.volume=b.volume;g.print_pose=b.print_pose
mirror=kind=="battery"
def left(obj):return obj.mirror("YZ",(b.W/2,0,0)) if mirror else obj
case=g.portrait(cq.importers.importStep(str(OUT/'case-measurement-prototype.step')))
exported=g.portrait(cq.importers.importStep(str(OUT/'holder.step')))
holder,fixed,latch,bay=g.holder('switch')
case=left(case);exported=left(exported);holder=left(holder);fixed=left(fixed);latch=left(latch)
assert g.volume(holder,exported)>holder.val().Volume()-1e-5

# The root blend ends at v23.4. Integrate bending compliance for the actual
# linear width taper. E cancels for a prescribed displacement. Use t=1.6.
y0=23.4;a=51.0-y0;L=52.05-y0;t=1.6
x=np.linspace(0,L,2001)
width=8-2*(x+y0-21.4)/(52.05-21.4)
I=width*t**3/12
curvature_unit=np.maximum(a-x,0)/I
dx=x[1]-x[0]
def integrate(f):return np.r_[0,np.cumsum((f[:-1]+f[1:])*.5*dx)]
theta_unit=integrate(curvature_unit);w_unit=integrate(theta_unit)
scale=2/np.interp(a,x,w_unit)
w=w_unit*scale;theta=theta_unit*scale
def disp(y):return 0.0 if y<=y0 else float(np.interp(y-y0,x,w))
def slope(y):return 0.0 if y<=y0 else float(np.interp(y-y0,x,theta))

# Piecewise rigid strips of the actual latch use the same displacement and
# local tangent. This includes the paddle, full tooth and widened leaf, not
# just a translated tooth tip. Root stays fixed. 0.4 mm spatial stations.
strips=[]
for lo,hi in zip(np.arange(y0,52.05,.4),np.minimum(np.arange(y0,52.05,.4)+.4,52.05)):
    strip=latch.intersect(g.box(-1,lo,R-2,14,hi-lo,6))
    if strip.val().Volume()>1e-8:strips.append((.5*(lo+hi),strip))
def deformed(fraction):
    parts=[]
    for y,s in strips:
        p=(0,y,R+2.4)
        parts.append(s.rotate(p,(1,y,R+2.4),math.degrees(slope(y))*fraction)
                     .translate((0,0,disp(y)*fraction)))
    return cq.Compound.makeCompound([p.val() for p in parts])
report={'revision':p['revision'],'case_sha256':hashlib.sha256((OUT/'case-measurement-prototype.step').read_bytes()).hexdigest(),
 'holder_sha256':hashlib.sha256((OUT/'holder.step').read_bytes()).hexdigest(),
 'spring_screen':{'method':'variable-width linear elastic beam, ideal rigid root; print anisotropy and local concentration not modeled',
   'effective_length_mm':L,'thickness_mm':t,'commanded_press_mm':2.0,
   'nominal_peak_surface_strain_percent':float(np.max(curvature_unit*scale*t/2)*100),
   'tip_wallward_motion_mm':disp(52.05),'tooth_leading_motion_mm':disp(47.05),
   'minimum_rigid_tooth_clearance_mm':disp(47.05)-1.1},
 'sweep_strip_tolerance_mm3':1e-4,'sweep':[],'released_lift':[],'stop':{},'coupons':{},'board':{}}
for fraction in [0,.25,.5,.75,1]:
    d=deformed(fraction)
    row={'press_mm':fraction*2,'fixed_overlap_mm3':max(0,d.intersect(fixed.val()).Volume()),
         'case_overlap_mm3':max(0,d.intersect(case.val()).Volume())}
    report['sweep'].append(row)
    assert row['fixed_overlap_mm3']<1e-4 and row['case_overlap_mm3']<1e-4,row
released=deformed(1)
for lift in np.linspace(0,4,17):
    vol=max(0,released.intersect(case.translate((0,float(lift),0)).val()).Volume())
    report['released_lift'].append({'lift_mm':float(lift),'overlap_mm3':vol})
    assert vol<1e-6,(lift,vol)
report['unreleased_lift_overlap_mm3']=g.volume(case.translate((0,1,0)),latch)
assert report['unreleased_lift_overlap_mm3']>1
# Probe the stop using the full beam. A stroke beyond its design limit must
# cause collision with the stop; nominal release must not.
for press in [2.0,2.1,2.2,2.3,2.4,2.6]:
    d=deformed(press/2)
    stop=fixed.intersect(g.box(3.1,50.4,R+5.49,6.0,2.2,bay+3))
    report['stop'][str(press)]=max(0,d.intersect(stop.val()).Volume())
assert report['stop']['2.0']<1e-4 and report['stop']['2.6']>.01

# The recessed tool path must remain usable with the new, smaller surround.
blade=g.box(-3,50,R+.9,12.5,2,.6)
report['tool_access_overlaps_mm3']=[g.volume(blade.translate((0,0,d)),target)
    for d in [0,1,2.1] for target in [case,fixed]]
assert max(report['tool_access_overlaps_mm3'])<1e-6

# Representative low-material pair: identical first hook, receiver, leaf,
# release access and stop in the same print orientation as the full parts.
for name,part in [('case',case),('holder',exported)]:
    crop=part.intersect(g.box(-2.2,-2.2 if mirror else 8.0,R-4.8,32.2 if mirror else 20.2,59.2 if mirror else 49.0,bay+7.9))
    assert crop.val().isValid() and len(crop.solids().vals())==1,name
    path=OUT/f'mount-{name}-coupon.stl'
    cq.exporters.export(g.print_pose(left(crop)),str(path),tolerance=.04,angularTolerance=.1)
    report['coupons'][name]={'file':path.name,'volume_cm3':crop.val().Volume()/1000}
report['passed']=True
(OUT/'mount-verification.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
