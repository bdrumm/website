"""Extract the official 2026-04-11 4.3-inch STEP without scaling it.

These are vendor nominal coordinates, distinct from the owner's measurements.
Rear view: USB left, glass lower-left at (0,0), front glass at z=0.
"""
from pathlib import Path
import json
import cadquery as cq

ROOT = Path(__file__).resolve().parent
REF = ROOT / 'reference'

def main():
    board = cq.importers.importStep(str(REF / 'board.stp'))
    aligned = board.rotate((0,0,0),(1,-1,0),180).translate((57.2,33.4,0))
    solids = aligned.solids().vals()
    rows = []
    for i, s in enumerate(solids):
        b = s.BoundingBox()
        rows.append(dict(index=i, volume_mm3=s.Volume(),
                         bounds=[getattr(b,k) for k in ['xmin','ymin','zmin','xmax','ymax','zmax']]))
    (REF / 'aligned-solid-bounds.json').write_text(json.dumps(rows,indent=2)+'\n')
    cq.exporters.export(aligned, str(REF/'board-aligned.brep'))
    cq.exporters.export(aligned, str(REF/'board-aligned-preview.stl'), tolerance=.12, angularTolerance=.3)
    for row in rows:
        b=row['bounds']; dx,dy,dz=[b[j+3]-b[j] for j in range(3)]
        if row['volume_mm3'] > 40 or (4 < dx < 7 and 4 < dy < 7 and dz > 3):
            print(row['index'],round(row['volume_mm3'],2),[round(n,4) for n in b],flush=True)
    print('solids',len(solids),flush=True)

if __name__ == '__main__': main()
