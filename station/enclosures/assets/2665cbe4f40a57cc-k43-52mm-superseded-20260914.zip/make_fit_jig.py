"""Crop the actual measured cup into a low-material glass/post depth jig."""
import cadquery as cq
import build as b

out=b.ROOT/'battery/exports'
case=cq.importers.importStep(str(out/'case-measurement-prototype.step'))
masks=[b.box(-3,-3,-.5,120,71,1.7)]
for x,y in b.base.MOUNTS:
    masks.append(b.base.cyl(x,y,-.5,12.,16.6))
    lo=-3 if y<32.5 else y
    high=y if y<32.5 else 68
    masks.append(b.box(x-3,lo,-.5,6,high-lo,16.6))
jig=case.intersect(b.base.union_all(masks)).intersect(b.box(-3,-3,-.5,120,71,16.5))
assert jig.val().isValid() and len(jig.solids().vals())==1
for kind in ['battery','switch']:
    out=b.ROOT/kind/'exports'
    cq.exporters.export(b.print_pose(jig),str(out/'fit-jig.stl'),tolerance=.04,angularTolerance=.1)
print('Measured glass/post jig: one connected solid; volume cm3',jig.val().Volume()/1000)
