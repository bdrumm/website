"""Exact exported solids against the new vendor electronics and measured accessories.

Checks nominal placement and all four corner positions of the in-plane PCB
adjustment range; intermediate positions are not exhaustively swept.
Vendor glass is replaced with the measured glass outline. Other 1219 vendor
solids retain their real dimensions and move as one unscaled assembly.
"""
import argparse, hashlib, json
import cadquery as cq
import build as b

parser=argparse.ArgumentParser();parser.add_argument('kind',choices=['battery','switch']);kind=parser.parse_args().kind
g,p=b.configuration(kind);out=b.ROOT/kind/'exports'
case=cq.importers.importStep(str(out/'case-measurement-prototype.step'))
holder=cq.importers.importStep(str(out/'holder.step'))
sf=p['speaker_rear_z']-p['back']+p['speaker_recess']-p['speaker_gasket']-p['speaker'][2]
objects={'case':case,'holder':holder,
         'speaker_full_rectangular_envelope':b.box(*p['speaker_xy'],sf,*p['speaker'])}
if kind=='battery':
    bf=p['battery_rear_z']-p['back']-p['battery_rear_pad']-p['battery'][2]
    objects['battery']=b.box(*p['battery_xy'],bf,*p['battery'])
    objects['insulator']=b.box(*p['battery_xy'],bf-p['battery_insulator'],*p['battery'][:2],p['battery_insulator'])
else:objects['pocket']=b.rounded(22.8,17.,13.5,30.4,31.,10.,2.)
for i,y in enumerate(b.base.USB_Y):
    plug=b.bottom_plug(y) if kind=='battery' else b.bent_cable(y)[0].union(b.bent_cable(y)[1])
    objects['usb_'+str(i)]=b.canonical(plug)
vendor=cq.Shape.importBrep(str(b.ROOT/'reference/board-aligned.brep')).Solids()
board=[s.translate((-.2,-.9,.35)) for s in vendor[1:]]
glass=b.rounded(0,0,0,114,65,1.3,2.5)
report={'revision':p['revision'],'vendor_solids':len(vendor),'vendor_glass_replaced':True,
        'electronic_solids_checked':len(board),'measured_glass_mm':[114,65],
        'source_sha256':hashlib.sha256((b.ROOT/'reference/board.stp').read_bytes()).hexdigest(),
        'case_sha256':hashlib.sha256((out/'case-measurement-prototype.step').read_bytes()).hexdigest(),
        'holder_sha256':hashlib.sha256((out/'holder.step').read_bytes()).hexdigest(),
        'accessory_checks':[],'board_checks':[],'printed_fit_approved':False}
def disjoint(a,b):
    return any(getattr(a,ax+'max')<getattr(b,ax+'min') or getattr(b,ax+'max')<getattr(a,ax+'min') for ax in 'xyz')
safe=b.rounded(-.349,-.349,-1,114.698,65.698,40,2.849)
first_plastic=case.intersect(safe).val().BoundingBox().zmin
report['case_first_interior_plastic_z']=first_plastic
def inside_safe_xy(x,y):
    if not (-.349<=x<=114.349 and -.349<=y<=65.349):return False
    qx=min(max(x,2.5),111.5);qy=min(max(y,2.5),62.5)
    return (x-qx)**2+(y-qy)**2<=2.849**2
for name,obj in objects.items():
    if name not in ['case','holder']:
        for n,target in [('case',case),('holder',holder)]:
            report['accessory_checks'].append(dict(part=name,against=n,overlap_mm3=b.volume(obj,target)))
    report['accessory_checks'].append(dict(part=name,against='measured_glass',overlap_mm3=b.volume(obj,glass)))
    # USB plugs move with their sockets; reference plug geometry is not used
    # as a tolerance obstacle to the same board it is attached to.
    offsets=[(0.,0.)] if name.startswith('usb_') else [(0.,0.),(-.35,-1.),(-.35,1.),(.35,-1.),(.35,1.)]
    for dx,dy in offsets:
        ab=obj.val().BoundingBox();hits=[];tests=0;pruned=0
        for index,s in enumerate(board,1):
            shifted=s.translate((dx,dy,0))
            sb=shifted.BoundingBox()
            if disjoint(ab,sb):pruned+=1;continue
            if name=='case' and sb.zmax<first_plastic-1e-5 and all(inside_safe_xy(x,y) for x in [sb.xmin,sb.xmax] for y in [sb.ymin,sb.ymax]):
                pruned+=1;continue
            tests+=1;vol=max(0.,obj.val().intersect(shifted).Volume())
            if vol>1e-5:
                bb=shifted.BoundingBox()
                hits.append(dict(solid=index,overlap_mm3=vol,bounds=[getattr(bb,k) for k in ['xmin','ymin','zmin','xmax','ymax','zmax']]))
        row=dict(part=name,board_offset_xy_mm=[dx,dy],exact_tests=tests,proven_clear_by_separation=pruned,hits=hits)
        report['board_checks'].append(row)
        print(name,[dx,dy],'hits',hits,flush=True)
report['passed']=not any(r['hits'] for r in report['board_checks']) and all(r['overlap_mm3']<1e-5 for r in report['accessory_checks'])
(out/'independent-clearance-checks.json').write_text(json.dumps(report,indent=2)+'\n')
assert report['passed'],report
