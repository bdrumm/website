"""K43/L43 concealed mount, adapted from the reinforced I/S3 mechanism.

Portrait placement uses the measured 65 x 114 mm glass. Physical spring and
hook sections retain their dimensions. Print each case and holder as a pair.
"""
import cadquery as cq

def install(g):
    R=g.R
    box,rounded,union=g.box,g.rounded,g.union_all
    bottom=getattr(g,'HOLDER_BOTTOM',-15.15)
    W=g.GLASS[1];H=g.GLASS[0];cx=W/2;holder_w=W+2.3
    height=H+1.15-bottom
    right_release=getattr(g,'RELEASE_SIDE','left')=='right'
    def release_pose(obj):
        return obj.mirror('YZ',(cx,0,0)) if right_release else obj

    def receiver_parts():
        adds=[];cuts=[]
        for u,v in g.RECEIVERS:
            # 1.8 mm retaining roof, 1.6 mm side walls and 0.3 mm neck play.
            adds.append(rounded(u-6.2,v-7.6,R-4.8,12.4,11.5,4.8,.65))
            cuts += [rounded(u-4.6,v-6.4,R-4.9,9.2,9.0,3.1,.35),
                     rounded(u-4.6,v-6.0,R-1.9,9.2,4.0,2.0,.25),
                     rounded(u-2.5,v-5.8,R-1.9,5.0,7.8,2.0,.25)]
        # Wider tooth and surrounding ledge, shifted 6 mm up from H/S2.
        adds.append(release_pose(rounded(2.0,45.5,R-2.8,8.2,8.1,2.8,.6)))
        cuts.append(release_pose(rounded(3.5,47.0,R-1.5,5.2,5.1,1.6,.25)))
        return g.canonical(union(adds)),g.canonical(union(cuts))

    def fillet_at_z(part,z,radius,u,v):
        # Round the concave shoulder as well as small outer edges at this
        # plane. A strict selection makes failed/missing fillets visible.
        edges=[e for e in part.val().Edges() if abs(e.BoundingBox().zmin-z)<1e-6
               and abs(e.BoundingBox().zmax-z)<1e-6
               and abs(e.Center().x-u)<2.21 and abs(e.Center().y-v)<1.61]
        assert edges,(z,radius)
        return cq.Workplane(obj=part.val()).newObject(edges).fillet(radius)

    def hook(u,v,bay):
        # The broad boss tapers out toward the plate. No horizontal step on a
        # tiny unsupported pedestal; printed from the wall face upward.
        boss=(cq.Workplane('XY').workplane(offset=R+1.2).center(u,v).rect(10.4,9.2)
              .workplane(offset=bay-1.2).rect(14.0,12.8).loft(combine=True))
        boss=boss.union(box(u-7,v-6.4,R+bay-.05,14,12.8,3.05))
        neck=box(u-2.2,v-1.6,R-2.1,4.4,3.2,3.55)
        cap=box(u-4.2,v-1.6,R-4.1,8.4,3.2,2.0)
        stem=fillet_at_z(neck.union(cap),R-2.1,.20,u,v)
        joined=boss.union(stem)
        joined=fillet_at_z(joined,R+1.2,.75,u,v)
        return joined

    def holder(kind):
        assert kind=='switch'
        bay=g.SWITCH_BAY;z=R+bay
        frame=rounded(-1.15,bottom,z,holder_w,height,3,3.65)
        window=rounded(cx-17.2,g.PLATE_CENTRE-34,z-.1,34.4,68,3.2,2)
        for sign in [-1,1]:
            vals=sorted([g.PLATE_CENTRE+sign*83.34/2,g.PLATE_CENTRE+sign*96.83/2])
            frame=frame.cut(rounded(cx-2.1,vals[0]-2.1,z-.1,4.2,vals[1]-vals[0]+4.2,3.2,2.09))
            head_recess=getattr(g,'MOUNT_HEAD_RECESS',1.1)
            frame=frame.cut(rounded(cx-4.2,vals[0]-4.2,z-.1,8.4,vals[1]-vals[0]+8.4,head_recess+.1,4.19))
        frame=frame.cut(window)
        skirt=rounded(-1.15,bottom,R+.3,holder_w,height,bay-.3,3.65)
        inner=rounded(.65,bottom+1.8,R+.2,holder_w-3.6,height-3.6,bay+.1,1.85)
        frame=frame.union(skirt.cut(inner))
        for v in (71,78,85,92):
            frame=frame.cut(box(-2,v,R+3,4,3,bay-4.5))
        frame=frame.cut(release_pose(rounded(-2,48,R+.3,4,6,5,.4)))
        for u,v in g.RECEIVERS:
            frame=frame.union(hook(u,v,bay))
        for u in (-.2,W-3.6):
            for v in getattr(g,'STANDOFF_POSITIONS',(60,111)):
                frame=frame.union(box(u,v,R,2.8,7,bay+.2))
        # A single broad anchor joins the first mounting boss AND side skirt.
        # The leaf emerges with a root radius instead of a square thin shelf.
        anchor_bottom=getattr(g,'LATCH_ANCHOR_BOTTOM',15.5)
        anchor=rounded(.1,anchor_bottom,R+1.6,getattr(g,'LATCH_ANCHOR_WIDTH',12.0),22.2-anchor_bottom,bay+1.4,.65)
        beam=(cq.Workplane('XY').polyline([(2.1,21.4),(10.1,21.4),
               (9.1,52.05),(3.1,52.05)]).close().extrude(1.6).translate((0,0,R+1.6)))
        paddle=rounded(.5,48.5,R+1.6,8.6,3.55,1.6,.35)
        root=anchor.union(beam).union(paddle)
        edges=[e for e in root.val().Edges() if abs(e.Center().y-22.2)<1e-6
               and abs(e.Center().z-(R+3.2))<1e-6]
        assert edges,'The spring root fillet must exist'
        root=cq.Workplane(obj=root.val()).newObject(edges).fillet(1.2)
        tooth=(cq.Workplane('YZ').polyline([(47.05,R-1.1),(48.0,R-1.1),
                 (52.05,R+1.65),(47.05,R+1.65)]).close().extrude(4.0).translate((4.1,0,0)))
        latch=release_pose(root.union(tooth))
        # Hard stop: 2.3 mm free wallward travel at the paddle's far edge.
        # Attached directly to the plate, behind the free end of the spring.
        stop=rounded(3.2,50.5,R+5.5,5.8,2.0,bay-5.5+3,.4)
        frame=frame.union(release_pose(stop))
        # Side ribs transfer mounting and anchor loads into the skirt. Their
        # sloped upper faces avoid a new horizontal support shelf.
        for side,(u,v) in zip((-1,1),g.RECEIVERS[:2]):
            outer=.60 if side<0 else W-.6
            rib=(cq.Workplane('XZ').polyline([(u,R+1.5),(outer,R+bay-1.5),
                  (outer,R+bay+.2),(u,R+bay+.2)]).close().extrude(2.4)
                 .translate((0,v+1.4,0)))
            frame=frame.union(rib)
        for v in (30,48):
            for u in (W-4.3,W-1.5):
                frame=frame.cut(rounded(u,v,z-.1,1.4,7,3.2,.6))
        # The upper boss spreads to the top skirt but must not project past
        # the inset holder outline. Preserve the concealed mounting envelope.
        frame=frame.intersect(rounded(-1.15,bottom,R-4.2,holder_w,height,bay+7.3,3.65))
        if hasattr(g,'POD_RELIEF'):
            # The closed battery pod replaces a local portion of the skirt.
            # Keep the full 3 mm wall plate and its wide side rail continuous;
            # clearance includes the entire 4 mm insertion/removal stroke.
            frame=frame.cut(box(*g.POD_RELIEF))
        result=frame.union(latch)
        assert result.val().isValid() and len(result.solids().vals())==1
        assert all(abs(a-b)<1e-4 for a,b in zip(g.dims(result)[:2],[holder_w,height]))
        return result,frame,latch,bay

    g.receiver_parts=receiver_parts
    g.holder=holder

METADATA={
    'hook_neck_mm':[4.4,3.2], 'previous_hook_neck_mm':[2.8,2.6],
    'neck_section_area_gain_percent':100*(4.4*3.2/(2.8*2.6)-1),
    'hook_head_mm':[8.4,3.2,2.0], 'receiver_roof_mm':1.8,
    'neck_to_boss_fillet_mm':.75,'head_to_neck_fillet_mm':.2,
    'spring_root_fillet_mm':1.2,'spring_thickness_mm':1.6,
    'spring_width_root_tip_mm':[8,6],'spring_geometric_length_mm':29.85,
    'release_point_portrait_mm':[6.1,51.0], 'release_mm':2.0,
    'hard_stop_travel_mm':2.3,'strength_status':'geometry improved; physical load and fatigue tests pending',
}
