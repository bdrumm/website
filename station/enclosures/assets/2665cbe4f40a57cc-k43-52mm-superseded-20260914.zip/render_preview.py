"""Technical preview from the actual exported CAD meshes; no invented geometry."""
from pathlib import Path
import os,json
os.environ.setdefault('MPLCONFIGDIR','/private/tmp/p4-43-matplotlib')
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d.art3d import Poly3DCollection
import numpy as np
import trimesh

ROOT=Path(__file__).resolve().parent
fig=plt.figure(figsize=(14,7),facecolor='#f4f6f7')
for i,kind in enumerate(['battery','switch']):
    out=ROOT/kind/'exports';d=json.loads((out/'assembly-checks.json').read_text())
    ax=fig.add_subplot(1,2,i+1,projection='3d',computed_zorder=True)
    ax.set_facecolor('#f4f6f7')
    for name,color in [('case','#d6dcdf'),('holder','#5c9299')]:
        path=out/f'{name}-preview.stl'
        if not path.exists():continue
        m=trimesh.load_mesh(path)
        vertices=m.vertices.copy();x=65-vertices[:,1];y=vertices[:,0];z=-vertices[:,2]
        vertices=np.column_stack([x+(84 if name=='holder' else 0),y,z])
        tris=vertices[m.faces]
        normals=np.cross(tris[:,1]-tris[:,0],tris[:,2]-tris[:,0]);norm=np.linalg.norm(normals,axis=1)
        normals/=np.maximum(norm[:,None],1e-15)
        light=np.array([-.3,-.5,1.]);light/=np.linalg.norm(light)
        shade=.66+.34*np.abs(normals@light)
        rgb=np.array(matplotlib.colors.to_rgb(color))
        poly=Poly3DCollection(tris,facecolors=np.clip(shade[:,None]*rgb,0,1),edgecolor='none',linewidth=0,rasterized=True)
        ax.add_collection3d(poly)
    ax.set_xlim(-6,154);ax.set_ylim(-20,120);ax.set_zlim(-34,5)
    ax.set_box_aspect([160,140,39]);ax.view_init(elev=58,azim=-76);ax.set_axis_off()
    ax.set_title(('K43 · Battery wall' if kind=='battery' else 'L43 · Batteryless switch')+'\n'+f"{d['mounted_depth_mm']:.1f}"+' mm mounted',fontsize=16,color='#193747',pad=8)
fig.suptitle('Corrected for the measured 4.3-inch board',fontsize=21,x=.5,y=.98,color='#193747')
fig.text(.5,.06,'Printed parts only · electronics omitted to show the seats and clips · holders separated',ha='center',fontsize=12,color='#425b68')
fig.text(.5,.025,'Glass: 114 × 65 mm    |    Screw pattern: 92 × 50 mm    |    Speaker: 26 × 26 × 5 mm',ha='center',fontsize=12,color='#425b68')
fig.subplots_adjust(left=.015,right=.985,bottom=.12,top=.80,wspace=.04)
fig.savefig(ROOT/'preview.png',dpi=150,facecolor=fig.get_facecolor())
print(ROOT/'preview.png')
