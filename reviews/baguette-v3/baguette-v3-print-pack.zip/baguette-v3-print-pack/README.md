# Baguette holder V3.1 — print prototype

Read engineering-review.md before printing. These files have passed geometry
checks and offline slicing, but have not been physically printed or validated.

1. Print hinge_gap_0p4 and hinge_end. The latter checks the local shell transition. The 0p3 and 0p5 coupons offer tighter/looser alternatives.
2. Print latch_base and latch_lid; test retention and manual release.
3. Print joint_A and joint_B plus all three full-size sleeves; dry-fit and
   check the complete hinge travel before bonding.
4. Print the two full main segments only after the coupons pass.

The five final print objects are in parts/. Keep the supplied upright, open
orientation; print each large segment separately. The default target is a
Bambu H2C, PLA, 0.4 mm nozzle, 0.20 mm layers, 4 walls, 15% infill and 8 mm brim.
The 3MF files contain oriented geometry, not prepared printer jobs or G-code.
The JSON settings record the offline slicing check and can require adaptation
to your installed Bambu Studio version. Inspect supports, especially at latch
undercuts, and exclude them from narrow working hinge bearings.

The center joint uses three internal BONDING joiners: one base sleeve
and two distinct lid keys. Use a filament-compatible adhesive only after dry
fitting. Keep adhesive away from the hinge and the base/lid parting seam.
The keys are intentionally different and cannot be interchanged. Use the
interactive review's Center joint, Separate segments and Cutaway views to
inspect their installed positions.

Review: https://parametric.space/reviews/baguette-v3/
The CAD/preview dimensions and STL units are millimetres. Do not scale coupons
independently. Model color does not select the printing filament.
