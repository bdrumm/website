# Baguette holder V3.7 engineering prototype

Start with `review/engineering-review.md`. Two main print objects join through eight edge tongues and covered blind receiving sockets, with no loose connector or adhesive. All six internal ribs and their support ramps are removed. The smooth direct rim hinge and two short exterior latches remain. The reviewed opening range is 0–100°. Physical print, fit and load tests remain outstanding.

The print pack contains two final STL/3MF objects, seven fit coupons, geometry checks, wall samples and slicer settings. Test the joint coupons first: the center connection has no release feature and is intended to remain locked. The review at https://parametric.space/reviews/baguette-v3/ includes opening, orbit, joint separation and capped hinge and joint cross-sections.

## Rebuild

The recorded environment uses Python 3.14, the versions in `requirements.txt`, Three.js 0.186.0, esbuild 0.28.2, Blender 5.1.2 and Bambu Studio 02.08.02.61.

```sh
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python source/baguette_v3.py
.venv/bin/python source/validate-v3.py
.venv/bin/python source/sample-walls.py
.venv/bin/python source/make-coupons.py
npm install
npm run build:preview
```

Parameters are in `source/baguette_v3.py`. The inherited core is extracted from the unchanged V2 reference. The generator omits the inherited rib-construction loop and removes the legacy hinge filler before adding the hinge, exterior latches and covered center joint. Core parameters are included in its cache key.

`source/build-inline.py` creates the conversation preview. `source/render-review.py` runs in Blender and renders the model and capped manufacturing sections. `source/prepare-slicer.py` resolves the installed macOS H2C / PLA presets. The slicing scripts are offline only; they never operate a printer. Inspect supports around the embedded root channels, covered receiving slots, retaining pockets, latch undercuts and hinge bearings.

Geometry generation resets `output/review.json`. After a change, run validation, `source/run-slicer.py` for fresh slices and `source/collect-slicer.py` to verify their hashes. Follow `AGENTS.md`: inspect the actual CAD renders, record their hashes in `output/design-review.json`, package with `source/package-review.py`, then run `source/prepublish-review.py` before committing or publishing. Publish both matching archives and the preview together.

Legacy references are under `source/legacy/`. The crust is identified there as “Baguette” by Isa Lousberg, CC0/Public Domain.
