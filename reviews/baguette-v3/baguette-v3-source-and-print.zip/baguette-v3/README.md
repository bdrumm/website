# Baguette holder V3.5 engineering prototype

Start with `review/engineering-review.md`. This revision blends the 6.6 mm hinge knuckles into the rear wall with 2 mm radius tangent transitions. The fixed hinge ends continue into the smooth rim profile. Captured 2 mm pins provide the direct hinge, with no support arms. It retains two short shell-contoured latches with 1.6 mm hooks and reinforced catch lips; a hidden exit bevel clears their revised opening path. The reviewed opening range is 0–100°. Physical print and load tests remain outstanding.

The flat 0.20 mm center seam and cleaned rib connections are retained. One base sleeve and two different lid keys form internal bonding joints. Use the supplied keys, dry-fit first, and keep adhesive away from moving surfaces.

The print pack contains five final STL/3MF objects, seven fit coupons, geometry checks, wall samples and slicer settings. No G-code is distributed. The interactive review at https://parametric.space/reviews/baguette-v3/ supports opening, orbit, close-ups, a catch section, cutaway, segment separation and shareable views.

## Rebuild

The recorded environment used Python 3.14, the versions in `requirements.txt`, Three.js 0.186.0, esbuild 0.28.2, Blender 5.1.2 and Bambu Studio 02.08.02.61.

```sh
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python source/baguette_v3.py
.venv/bin/python source/validate-v3.py
.venv/bin/python source/sample-walls.py
.venv/bin/python source/make-coupons.py
npm install
npm run build:preview
```

Parameters are in `source/baguette_v3.py`. The inherited core is extracted from the unchanged V2 source; the generator corrects the rib union and removes its long hinge filler before adding the new hinge, latches and joinery. Change the core cache revision whenever changing this extraction.

Manufacturing exports retain the detailed CAD. Preview meshes use 0.02 mm simplification and 0.001 mm coordinate rounding. `source/build-inline.py` embeds the compressed preview for conversation review. `source/render-review.py` runs in Blender and renders the same display model.

`source/prepare-slicer.py` resolves the installed macOS H2C / PLA presets. Adapt its application path on other systems. Slice each generated segment separately in its supplied upright 100° open orientation. The checked settings use four walls, 15% infill, an 8 mm brim, automatic supports, 0.4 mm nozzle and 0.20 mm layers. Inspect support placement before printing.

Geometry generation resets `output/review.json`; rerun validation and fresh offline slices after any change. `source/collect-slicer.py` reads the resulting `output/slicer/segment-A/plate_1.gcode` and segment-B headers, records estimates and input STL hashes, and never operates a printer. `source/package-review.py` packages only the final objects and listed coupons.

Legacy references are under `source/legacy/`. The reference crust is identified there as “Baguette” by Isa Lousberg, CC0/Public Domain.

Before committing or publishing a geometry change, follow `AGENTS.md`. Run `source/run-slicer.py` for fresh offline slices, `source/collect-slicer.py` to verify their provenance, and `source/prepublish-review.py` after packaging. Inspect actual geometry renders and record their hashes in `output/design-review.json`; the gate requires matching review evidence.
