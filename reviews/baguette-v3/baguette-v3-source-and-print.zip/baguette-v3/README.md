# Baguette holder V3.14 engineering prototype

Start with `review/engineering-review.md`. Two main print objects join through eight edge tongues and covered blind receiving sockets, with no loose connector or adhesive. All six internal ribs and their support ramps are removed. Thin shell areas are reinforced, the direct hinge is thicker inward with a 3 mm pin, and the two exterior latches have rounded corners, smoothly blended finger catches and shallow fingernail recesses underneath. Exposed latch-mount and hinge entrance edges are eased. The latch side openings cut through the raised shell band without overhanging bridges. The outer band now blends smoothly into the shell and latch face instead of ending in square ledges. Strap eyes have rounded edges and coved roots, with their tails tapered into the actual narrowing shell to remove the raised end stub. Each grip includes a small fingernail scoop in its underside. Half A has solid, unrecessed snap roots and the attachment blends into the inner shell over 30 mm. The reviewed opening range is 0–100°. Physical print, fit and load tests remain outstanding.

The print pack contains a combined three-plate 3MF project, two individual final STL/3MF objects, eight fit coupons, geometry checks, wall samples, sliced-path review and slicer settings. Test the joint coupons first: the center connection has no release feature and is intended to remain locked. The review at https://parametric.space/reviews/baguette-v3/ includes opening, orbit, joint separation and capped hinge and joint cross-sections.

## Rebuild

The recorded environment uses Python 3.14, the versions in `requirements.txt`, Three.js 0.186.0, esbuild 0.28.2, Blender 5.1.2 and Bambu Studio 02.08.02.61.

```sh
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python source/baguette_v3.py
.venv/bin/python source/validate-v3.py
.venv/bin/python source/sample-walls.py
.venv/bin/python source/make-coupons.py
npm install
npm run build:preview
```

Parameters are in `source/baguette_v3.py`. The inherited core is extracted from the unchanged V2 reference. The generator omits the inherited rib-construction loop and removes the legacy hinge filler before adding the hinge, exterior latches and covered center joint. The guarded cavity and smooth joint transition use source/joint-profile.json and source/joint-blend.py.txt. Their contents and core parameters are included in the cache key and final design-review hashes.

`source/build-inline.py` creates the conversation preview. `source/render-review.py` runs in Blender and renders the model and capped manufacturing sections. `source/prepare-slicer.py` resolves the installed macOS H2C / PLA presets. The slicing scripts are offline only; they never operate a printer. Inspect supports around the covered receiving slots, retaining pockets, latch undercuts and hinge bearings.

Geometry generation resets `output/review.json`. After a change, run validation, `source/run-slicer.py` for fresh slices and `source/collect-slicer.py` to verify their hashes. Run source/review-sliced-walls.py and inspect its actual extrusion-path plots at the former thin-wall stations. Follow `AGENTS.md`: inspect the actual CAD renders, record their hashes in `output/design-review.json`, package with `source/package-review.py`, then run `source/prepublish-review.py` before committing or publishing. Publish both matching archives and the preview together.

Legacy references are under `source/legacy/`. The crust is identified there as “Baguette” by Isa Lousberg, CC0/Public Domain.
