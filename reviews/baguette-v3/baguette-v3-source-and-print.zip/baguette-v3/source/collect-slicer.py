from pathlib import Path
import json,re,hashlib
ROOT=Path(__file__).resolve().parents[1]
report=json.loads((ROOT/'output/review.json').read_text());sliced={}
for side in ('A','B'):
 path=ROOT/'output/slicer'/f'segment-{side}'/'plate_1.gcode'
 provenance=json.loads((path.parent/'slice-provenance.json').read_text())
 assert provenance['input_stl_sha256']==hashlib.sha256((ROOT/'output'/f'baguette_v3_segment_{side}.stl').read_bytes()).hexdigest()
 assert provenance['output_gcode_sha256']==hashlib.sha256(path.read_bytes()).hexdigest()
 for name,digest in provenance['settings_sha256'].items():assert digest==hashlib.sha256((ROOT/'output/slicer'/f'{name}.json').read_bytes()).hexdigest()
 with path.open() as f:head=''.join(f.readline() for _ in range(15))
 sliced[side]={'input_stl_sha256':hashlib.sha256((ROOT/'output'/f'baguette_v3_segment_{side}.stl').read_bytes()).hexdigest(),'status':'offline slice completed','slicer':'Bambu Studio 02.08.02.61','estimated_time':re.search(r'total estimated time: (.+)',head)[1],'filament_g':float(re.search(r'total filament weight \[g\] : (.+)',head)[1]),'max_z_mm':float(re.search(r'max_z_height: (.+)',head)[1]),'supports_enabled':True,'sent_to_printer':False,'provenance':provenance}
report['slicing']=sliced;(ROOT/'output/review.json').write_text(json.dumps(report,indent=2));print(sliced)
