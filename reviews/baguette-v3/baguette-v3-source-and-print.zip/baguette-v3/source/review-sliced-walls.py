"""Inspect actual extrusion paths at the former thin-wall stations. Offline only."""
from pathlib import Path
from collections import defaultdict
import hashlib,json,math,re
from PIL import Image,ImageDraw,ImageFont
from shapely.geometry import LineString
from shapely.ops import unary_union
ROOT=Path(__file__).resolve().parents[1]
TARGETS={'A':[(55.6,-43.6),(162.0,-150.0),(180.0,-168.0)],'B':[(47.6,43.7),(153.9,150.0),(172.0,168.1)]}
MODEL_FEATURES={'Outer wall','Inner wall','Gap infill','Internal solid infill','Top surface','Bridge','Overhang wall','Sparse infill'}
number=re.compile(r'([XYZEFIJK])(-?(?:\d+(?:\.\d*)?|\.\d+))')
records=[];panels=[]
for side,targets in TARGETS.items():
 path=ROOT/'output/slicer'/f'segment-{side}'/'plate_1.gcode'
 x=y=z=last_e=0.;layer_z=0.;width=.42;feature='';relative_e=True;absolute_xyz=True;active=False
 layers=defaultdict(list)
 with path.open() as f:
  for raw in f:
   line=raw.strip()
   if line.startswith('; Z_HEIGHT:'):
    layer_z=float(line.split(':',1)[1]);active=any(abs(layer_z-t)<.36 for t,_ in targets)
    if layer_z>max(t for t,_ in targets)+1:break
   elif line.startswith('; FEATURE:'):feature=line.split(':',1)[1].strip()
   elif line.startswith('; LINE_WIDTH:'):width=float(line.split(':',1)[1])
   if line.startswith('M83'):relative_e=True
   elif line.startswith('M82'):relative_e=False
   elif line=='G90':absolute_xyz=True
   elif line=='G91':absolute_xyz=False
   elif line.startswith('G92'):
    vals={k:float(v) for k,v in number.findall(line.split(';')[0])}
    if 'E' in vals:last_e=vals['E']
   elif line.startswith(('G0 ','G1 ','G2 ','G3 ')):
    vals={k:float(v) for k,v in number.findall(line.split(';')[0])}
    nx=(vals.get('X',x) if absolute_xyz else x+vals.get('X',0));ny=(vals.get('Y',y) if absolute_xyz else y+vals.get('Y',0));nz=(vals.get('Z',z) if absolute_xyz else z+vals.get('Z',0))
    e=vals.get('E',0 if relative_e else last_e);de=e if relative_e else e-last_e
    if active and de>0 and feature in MODEL_FEATURES and abs(nz-layer_z)<.002 and math.hypot(nx-x,ny-y)>.0001:
     points=[(x,y),(nx,ny)]
     if line.startswith(('G2 ','G3 ')) and ('I' in vals or 'J' in vals):
      cx=x+vals.get('I',0);cy=y+vals.get('J',0);rad=math.hypot(x-cx,y-cy);a0=math.atan2(y-cy,x-cx);a1=math.atan2(ny-cy,nx-cx)
      da=(a1-a0)%(2*math.pi)
      if line.startswith('G2 '):da-=2*math.pi
      steps=max(2,int(abs(da)*rad/.15)+1);points=[(cx+rad*math.cos(a0+da*i/steps),cy+rad*math.sin(a0+da*i/steps)) for i in range(steps+1)]
     layers[round(layer_z,3)].append({'points':points,'width':width,'feature':feature})
    x,y,z=nx,ny,nz;last_e=e
 for target,source_y in targets:
  available=[zz for zz,ss in layers.items() if abs(zz-target)<.36 and sum(LineString(s['points']).length for s in ss if s['feature']=='Outer wall')>200]
  assert available,(side,target,'No complete outer-wall layer found')
  zz=min(available,key=lambda a:abs(a-target));segments=layers[zz]
  lengths={name:sum(LineString(s['points']).length for s in segments if s['feature']==name) for name in MODEL_FEATURES}
  assert lengths['Outer wall']>200 and lengths['Inner wall']>200
  walls=[s for s in segments if s['feature'] in {'Outer wall','Inner wall','Overhang wall'}]
  footprints=unary_union([LineString(s['points']).buffer(s['width']/2+.015,quad_segs=3) for s in segments])
  pieces=list(footprints.geoms) if footprints.geom_type=='MultiPolygon' else [footprints]
  records.append({'segment':side,'source_y_mm':source_y,'print_z_mm':zz,'feature':'fingernail recess and hinge' if abs(source_y)==150 else 'former thin wall','expected_material_regions':3 if abs(source_y)==150 else 2,'outer_wall_length_mm':lengths['Outer wall'],'inner_wall_length_mm':lengths['Inner wall'],'minimum_wall_line_width_mm':min(s['width'] for s in walls),'planned_bead_regions_over_1_mm2':sum(p.area>1 for p in pieces),'gcode_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'supports_hidden_in_plot':True})
  panels.append((f'{side} / print Z {zz:.2f} mm',segments))
scale=2;W,H=1440,1460;im=Image.new('RGB',(W*scale,H*scale),'#eef0f2');draw=ImageDraw.Draw(im)
try:font=ImageFont.truetype('/System/Library/Fonts/Supplemental/Arial.ttf',24*scale);small=ImageFont.truetype('/System/Library/Fonts/Supplemental/Arial.ttf',17*scale)
except OSError:font=ImageFont.load_default(size=24*scale);small=ImageFont.load_default(size=17*scale)
colors={'Outer wall':'#22384b','Inner wall':'#b68139','Overhang wall':'#536c84','Gap infill':'#cc9651','Internal solid infill':'#c9b398','Top surface':'#c9b398','Bridge':'#bbad97','Sparse infill':'#cac8c3'}
for i,(title,segments) in enumerate(panels):
 col=i%2;row=i//2;ox=col*720;oy=row*460
 draw.text(((ox+30)*scale,(oy+22)*scale),title,font=font,fill='#22384b')
 pts=[p for s in segments for p in s['points']];minx=min(p[0] for p in pts);maxx=max(p[0] for p in pts);miny=min(p[1] for p in pts);maxy=max(p[1] for p in pts)
 zoom=min(650/(maxx-minx),365/(maxy-miny));cx=(minx+maxx)/2;cy=(miny+maxy)/2
 for s in sorted(segments,key=lambda s:s['feature']=='Outer wall'):
  coords=[((ox+360+(x-cx)*zoom)*scale,(oy+245-(y-cy)*zoom)*scale) for x,y in s['points']]
  draw.line(coords,fill=colors.get(s['feature'],'#cac8c3'),width=max(1,round(s['width']*zoom*scale)),joint='curve')
draw.text((30*scale,1398*scale),'Actual sliced extrusion paths / dark: outer walls / gold: inner walls / supports hidden',font=small,fill='#22384b')
im.resize((W,H),Image.Resampling.LANCZOS).save(ROOT/'review/slice-walls.png')
result={'revision':'V3.13','scope':'Six complete sliced cross-sections at former thin-wall stations and the new fingernail recesses. Planned extrusion paths, not a physical print or all-layer defect proof. White seam markers are not part of this plot.','sections':records}
(ROOT/'output/slice-wall-review.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
