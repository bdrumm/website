"""Lossless byte-plane packing for the embedded GLB; geometry is unchanged."""
import gzip,json,struct

def layout(blob):
    size=struct.unpack_from('<I',blob,12)[0]
    meta=json.loads(blob[20:20+size]);start=28+size
    width={5120:1,5121:1,5122:2,5123:2,5125:4,5126:4}
    components={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4,'MAT4':16}
    views={a['bufferView']:meta['bufferViews'][a['bufferView']].get('byteStride',width[a['componentType']]*components[a['type']]) for a in meta['accessors'] if 'bufferView' in a}
    return [(start+meta['bufferViews'][i].get('byteOffset',0),meta['bufferViews'][i]['byteLength']//stride,stride) for i,stride in views.items()]

def pack(blob):
    out=bytearray(blob)
    for start,count,stride in layout(blob):
        chunk=blob[start:start+count*stride]
        delta=chunk[:stride]+bytes((a-b)%256 for a,b in zip(chunk[stride:],chunk[:-stride]))
        out[start:start+count*stride]=b''.join(delta[j::stride] for j in range(stride))
    return gzip.compress(out,compresslevel=9,mtime=0)

def unpack(packed):
    blob=gzip.decompress(packed);out=bytearray(blob)
    for start,count,stride in layout(blob):
        for j in range(stride):
            value=0
            for i in range(count):
                value=(value+blob[start+j*count+i])%256
                out[start+i*stride+j]=value
    return bytes(out)
