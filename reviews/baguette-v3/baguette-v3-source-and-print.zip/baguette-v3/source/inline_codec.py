"""Lossless word-delta, zigzag and byte-plane packing for the embedded GLB."""
import gzip,json,struct

def layout(blob):
    size=struct.unpack_from('<I',blob,12)[0]
    meta=json.loads(blob[20:20+size]);start=28+size
    width={5120:1,5121:1,5122:2,5123:2,5125:4,5126:4}
    components={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4,'MAT4':16}
    views={a['bufferView']:(meta['bufferViews'][a['bufferView']].get('byteStride',width[a['componentType']]*components[a['type']]),width[a['componentType']]) for a in meta['accessors'] if 'bufferView' in a}
    return [(start+meta['bufferViews'][i].get('byteOffset',0),meta['bufferViews'][i]['byteLength']//stride,stride,w) for i,(stride,w) in views.items()]

def pack(blob):
    out=bytearray(blob)
    for start,count,stride,w in layout(blob):
        chunk=blob[start:start+count*stride];delta=bytearray(len(chunk));bits=w*8;mask=(1<<bits)-1
        for j in range(0,stride,w):
            previous=0
            for i in range(count):
                at=i*stride+j;value=int.from_bytes(chunk[at:at+w],'little')
                d=(value-previous)&mask;previous=value
                d=((d<<1)^(-(d>>(bits-1))))&mask
                delta[at:at+w]=d.to_bytes(w,'little')
        out[start:start+len(chunk)]=b''.join(delta[j::stride] for j in range(stride))
    return gzip.compress(out,compresslevel=9,mtime=0)

def unpack(packed):
    blob=gzip.decompress(packed);out=bytearray(blob)
    for start,count,stride,w in layout(blob):
        mask=(1<<(8*w))-1
        for j in range(0,stride,w):
            value=0
            for i in range(count):
                d=sum(blob[start+(j+k)*count+i]<<(8*k) for k in range(w))
                d=(d>>1)^(-(d&1));value=(value+d)&mask
                at=start+i*stride+j;out[at:at+w]=value.to_bytes(w,'little')
    return bytes(out)
