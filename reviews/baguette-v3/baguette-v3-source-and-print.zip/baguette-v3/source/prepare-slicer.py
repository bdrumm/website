from pathlib import Path
import json
ROOT=Path(__file__).resolve().parents[1]
profiles=Path('/Applications/BambuStudio.app/Contents/Resources/profiles/BBL')
files={}
for p in profiles.rglob('*.json'):
 try:
  d=json.loads(p.read_text());name=d.get('name')
  if name:files[name]=(p,d)
 except (ValueError,UnicodeError):pass

def flatten(name):
 p,d=files[name];out={}
 if d.get('inherits'):out.update(flatten(d['inherits']))
 out.update(d);out.pop('inherits',None)
 return out

out=ROOT/'output/slicer';out.mkdir(exist_ok=True)
for name,dst in [('Bambu Lab H2C 0.4 nozzle','machine'),('0.20mm Standard @BBL H2C','process'),('Generic PLA @BBL H2C 0.4 nozzle','filament')]:
 d=flatten(name)
 if dst=='process':
  d.update({'wall_loops':'4','sparse_infill_density':'15%','brim_type':'outer_only','brim_width':'8','enable_support':'1','support_type':'normal(auto)','support_on_build_plate_only':'0','support_threshold_angle':'25','support_top_z_distance':'0.2','support_bottom_z_distance':'0.2','support_object_xy_distance':'0.5'})
 (out/f'{dst}.json').write_text(json.dumps(d,indent=2))
