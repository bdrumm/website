from pathlib import Path
import argparse,json,numpy as np,trimesh
ROOT=Path(__file__).resolve().parents[1]
parser=argparse.ArgumentParser();parser.add_argument("--prefix",default="");parser.add_argument("--output",default="wall-samples.json");args=parser.parse_args()
results={}
params=json.loads((ROOT/'output/review.json').read_text())['parameters']
for name in ('base_A','base_B','lid_A','lid_B'):
 m=trimesh.load_mesh(ROOT/'output'/f'{args.prefix}{name}.stl',process=True)
 centers=m.triangles_center;normal=m.face_normals;radial=centers.copy();radial[:,1]=0
 radial/=np.maximum(np.linalg.norm(radial,axis=1)[:,None],1e-10)
 valid=(np.einsum('ij,ij->i',radial,normal)>.15)&(abs(centers[:,1])<295)&(abs(centers[:,2])>12)&(centers[:,0]>-31)&(abs(centers[:,1]+4)>22)&(m.area_faces>.05)
 ids=np.flatnonzero(valid);ids=ids[np.linspace(0,len(ids)-1,min(2500,len(ids))).astype(int)]
 origins=centers[ids]-normal[ids]*.002;dirs=-normal[ids]
 tris=m.triangles;lower=tris.min(axis=1);upper=tris.max(axis=1);found=[];hits=[]
 for face_id,origin,direction in zip(ids,origins,dirs):
  end=origin+direction*12;lo=np.minimum(origin,end)-.001;hi=np.maximum(origin,end)+.001
  candidate=tris[np.all(upper>=lo,axis=1)&np.all(lower<=hi,axis=1)]
  e1=candidate[:,1]-candidate[:,0];e2=candidate[:,2]-candidate[:,0]
  pvec=np.cross(np.broadcast_to(direction,e2.shape),e2);det=np.einsum('ij,ij->i',e1,pvec)
  inv=np.divide(1,det,out=np.zeros_like(det),where=abs(det)>1e-10)
  tv=origin-candidate[:,0];u=np.einsum('ij,ij->i',tv,pvec)*inv;q=np.cross(tv,e1)
  vv=q@direction*inv;tt=np.einsum('ij,ij->i',e2,q)*inv
  valid=(abs(det)>1e-10)&(u>=-1e-8)&(vv>=-1e-8)&(u+vv<=1+1e-8)&(tt>.0001)&(tt<=12)
  if valid.any():
   distance=float(tt[valid].min())+.002;found.append(distance);hits.append({"thickness":distance,"center":centers[face_id].tolist(),"normal":normal[face_id].tolist(),"face":int(face_id),"region":"hinge trim" if centers[face_id][0]<-25 and centers[face_id][2]<14 else "latch tongue" if name.startswith("lid") and centers[face_id][2]<0 and centers[face_id][0]>20 else "crust"})
 distances=np.array(found)
 crust_distances=np.array([h['thickness'] for h in hits if h['region']=='crust'])
 region_minima={region:min(h['thickness'] for h in hits if h['region']==region) for region in {h['region'] for h in hits}}
 results[name]={'region_minimum_mm':region_minima,'crust_minimum_mm':float(crust_distances.min()),'crust_samples':len(crust_distances),'lowest_samples':sorted(hits,key=lambda h:h['thickness'])[:30],'samples':len(distances),'minimum_mm':float(distances.min()),'p05_mm':float(np.quantile(distances,.05)),'median_mm':float(np.median(distances)),'scope':'Normal ray samples of outward radial faces. Crust statistics exclude the left rim below 14 mm. Hinge-trim samples are reported separately. Sampling omits the new latch tongues, end tips, center joint, central parting seam, and small faces. Not a global minimum-wall proof.'}
assert min(r['crust_minimum_mm'] for r in results.values())>=2.4
print(json.dumps(results,indent=2));(ROOT/'output'/args.output).write_text(json.dumps(results,indent=2))
