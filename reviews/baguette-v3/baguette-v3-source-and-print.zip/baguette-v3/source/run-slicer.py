"""Offline only. Hash each input before slicing and bind it to the resulting G-code."""
from pathlib import Path
import hashlib,json,subprocess
ROOT=Path(__file__).resolve().parents[1]
settings=ROOT/'output/slicer'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for side in ('A','B'):
 dest=settings/f'segment-{side}';dest.mkdir(exist_ok=True)
 stl=ROOT/'output'/f'baguette_v3_segment_{side}.stl'
 gcode=dest/'plate_1.gcode'
 job={'input_stl_sha256':sha(stl),'settings_sha256':{n:sha(settings/f'{n}.json') for n in ('machine','process','filament')}}
 if gcode.exists():gcode.unlink()
 args=['/Applications/BambuStudio.app/Contents/MacOS/BambuStudio','--datadir','/private/tmp/baguette-v3-bambu-data','--debug','2','--load-settings',str(settings/'machine.json')+';'+str(settings/'process.json'),'--load-filaments',str(settings/'filament.json'),'--slice','0','--arrange','1','--orient','0','--outputdir',str(dest),str(stl)]
 with (dest/'slice.log').open('w') as log:subprocess.run(args,stdout=log,stderr=subprocess.STDOUT,check=True)
 assert gcode.exists() and sha(stl)==job['input_stl_sha256']
 job['output_gcode_sha256']=sha(gcode)
 (dest/'slice-provenance.json').write_text(json.dumps(job,indent=2))
 print('Fresh offline slice complete:',side,flush=True)
