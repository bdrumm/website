"""Fit coupons cropped from the final manufacturing exports."""
from pathlib import Path
import json,sys,numpy as np,trimesh
sys.path.insert(0,str(Path(__file__).resolve().parent))
import baguette_v3 as v
from baguette_case import box,to_trimesh,write_3mf
ROOT=v.ROOT;out=ROOT/'output/coupons';out.mkdir(exist_ok=True)
def read(name):
 m=trimesh.load_mesh(ROOT/'output'/f'{name}.stl')
 return v.Manifold(v.Mesh(m.vertices.astype(np.float32),m.faces.astype(np.uint32)))
parts={n:read(n) for n in ('base_A','base_B','lid_A','lid_B')}
report=json.loads((ROOT/'output/review.json').read_text());coupons={}
a=v.P['hinge_axis_x'];z=v.P['hinge_axis_z'];cy=v.P['hinge_centers'][1]
clip=box(a-17,cy-19,-10,a+8,cy+19,22)
b=v.clean(parts['base_B']^clip);l=v.clean(parts['lid_B']^clip)
for gap in (.3,.4,.5):
 # The default reproduces the exact released production bearing. Variants
 # use circular test bores to bracket the chosen minimum radial clearance.
 moving=l
 if gap!=.4:
  moving=v.clean((moving+v.y_cyl(v.P['pin_radius']+.6,cy-8,cy+8,a,z))-v.y_cyl(v.P['pin_radius']+gap,cy-8,cy+8,a,z))
 coupons[f'hinge_gap_{str(gap).replace(".","p")}']=v.print_pose(v.clean(b+v.open_lid(moving,a,v.P['max_open_angle'])),'B')
f=report['latches'][1];x=f['x'];y=f['y'];clip=box(30,y-14,-16,x+4,y+14,16)
for name in ('base','lid'):
 coupons[f'latch_{name}']=v.print_pose(v.clean(parts[name+'_B']^clip),'B')
for side in ('A','B'):
 printed=read('baguette_v3_segment_'+side)
 coupons[f'joint_{side}']=v.clean(printed^box(-200,-150,0,200,150,32))
coupons['strap_eye']=v.print_pose(v.clean(parts['base_B']^box(30,233,-15,75,301,-.15)),'B')
result={}
for name,solid in coupons.items():
 result[name]=v.metrics(solid);assert result[name]['watertight'] and result[name]['consistent_winding']
 assert result[name]['components']==(2 if name.startswith(('hinge','joint')) else 1),(name,result[name]['components'])
 mesh=to_trimesh(solid);mesh.export(out/f'{name}.stl');write_3mf(out/f'{name}.3mf',[(name,mesh)])
 print(name,result[name]['components'],result[name]['size_mm'])
(out/'coupons.json').write_text(json.dumps(result,indent=2))

# Review-only closed sections, excluded from the printable coupon manifest.
for name in ('base','lid'):
 section=v.clean(parts[name+'_B']^box(30,136,-16,50,150,16))
 to_trimesh(section).export(ROOT/'output'/f'latch-section-{name}.stl')

# Review-only transverse hinge section, taken from manufacturing solids.
for name in ('base','lid'):
 section=v.clean(parts[name+'_B']^box(a-7,cy,-12,a+11,cy+5,12))
 to_trimesh(section).export(ROOT/'output'/f'hinge-section-{name}.stl')

sections=[]
for name in ('base','lid'):
 mesh=trimesh.load_mesh(ROOT/'output'/f'hinge-section-{name}.stl')
 sections.append({'name':name+'_hinge_section','reviewSection':True,'sectionType':'hinge','vertices':np.round(mesh.vertices[:,[1,2,0]],5).tolist(),'triangles':mesh.faces.tolist()})
# A capped section through one built-in lower snap, aligned for inspection.
for side in ('A','B'):
 section=v.clean(parts['base_'+side].rotate([0,245,0])^box(25,v.old.JOINT_Y-10,-4,50,v.old.JOINT_Y+21,0))
 mesh=to_trimesh(section);mesh.export(ROOT/'output'/f'joint-section-{side}.stl')
 sections.append({'name':'joint_section_'+side,'reviewSection':True,'sectionType':'joint','vertices':np.round(mesh.vertices[:,[1,0,2]],5).tolist(),'triangles':mesh.faces[:,[0,2,1]].tolist()})
(ROOT/'output/hinge-sections.json').write_text(json.dumps(sections,separators=(',',':')))
