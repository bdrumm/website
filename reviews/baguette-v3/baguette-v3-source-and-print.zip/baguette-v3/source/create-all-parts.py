"""Combine reviewed exports into a three-plate, unsliced Bambu Studio project."""
from pathlib import Path
from copy import deepcopy
import hashlib,json,subprocess,xml.etree.ElementTree as ET,zipfile
import numpy as np
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output';TMP=OUT/'combined';TMP.mkdir(exist_ok=True)
DATA=Path('/private/tmp/baguette-all-parts-config');DATA.mkdir(exist_ok=True)
NS='http://schemas.microsoft.com/3dmanufacturing/core/2015/02';PN='http://schemas.microsoft.com/3dmanufacturing/production/2015/06'
ET.register_namespace('',NS);ET.register_namespace('p',PN)
q=lambda name:'{'+NS+'}'+name
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
names=['segment_A','segment_B']+list(json.loads((OUT/'coupons/coupons.json').read_text()))
paths={n:OUT/(('baguette_v3_'+n+'.3mf') if n.startswith('segment_') else 'coupons/'+n+'.3mf') for n in names}
cli='/Applications/BambuStudio.app/Contents/MacOS/BambuStudio'
def run(args,log):
 with (TMP/log).open('w') as f:subprocess.run([cli,'--datadir',str(DATA),*args],stdout=f,stderr=subprocess.STDOUT,check=True)
run(['--load-settings',str(OUT/'slicer/machine.json')+';'+str(OUT/'slicer/process.json'),'--load-filaments',str(OUT/'slicer/filament.json'),'--arrange','0','--orient','0','--outputdir',str(TMP),'--export-3mf','seed.3mf',*[str(paths[n]) for n in names]],'seed.log')
with zipfile.ZipFile(TMP/'seed.3mf') as z:data={n:z.read(n) for n in z.namelist() if not n.endswith('.png')}
model=ET.fromstring(data['3D/3dmodel.model']);config=ET.fromstring(data['Metadata/model_settings.config'])
objects={o.attrib['id']:o for o in model.find(q('resources')).findall(q('object'))};items={i.attrib['objectid']:i for i in model.find(q('build'))}
record=[];assignments={1:[],2:[],3:[]};origin={1:(0.,0.),2:(396.,0.),3:(0.,-384.)}
centers={'segment_A':(165,160),'segment_B':(165,160),'joint_A':(85,90),'joint_B':(244,90),'hinge_gap_0p3':(30,205),'hinge_gap_0p4':(85,205),'hinge_gap_0p5':(140,205),'latch_base':(195,205),'latch_lid':(235,205),'strap_eye':(285,225)}
expected={}
for object_config in config.findall('object'):
 oid=object_config.attrib['id'];name=next(m.attrib['value'] for m in object_config.findall('metadata') if m.attrib.get('key')=='name');assert name in paths,name
 with zipfile.ZipFile(paths[name]) as z:source=ET.fromstring(z.read('3D/3dmodel.model'))
 mesh=source.find(q('resources')).find(q('object')).find(q('mesh'));vertices=np.array([[float(v.attrib[k]) for k in ('x','y','z')] for v in mesh.find(q('vertices'))]);lo=vertices.min(axis=0);hi=vertices.max(axis=0)
 component=objects[oid].find(q('components')).find(q('component'));assert component.attrib.get('transform','1 0 0 0 1 0 0 0 1 0 0 0')=='1 0 0 0 1 0 0 0 1 0 0 0'
 member=component.attrib['{'+PN+'}path'].lstrip('/');child=ET.fromstring(data[member]);mesh_obj=next(o for o in child.find(q('resources')).findall(q('object')) if o.attrib['id']==component.attrib['objectid']);mesh_obj.remove(mesh_obj.find(q('mesh')));mesh_obj.append(deepcopy(mesh));data[member]=ET.tostring(child,encoding='utf-8',xml_declaration=True)
 plate=1 if name=='segment_A' else 2 if name=='segment_B' else 3;ox,oy=origin[plate];cx,cy=centers[name];delta=np.array([ox+cx-(lo[0]+hi[0])/2,oy+cy-(lo[1]+hi[1])/2,-lo[2]])
 items[oid].set('transform','1 0 0 0 1 0 0 0 1 '+' '.join(f'{v:.9f}' for v in delta));items[oid].set('printable','1');assignments[plate].append(oid)
 bbox=np.array([lo+delta,hi+delta]);local=bbox-np.array([ox,oy,0]);assert np.all(local[0,:2]>=8) and np.all(local[1,:2]<=[322,312]) and local[1,2]<=325
 expected[name]=(vertices,mesh,plate,delta);record.append({'name':name,'plate':plate,'input_3mf_sha256':sha(paths[name]),'bounds_on_plate_mm':local.tolist(),'triangles':len(mesh.find(q('triangles')))})
assert set(expected)==set(names)
for plate in config.findall('plate'):config.remove(plate)
for index,title in [(1,'Half A - connection down'),(2,'Half B - connection down'),(3,'Fit test pieces')]:
 plate=ET.SubElement(config,'plate')
 for key,value in [('plater_id',str(index)),('plater_name',title),('locked','false'),('filament_map_mode','Auto For Flush'),('gcode_file','')]:ET.SubElement(plate,'metadata',key=key,value=value)
 for oid in assignments[index]:
  instance=ET.SubElement(plate,'model_instance')
  for key,value in [('object_id',oid),('instance_id','0'),('identify_id',oid)]:ET.SubElement(instance,'metadata',key=key,value=value)
for key,value in [('Title','Baguette holder V3.18 - all parts'),('Description','Two reviewed main halves and eight fit coupons on three plates. Unsliced H2C project; reviewed connection-down orientations are preserved.')]:
 meta=next((m for m in model.findall(q('metadata')) if m.attrib.get('name')==key),None)
 if meta is None:meta=ET.SubElement(model,q('metadata'),name=key)
 meta.text=value
for plate in (1,2,3):
 boxes=[r['bounds_on_plate_mm'] for r in record if r['plate']==plate]
 for i,a in enumerate(boxes):
  for b in boxes[i+1:]:assert any(a[1][j]+16<=b[0][j] or b[1][j]+16<=a[0][j] for j in (0,1)),'Eight-mm brims would overlap'
data['3D/3dmodel.model']=ET.tostring(model,encoding='utf-8',xml_declaration=True);data['Metadata/model_settings.config']=ET.tostring(config,encoding='utf-8',xml_declaration=True)
with zipfile.ZipFile(TMP/'arranged.3mf','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for n,b in data.items():z.writestr(n,b)
run(['--arrange','0','--orient','0','--outputdir',str(OUT),'--export-3mf','baguette_v3_all_parts.3mf',str(TMP/'arranged.3mf')],'roundtrip.log')
final=OUT/'baguette_v3_all_parts.3mf'
with zipfile.ZipFile(final) as z:
 assert z.testzip() is None
 cfg=ET.fromstring(z.read('Metadata/model_settings.config'));assert len(cfg.findall('object'))==10 and len(cfg.findall('plate'))==3
 root=ET.fromstring(z.read('3D/3dmodel.model'));obj={o.attrib['id']:o for o in root.find(q('resources')).findall(q('object'))};build={i.attrib['objectid']:i for i in root.find(q('build'))}
 membership={}
 for p in cfg.findall('plate'):
  pn=int(next(m.attrib['value'] for m in p.findall('metadata') if m.attrib.get('key')=='plater_id'))
  for inst in p.findall('model_instance'):membership[next(m.attrib['value'] for m in inst.findall('metadata') if m.attrib.get('key')=='object_id')]=pn
 for o in cfg.findall('object'):
  oid=o.attrib['id'];name=next(m.attrib['value'] for m in o.findall('metadata') if m.attrib.get('key')=='name');source,source_mesh,plate,delta=expected[name];assert membership[oid]==plate
  comp=obj[oid].find(q('components')).find(q('component'));child=ET.fromstring(z.read(comp.attrib['{'+PN+'}path'].lstrip('/')));mesh=next(x for x in child.find(q('resources')).findall(q('object')) if x.attrib['id']==comp.attrib['objectid']).find(q('mesh'))
  vertices=np.array([[float(v.attrib[k]) for k in ('x','y','z')] for v in mesh.find(q('vertices'))]);assert vertices.shape==source.shape;assert len(mesh.find(q('triangles')))==len(source_mesh.find(q('triangles')))
  def transform(points,t):
   a=np.array([float(v) for v in t.split()]);return points@a[:9].reshape(3,3)+a[9:]
  vertices=transform(vertices,comp.attrib.get('transform','1 0 0 0 1 0 0 0 1 0 0 0'));vertices=transform(vertices,build[oid].attrib.get('transform','1 0 0 0 1 0 0 0 1 0 0 0'))
  assert np.allclose(vertices,source+delta,rtol=0,atol=.00015),(name,float(np.max(abs(vertices-source-delta))))
 report={'revision':'V3.18','geometry_unchanged':True,'maximum_roundtrip_coordinate_tolerance_mm':.00015,'plates':3,'objects':10,'sliced':False,'sent_to_printer':False,'objects_review':record,'combined_3mf_sha256':sha(final)}
 (OUT/'all-parts-review.json').write_text(json.dumps(report,indent=2)+'\n')
print('Verified 10 unchanged objects on 3 plates:',final,final.stat().st_size,'bytes')
