"""Baguette V3 engineering prototype; dimensions are millimetres.

Preserves the original crust/cavity/rib/lug construction. New printable features:
hinge contained within the original exterior, two short shell-following snap latches, a rib-free interior and an integrated covered center snap joint. No display-only geometry is substituted for the print meshes.
"""
from pathlib import Path
import argparse, ast, hashlib, json, math, sys, zipfile
import numpy as np
import shapely.geometry as sg
from manifold3d import Manifold, Mesh, CrossSection, set_circular_segments
import trimesh

ROOT=Path(__file__).resolve().parents[1]
JOINT_PROFILE_SOURCE=(ROOT/'source/joint-profile.json').read_text()
JOINT_BLEND_SOURCE=(ROOT/'source/joint-blend.py.txt').read_text()
LEGACY=Path(__file__).resolve().parent/'legacy'
sys.path.insert(0,str(LEGACY))
import baguette_case_v2 as old
from baguette_case import box, prof_extrude, y_cyl, to_trimesh, write_3mf

# Prototype defaults. Validate using the supplied fit coupons before full parts.
P={'hinge_axis_x':-40.4,'exterior_rim_axis_x':-41.0,'exterior_rim_radius':3.3,'hinge_axis_z':0.0,'hinge_radius':4.3,'pin_radius':1.5,'hinge_centers':[-150.,150.],'max_open_angle':100,'rear_wall_outer_x':-43.0,'rear_wall_inner_x':-38.5,'rim_blend_radius':2.0,'radial_clearance':.4,'axial_clearance':.45,
   'seam_gap':.3,'joint_gap':.2,'latch_thickness':1.8,'latch_length':18.0,
   'latch_width':20.0,'latch_hook':1.6,'latch_relief':.45,
   'latch_centers':[-150.,150.],'latch_root_thickness':3.2,'catch_backing':5.2,
   'catch_pocket_extra':.4,'catch_exit_relief':.9,'catch_shoulder_gap':.35,'thumb_lip':2.0,'thumb_lip_height':3.0,'thumb_underhang':.8,'latch_corner_radius':1.5,'latch_edge_radius':.45,'thumb_blend_radius':.8,
   'wall_guard':2.45,'wall_nominal':3.6,'joint_blend_length':30.0,'release_travel':2.1,'ribs_enabled':False,'rib_depth':1.8,'rib_width':2.4,'rib_support':3.0,
   'joint_lip_length':16.0,'joint_lip_thickness':1.6,'joint_outward_shift':4.6,'joint_inner_cover':1.2,'joint_outer_cover':1.2,'joint_clearance':.3,'joint_anchor_length':12.0,'joint_flex_start':-.1,'joint_barb_height':1.0,'joint_barb_shoulder':12.0,'joint_pocket_clearance':.25,'joint_retention_gap':.25,'joint_finger_width_degrees':14.0,'joint_pocket_extra_degrees':5.0,'joint_deflection':1.2,
   'joint_finger_angles':[25,48,132,155,210,245,295,330],'material':'PLA','nozzle_mm':.4,'layer_mm':.2}


def clean(solid):
    parts=solid.decompose()
    kept=[p for p in parts if p.volume()>.001]
    if not kept:return Manifold()
    return Manifold.batch_boolean(kept, __import__('manifold3d').OpType.Add)


def base_geometry(with_envelope=False):
    """Cache the inherited shell with deterministic tessellation."""
    set_circular_segments(64)
    raw=(LEGACY/'baguette_case_v2.py').read_text()
    for key,original in [('RIB_D',4.0),('BULK_T',3.2),('RIB_SUP',6.0)]:
        parameter={'RIB_D':'rib_depth','BULK_T':'rib_width','RIB_SUP':'rib_support'}[key]
        raw=raw.replace(key+' = '+str(original),key+' = '+str(P[parameter]))
    raw=raw.replace('CAV_WALL = 3.0','CAV_WALL = '+str(P['wall_nominal']))
    raw=raw.replace('body = force(crust + belt, "crust+belt")', 'crust = force(crust + capsule(BORE_R + 2.5, BORE_L), "bore wall guard")\n    body = force(crust + belt, "crust+belt")')
    start=raw.index('    ero = crust\n');end=raw.index('    c0 = hollowed(CAV_WALL)',start)
    raw=raw[:start]+f'    flat_d = min(-body.bounding_box()[2],body.bounding_box()[5])-FLAT\n    ero = crust.minkowski_difference(Manifold.sphere({P["wall_guard"]},32))\n    ero ^= box(-300,-400,-flat_d+{P["wall_guard"]},300,400,flat_d-{P["wall_guard"]})\n\n'+raw[end:]
    start=raw.index('    cavity = (c1 - box');end=raw.index('    # keep a solid tube',start)
    raw=raw[:start]+JOINT_BLEND_SOURCE+raw[end:]
    # Extend each rib through the wall to the crust before union. The old c0
    # cavity boundary left near-coincident buried faces at the rib-to-wall join.
    before='shell += (slab - band - cone) ^ crust'
    assert raw.count(before)==1
    raw=raw.replace(before,'shell += ((crust ^ box(-99, lo, -99, 99, hi, 99)) - band - cone)')
    key=hashlib.sha256((raw+str(P['ribs_enabled'])+str(P['joint_blend_length'])+JOINT_PROFILE_SOURCE+'core-v3-8-guard-blend-segments64').encode()).hexdigest()[:12]
    cache=ROOT/'output'/f'core-{key}.npz'
    if cache.exists():
        d=np.load(cache)
        shells=[Manifold(Mesh(d[n+'v'].astype(np.float32),d[n+'f'].astype(np.uint32))) for n in ('base','lid')]
        result=(*shells, float(d['axis']),float(d['flat']),sg.Polygon(d['socket']),sg.Polygon(d['belt']))
        if with_envelope:return *result,Manifold(Mesh(d['outerv'].astype(np.float32),d['outerf'].astype(np.uint32)))
        return result
    tree=ast.parse(raw)
    build=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='build')
    # Remove the legacy large solid reinforcement tube around the hinge.
    build.body=[n for n in build.body if not (isinstance(n,ast.AugAssign) and isinstance(n.target,ast.Name) and n.target.id=='cavity' and isinstance(n.value,ast.Call) and isinstance(n.value.func,ast.Name) and n.value.func.id=='y_cyl')]
    stop=next(i for i,n in enumerate(build.body) if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='notch_spans' for t in n.targets))
    build.body=build.body[:stop]+ast.parse('return trough,lid,x_axis,D,jc,belt_poly,body').body
    if not P['ribs_enabled']:
        build.body=[n for n in build.body if not (isinstance(n,ast.For) and isinstance(n.iter,ast.Name) and n.iter.id=='BULK_Y')]
    ast.fix_missing_locations(tree)
    env={'__file__':str(LEGACY/'baguette_case_v2.py'),'__name__':'v3_core','JOINT_SOCKET':sg.Polygon(json.loads(JOINT_PROFILE_SOURCE)),'JOINT_BLEND_LENGTH':P['joint_blend_length']}
    exec(compile(tree,str(LEGACY/'baguette_case_v2.py'),'exec'),env)
    base,lid,axis,D,socket,belt,outer=env['build']('final')
    outer=outer^box(-300,-400,-D,300,400,D)
    data={}
    for n,s in [('base',base),('lid',lid),('outer',outer)]:
        m=to_trimesh(clean(s));data[n+'v']=m.vertices;data[n+'f']=m.faces
    np.savez_compressed(cache,**data,axis=axis,flat=D,socket=np.asarray(socket.exterior.coords),belt=np.asarray(belt.exterior.coords))
    result=(clean(base),clean(lid),axis,D,socket,belt)
    return (*result,outer) if with_envelope else result


def profile(points,y0,y1):
    return old.wedge(points,y0,y1)


def open_lid(solid,axis,angle):
    z=P['hinge_axis_z']
    return solid.translate([-axis,0,-z]).rotate([0,-angle,0]).translate([axis,0,z])


def clearance_envelope(solid,clearance):
    # A true solid offset: translated copies leave contact points on thin webs.
    c=clearance
    return solid.simplify(.005).minkowski_sum(box(-c,-c,-c,c,c,c))


def rim_profiles():
 """Tangent circular blends join the rolled edge to both wall surfaces.

 The profile is solid CAD, not a shading correction. It retains the 3 mm
 wall away from the rim and removes the abrupt steps at fixed-ear ends.
 """
 f=P['rim_blend_radius']
 R=P['hinge_radius'];axis=P['hinge_axis_x'];z0=P['hinge_axis_z']
 def side_points(side,d,R,axis):
  angle=math.acos((d+f)/(R+f));cz=math.sqrt((R+f)**2-(d+f)**2)
  half=[(side*R*math.cos(t),R*math.sin(t)) for t in np.linspace(0,angle,33)]
  half += [(side*(d+f-f*math.cos(t)),cz-f*math.sin(t)) for t in np.linspace(angle,0,33)[1:]]
  half.append((side*d,100.))
  points=[(x,-z) for x,z in reversed(half[1:])]+half
  return [(axis+x,z0+z) for x,z in points]
 outside=side_points(-1,P['exterior_rim_axis_x']-P['rear_wall_outer_x'],P['exterior_rim_radius'],P['exterior_rim_axis_x']);inside=side_points(1,P['rear_wall_inner_x']-axis,R,axis)
 return profile(outside+[(150,100),(150,-100)],-400,400),profile(outside+list(reversed(inside)),-400,400)


def hinge(base,lid,old_axis):
    """Direct three-knuckle hinges in a rounded rim; no arms or leaf brackets."""
    axis=P['hinge_axis_x'];z=P['hinge_axis_z'];R=P['hinge_radius']
    clearance=P['radial_clearance'];gap=P['axial_clearance']
    outer=base_geometry(True)[-1]
    rim=y_cyl(R,-400,400,axis,z)
    # Reprofile the back wall inward so the lid can rotate around the rim.
    # Rebuild a 3 mm wall behind the trimmed surface; simply clipping the
    # inherited thin crust would leave openings into the interior.
    allowed,wall=rim_profiles()
    back_wall=outer^wall
    shell=clean(((base+lid)^allowed)+back_wall)
    base=(shell^box(-150,-400,-100,150,400,-P['seam_gap']/2))+(shell^rim)
    full_lid=shell^box(-150,-400,P['seam_gap']/2,150,400,100)
    lid=full_lid-y_cyl(R+clearance,-400,400,axis,z)
    for cy in P['hinge_centers']:
        # The middle knuckle belongs to the lid and joins its shell directly.
        base-=y_cyl(R+clearance,cy-8-gap,cy+8+gap,axis,z)
        lid+=full_lid^box(-150,cy-8,-100,150,cy+8,100)
        for lo,hi in ((cy-14-gap,cy-8-gap),(cy+8+gap,cy+14+gap)):
            lid-=y_cyl(R+clearance,lo-gap,hi+gap,axis,z)
            base+=y_cyl(R,lo,hi,axis,z)^allowed
        base+=y_cyl(P['pin_radius'],cy-13-gap,cy+13+gap,axis,z)
        lid+=y_cyl(R,cy-8,cy+8,axis,z)^allowed
        lid-=y_cyl(P['pin_radius']+clearance,cy-15,cy+15,axis,z)
    return clean(base),clean(lid),axis


def latches(base,lid,belt):
    """Two shell-contoured tongues with deep hooks and reinforced catch rails."""
    # Cache evaluated solids against the exact source and all model parameters.
    # The same CAD is reused for export, motion review and fit coupons.
    key=hashlib.sha256((Path(__file__).read_text()+json.dumps(P,sort_keys=True)+JOINT_PROFILE_SOURCE+JOINT_BLEND_SOURCE+(LEGACY/'baguette_case_v2.py').read_text()).encode()).hexdigest()[:16]
    cache=ROOT/'output'/f'latches-{key}.npz'
    if cache.exists():
        d=np.load(cache)
        read=lambda n:Manifold(Mesh(d[n+'v'].astype(np.float32),d[n+'f'].astype(np.uint32)))
        features=json.loads(str(d['features']))
        for i,f in enumerate(features):f['solid']=read('tongue'+str(i))
        return read('base'),read('lid'),features
    features=[];outer=base_geometry(True)[-1]
    t=P['latch_thickness'];w=P['latch_width'];low=-10.;top=low+P['latch_length']
    def skin(offset0,offset1,clip):
        return (outer.translate([-offset0,0,0])-outer.translate([-offset1,0,0]))^clip
    def rounded_window(y0,y1,z0,z1,r):
        poly=sg.box(y0,z0,y1,z1).buffer(-r).buffer(r,quad_segs=12)
        points=list(poly.exterior.coords)[:-1]
        if not poly.exterior.is_ccw:points.reverse()
        return Manifold.extrude(CrossSection([points]),80).transform([[0,0,1,25],[1,0,0,0],[0,1,0,0]])
    for y in P['latch_centers']:
        y0=y-w/2;y1=y+w/2
        # The thin tongue follows the actual surface, including the belt ledges.
        local_shell=outer^box(20,y0-5,low-5,100,y1+5,top+6)
        eroded=local_shell.minkowski_difference(Manifold.sphere(t,16))
        arm=(local_shell-eroded)^rounded_window(y0,y1,low,top+1,P['latch_corner_radius'])
        # Rebuild a flexible U-cut tongue, with a thicker transition into the lid.
        lid-=box(20,y0-.6,0,100,y1+.6,top-.5)
        recess=skin(-1,t+P['latch_relief'],box(20,y0-.6,low-.6,100,y1+.6,0))
        base-=recess
        root=skin(0,P['latch_root_thickness'],box(20,y0-1.5,top,100,y1+1.5,top+4))
        # The receiver is 5.2 mm deep behind the running gap. Its
        # nominal undercut retains a 3.65 mm back wall and a 5 mm tall rail.
        backing=skin(t+P['latch_relief'],t+P['latch_relief']+P['catch_backing'],
                     box(20,y0-2,low-2,100,y1+2,-P['seam_gap']/2))
        base+=backing-old.capsule(old.BORE_R,old.BORE_L)
        shoulder=-5.5;ramp_start=low+1;ramp_end=-7.
        ramp_outer=(outer.translate([-t,0,0]))^box(20,y0+2,ramp_start,100,y1-2,ramp_end)
        def ramp(v):
            x,yy,z=v
            return (x-P['latch_hook']*(z-ramp_start)/(ramp_end-ramp_start),yy,z)
        hook=ramp_outer-ramp_outer.warp(ramp)
        hook+=skin(t,t+P['latch_hook'],box(20,y0+2,ramp_end,100,y1-2,shoulder))
        pocket=skin(t-.2,t+P['latch_hook']+P['catch_pocket_extra'],
                    box(20,y0+1.6,ramp_start-.4,100,y1-1.6,shoulder+P['catch_shoulder_gap']))
        base-=pocket
        # A short bevel above the retaining shoulder clears the released hook
        # as it rises toward the wider belt. Keep the retaining face intact.
        z0=shoulder+P['catch_shoulder_gap']+.3;z1=-2.
        front=(outer.translate([-t-P['latch_relief'],0,0]))^box(20,y0+1.5,z0,100,y1-1.5,z1)
        def exit_bevel(v):
            x,yy,z=v
            return (x-P['catch_exit_relief']*(z-z0)/(z1-z0),yy,z)
        base-=front-front.warp(exit_bevel)
        base-=skin(t+P['latch_relief'],t+P['latch_relief']+P['catch_exit_relief'],
                   box(20,y0+1.5,z1,100,y1-1.5,-P['seam_gap']/2))
        # A rounded lower catch is part of the tongue, with a concave blend
        # into its face and a small underhang for finger purchase.
        lip=skin(-P['thumb_lip'],t,rounded_window(y0+3,y1-3,low-P['thumb_underhang'],low+P['thumb_lip_height'],1.3))
        face=clean(arm+lip).simplify(.01)
        assert not arm.is_empty() and not lip.is_empty(), 'Latch outline must produce solid material'
        print('Rounding latch blend at',y,flush=True)
        ball=Manifold.sphere(P['thumb_blend_radius'],16)
        blend=face.minkowski_sum(ball).simplify(.01).minkowski_difference(ball).simplify(.01)
        lower=box(20,y0-2,low-2,100,y1+2,low+P['thumb_lip_height']+2)
        face=clean((blend^lower)+(face-lower))
        print('Rounding latch edges at',y,flush=True)
        edge=Manifold.sphere(P['latch_edge_radius'],16)
        face=clean(face.simplify(.01).minkowski_difference(edge).simplify(.01).minkowski_sum(edge)).simplify(.01)
        # Keep rounding within the shell envelope outside the finger catch.
        grip_zone=box(25,y-8,low-P['thumb_underhang'],100,y+8,low+P['thumb_lip_height']+2)
        face=clean(face^(outer+grip_zone))
        base-=clearance_envelope(face,P['latch_relief'])
        tongue=clean(face+root+hook)
        lid+=tongue
        local=outer^box(20,y0,low,100,y1,top)
        features.append({'y':y,'x':local.bounding_box()[3], 'root_z':top,'tip_z':low-P['thumb_underhang'],
                         'release_min_x':min(tongue.bounding_box()[0],32)-.1,
                         'hook_shoulder_z':shoulder,'engagement_mm':P['latch_hook']-P['latch_relief'],
                         'receiver_lip_projection_mm':P['latch_hook']+P['catch_pocket_extra']-P['latch_relief'],
                         'receiver_back_wall_mm':P['catch_backing']-P['latch_hook']-P['catch_pocket_extra']+P['latch_relief'],
                         'solid':tongue})
    solids={'base':clean(base),'lid':clean(lid),**{'tongue'+str(i):f['solid'] for i,f in enumerate(features)}}
    data={}
    for name,solid in solids.items():
        mesh=to_trimesh(solid);data[name+'v']=mesh.vertices;data[name+'f']=mesh.faces
    np.savez_compressed(cache,**data,features=json.dumps([{k:val for k,val in f.items() if k!='solid'} for f in features]))
    return solids['base'],solids['lid'],features


def released(lid,features,travel):
    if not travel:return lid
    def move(v):
        x,y,z=v
        for f in features:
            if abs(y-f['y'])<P['latch_width']/2+.1 and x>f['release_min_x']:
                q=max(0,min(1,(f['root_z']-z)/(f['root_z']-f['tip_z'])))
                x+=travel*q*q*(3-2*q)
        return (x,y,z)
    return lid.warp(move)


def print_pose(solid,side):
    s=solid.rotate([-90 if side=='A' else 90,0,0]);bb=s.bounding_box()
    return s.translate([-(bb[0]+bb[3])/2,-(bb[1]+bb[4])/2,-bb[2]])


def sector(angle,width,y0,y1):
 a=np.radians(np.linspace(angle-width/2,angle+width/2,17))
 points=[(0,0)]+[(100*float(np.cos(t)),100*float(np.sin(t))) for t in a]
 return profile(points,y0,y1)

def add_center_joint(parts,socket):
 """Eight integral edge tongues enter covered blind slots in the opposite shell."""
 j=old.JOINT_Y;L=P['joint_lip_length'];t=P['joint_lip_thickness'];c=P['joint_clearance'];h=P['joint_barb_height'];shoulder=P['joint_barb_shoulder'];root=P['joint_flex_start'];w=P['joint_finger_width_degrees']
 offset=P['joint_outward_shift']-c
 assert offset-t-P['joint_deflection']-c >= P['joint_inner_cover']-1e-8
 outer=socket.buffer(offset,quad_segs=12);inside=socket.buffer(offset-t,quad_segs=12)
 def prism(poly,y0,y1):
  # The legacy profile helper ignores polygon holes. Preserve them explicitly
  # so recessed socket channels retain both their inner and outer skins.
  solid=prof_extrude(sg.Polygon(poly.exterior),y1-y0).translate([0,y0,0])
  for hole in poly.interiors:solid-=prof_extrude(sg.Polygon(hole),y1-y0).translate([0,y0,0])
  return solid
 ring=prism(outer,j-P['joint_anchor_length'],j+L)
 lead=prism(outer,j+L-2,j+L)
 def tip(v):
  x,y,z=v;q=max(0,min(1,(y-(j+L-2))/2));factor=1-.6*q/40
  return (x*factor,y,z*factor)
 ring=(ring-lead)+(lead.warp(tip)^lead)
 ridge=prism(outer.buffer(h,quad_segs=12),j+shoulder,j+L)
 def ramp(v):
  x,y,z=v;q=max(0,min(1,(y-(j+shoulder+1))/(L-shoulder-1)));factor=1-h*q/41
  return (x*factor,y,z*factor)
 ridge=ridge.refine(2).warp(ramp)
 hollow=prism(inside,j-P['joint_anchor_length']-1,j+L+1)
 ring-=hollow;ridge-=hollow
 # The pocket remains covered on both radial sides. Its inner wall also
 # leaves space for the compressed tongue during assembly.
 channel_inner=socket.buffer(offset-t-P['joint_deflection']-c,quad_segs=12)
 channel_outer=socket.buffer(offset+c,quad_segs=12)
 channel_profile=channel_outer.difference(channel_inner)
 features=[]
 for angle in P['joint_finger_angles']:
  kind='lid' if angle<180 else 'base'
  finger=clean((ring+ridge)^sector(angle,w,j-P['joint_anchor_length'],j+L+.1))
  if kind=='base':clip=box(-200,-400,-100,200,400,-.7)-box(-200,-400,-4,-20,400,0)
  else:clip=box(-200,-400,.7,200,400,100)-box(-200,-400,0,-20,400,8.5)
  finger=clean(finger^clip)
  width=w+P['joint_pocket_extra_degrees']
  rear_channel=Manifold() # The male root grows directly from the uncut shell face.
  entry_channel=prism(channel_profile,j-.1,j+L+.4)^sector(angle,width,j-.1,j+L+.4)
  catch_profile=socket.buffer(offset+h+P['joint_pocket_clearance'],quad_segs=12).difference(channel_inner)
  catch=prism(catch_profile,j+shoulder-P['joint_retention_gap'],j+L+.4)^sector(angle,width,j+shoulder-.3,j+L+.4)
  pocket=clean(entry_channel+catch)
  parts[kind+'_A']=clean((parts[kind+'_A']-rear_channel)+finger)
  parts[kind+'_B']=clean(parts[kind+'_B']-pocket)
  features.append({'part':kind,'angle':angle,'root_y':j+root,'tip_y':j+L,'shoulder_y':j+shoulder,'nominal_radial_engagement_mm':h-c,'outward_shift_mm':P['joint_outward_shift'],'nominal_inner_cover_mm':offset-t-P['joint_deflection']-c,'covered_socket':True,'pocket':pocket,'rear_channel':rear_channel,'finger':clean(finger^box(-100,j+root,-100,100,j+L+.1,100))})
 return parts,features

def deflect_joint(solid,socket,travel):
 if not travel:return solid
 j=old.JOINT_Y;root=j+P['joint_flex_start'];tip=j+P['joint_lip_length'];w=P['joint_finger_width_degrees']
 offset=P['joint_outward_shift']-P['joint_clearance']
 inside_region=socket.buffer(offset+.02).difference(socket.buffer(offset-P['joint_lip_thickness']-.02))
 normals={}
 from shapely.geometry import LineString
 boundary=socket.exterior
 for a in P['joint_finger_angles']:
  rad=math.radians(a);ray=LineString([(0,0),(100*math.cos(rad),100*math.sin(rad))])
  point=boundary.intersection(ray)
  if point.geom_type!='Point':point=min(point.geoms,key=lambda p:math.hypot(p.x,p.y))
  at=boundary.project(point);p0=boundary.interpolate((at-.1)%boundary.length);p1=boundary.interpolate((at+.1)%boundary.length)
  nx,nz=p1.y-p0.y,-(p1.x-p0.x);norm=math.hypot(nx,nz);nx/=norm;nz/=norm
  if nx*point.x+nz*point.y<0:nx=-nx;nz=-nz
  normals[a]=(nx,nz)
 def warp(point):
  x,y,z=point
  if y<=root:return point
  angle=math.degrees(math.atan2(z,x))%360
  selected=next((a for a in P['joint_finger_angles'] if abs((angle-a+180)%360-180)<=w/2+.01),None)
  if selected is None:return point
  if y<j+P['joint_barb_shoulder']-.01 and not inside_region.covers(sg.Point(x,z)):return point
  q=max(0,min(1,(y-root)/(tip-root)));d=travel*q*q*(3-2*q);r=math.hypot(x,z)
  nx,nz=normals[selected]
  return (x-d*nx,y,z-d*nz)
 return solid.warp(warp)



def build():
    set_circular_segments(64)
    base,lid,old_axis,D,socket,belt=base_geometry()
    base,lid,axis=hinge(base,lid,old_axis)
    base,lid,features=latches(base,lid,belt)
    cuts={'A':box(-200,-400,-150,200,old.JOINT_Y-P['joint_gap']/2,150),
          'B':box(-200,old.JOINT_Y+P['joint_gap']/2,-150,200,400,150)}
    parts={kind+'_'+side:clean(solid^cut) for side,cut in cuts.items() for kind,solid in [('base',base),('lid',lid)]}
    parts,joint=add_center_joint(parts,socket)
    # Canonicalize the manufacturing meshes to STL precision and discard
    # zero-volume fragments before measuring, validating and exporting them.
    parts={name:clean(Manifold(solid.to_mesh())) for name,solid in parts.items()}
    printables={}
    for side in ('A','B'):
        solid=print_pose(parts['base_'+side]+open_lid(parts['lid_'+side],axis,P['max_open_angle']),side)
        printables['segment_'+side]=clean(Manifold(solid.to_mesh()))
    return parts,printables,features,axis,D,joint


def metrics(solid):
    mesh=to_trimesh(solid);bb=np.array(solid.bounding_box());pieces=solid.decompose()
    return {'triangles':len(mesh.faces),'watertight':bool(mesh.is_watertight),'consistent_winding':bool(mesh.is_winding_consistent),
            'volume_mm3':solid.volume(),'mass_g_at_1_24':solid.volume()*.00124,'components':len(pieces),'component_volumes_mm3':[s.volume() for s in pieces],
            'bounds_mm':bb.tolist(),'size_mm':(bb[3:]-bb[:3]).tolist()}


def run():
    out=ROOT/'output';out.mkdir(exist_ok=True)
    parts,prints,features,axis,D,joint=build()
    base=parts['base_A']+parts['base_B'];lid=parts['lid_A']+parts['lid_B']
    report={'generator_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'revision':'V3.9 rounded latch and underside finger catch engineering prototype','parameters':P,'hinge_axis':[axis,0,P['hinge_axis_z']], 'printables':{},'parts':{},'sweep':[],
            'joinery':'Eight integral edge tongues enter covered blind receiving slots, four on each shell; no separate connector, interior ribs or adhesive. Intended as a non-serviceable joint, pending physical fit and load tests.',
            'rib_count':0 if not P['ribs_enabled'] else len(old.BULK_Y),
            'joint':[ {k:val for k,val in f.items() if not isinstance(val,Manifold)} for f in joint],
            'latches':[ {k:v for k,v in f.items() if k!='solid'} for f in features]}
    for n,s in parts.items():
        report['parts'][n]=metrics(s);to_trimesh(s).export(out/f'{n}.stl')
    for n,s in prints.items():
        report['printables'][n]=metrics(s);to_trimesh(s).export(out/f'baguette_v3_{n}.stl')
        write_3mf(out/f'baguette_v3_{n}.3mf',[(n,to_trimesh(s))])
    free=released(lid,features,P['release_travel'])
    for angle in range(0,P['max_open_angle']+1,5):
        vol=(base^open_lid(free,axis,angle)).volume()
        report['sweep'].append({'angle_degrees':angle,'released_overlap_mm3':vol})
        print(f'sweep {angle}: {vol:.5f} mm3',flush=True)
    report['closed_overlap_mm3']=(base^lid).volume()
    report['approx_latch_strain_at_release']=1.5*P['latch_thickness']*P['release_travel']/P['latch_length']**2
    (out/'review.json').write_text(json.dumps(report,indent=2))
    payload={'axis':[0,P['hinge_axis_z'],axis], 'preview_tolerance_mm':.02, 'parts':[]}
    for n,s in parts.items():
        tm=to_trimesh(s.simplify(.02))
        payload['parts'].append({'name':n,'vertices':np.round(tm.vertices[:,[1,2,0]],5).tolist(),'triangles':tm.faces.tolist()})
    (out/'assembly.json').write_text(json.dumps(payload,separators=(',',':')))
    print(json.dumps({'max_sweep_overlap':max(r['released_overlap_mm3'] for r in report['sweep']), 'closed_overlap':report['closed_overlap_mm3'],'parts':{n:r['size_mm'] for n,r in report['printables'].items()}},indent=2))

if __name__=='__main__':run()
