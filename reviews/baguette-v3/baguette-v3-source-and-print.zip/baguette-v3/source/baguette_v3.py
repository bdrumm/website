"""Baguette V3 engineering prototype; dimensions are millimetres.

Preserves the original crust/cavity/rib/lug construction. New printable features:
hinge contained within the original exterior, two short shell-following snap latches, flat center faces and internal
bonding sleeves. No display-only geometry is substituted for the print meshes.
"""
from pathlib import Path
import argparse, ast, hashlib, json, sys, zipfile
import numpy as np
import shapely.geometry as sg
from manifold3d import Manifold, Mesh, set_circular_segments
import trimesh

ROOT=Path(__file__).resolve().parents[1]
LEGACY=Path(__file__).resolve().parent/'legacy'
sys.path.insert(0,str(LEGACY))
import baguette_case_v2 as old
from baguette_case import box, prof_extrude, y_cyl, to_trimesh, write_3mf

# Prototype defaults. Validate using the supplied fit coupons before full parts.
P={'hinge_axis_x':-41.0,'hinge_axis_z':0.0,'hinge_radius':3.3,'pin_radius':1.0,'hinge_centers':[-150.,150.],'max_open_angle':100,'rear_wall_outer_x':-43.0,'rear_wall_inner_x':-40.0,'radial_clearance':.4,'axial_clearance':.45,
   'seam_gap':.3,'joint_gap':.2,'sleeve_clearance':.25,'sleeve_wall':2.0,
   'sleeve_length':32.0,'latch_thickness':1.8,'latch_length':18.0,
   'latch_width':20.0,'latch_hook':1.6,'latch_relief':.45,
   'latch_centers':[-150.,150.],'latch_root_thickness':3.2,'catch_backing':5.2,
   'catch_pocket_extra':.4,'catch_exit_relief':.9,'catch_shoulder_gap':.35,'thumb_lip':.8,
   'release_travel':2.1,'material':'PLA','nozzle_mm':.4,'layer_mm':.2}


def clean(solid):
    parts=solid.decompose()
    kept=[p for p in parts if p.volume()>.001]
    if not kept:return Manifold()
    return Manifold.batch_boolean(kept, __import__('manifold3d').OpType.Add)


def base_geometry(with_envelope=False):
    """Cache the inherited shell with deterministic tessellation."""
    set_circular_segments(64)
    raw=(LEGACY/'baguette_case_v2.py').read_text()
    # Extend each rib through the wall to the crust before union. The old c0
    # cavity boundary left near-coincident buried faces at the rib-to-wall join.
    before='shell += (slab - band - cone) ^ crust'
    assert raw.count(before)==1
    raw=raw.replace(before,'shell += ((crust ^ box(-99, lo, -99, 99, hi, 99)) - band - cone)')
    key=hashlib.sha256((raw+'core-v3-5-no-hinge-filler-segments64').encode()).hexdigest()[:12]
    cache=ROOT/'output'/f'core-{key}.npz'
    if cache.exists():
        d=np.load(cache)
        shells=[Manifold(Mesh(d[n+'v'].astype(np.float32),d[n+'f'].astype(np.uint32))) for n in ('base','lid')]
        result=(*shells, float(d['axis']),float(d['flat']),sg.Polygon(d['socket']),sg.Polygon(d['belt']))
        if with_envelope:return *result,Manifold(Mesh(d['outerv'].astype(np.float32),d['outerf'].astype(np.uint32)))
        return result
    tree=ast.parse(raw)
    build=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='build')
    # Remove the legacy large solid reinforcement tube around the hinge.
    build.body=[n for n in build.body if not (isinstance(n,ast.AugAssign) and isinstance(n.target,ast.Name) and n.target.id=='cavity' and isinstance(n.value,ast.Call) and isinstance(n.value.func,ast.Name) and n.value.func.id=='y_cyl')]
    stop=next(i for i,n in enumerate(build.body) if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='notch_spans' for t in n.targets))
    build.body=build.body[:stop]+ast.parse('return trough,lid,x_axis,D,jc,belt_poly,body').body
    ast.fix_missing_locations(tree)
    env={'__file__':str(LEGACY/'baguette_case_v2.py'),'__name__':'v3_core'}
    exec(compile(tree,str(LEGACY/'baguette_case_v2.py'),'exec'),env)
    base,lid,axis,D,socket,belt,outer=env['build']('final')
    outer=outer^box(-300,-400,-D,300,400,D)
    data={}
    for n,s in [('base',base),('lid',lid),('outer',outer)]:
        m=to_trimesh(clean(s));data[n+'v']=m.vertices;data[n+'f']=m.faces
    np.savez_compressed(cache,**data,axis=axis,flat=D,socket=np.asarray(socket.exterior.coords),belt=np.asarray(belt.exterior.coords))
    result=(clean(base),clean(lid),axis,D,socket,belt)
    return (*result,outer) if with_envelope else result


def profile(points,y0,y1):
    return old.wedge(points,y0,y1)


def open_lid(solid,axis,angle):
    z=P['hinge_axis_z']
    return solid.translate([-axis,0,-z]).rotate([0,-angle,0]).translate([axis,0,z])


def clearance_envelope(solid,clearance):
    # A true solid offset: translated copies leave contact points on thin webs.
    c=clearance
    return solid.simplify(.005).minkowski_sum(box(-c,-c,-c,c,c,c))


def hinge(base,lid,old_axis):
    """Direct three-knuckle hinges in a rounded rim; no arms or leaf brackets."""
    axis=P['hinge_axis_x'];z=P['hinge_axis_z'];R=P['hinge_radius']
    clearance=P['radial_clearance'];gap=P['axial_clearance']
    outer=base_geometry(True)[-1]
    rim=y_cyl(R,-400,400,axis,z)
    # Reprofile the back wall inward so the lid can rotate around the rim.
    # Rebuild a 3 mm wall behind the trimmed surface; simply clipping the
    # inherited thin crust would leave openings into the interior.
    allowed=box(P['rear_wall_outer_x'],-400,-100,150,400,100)+rim
    back_wall=outer^allowed^box(-150,-400,-100,P['rear_wall_inner_x'],400,100)
    shell=clean(((base+lid)^allowed)+back_wall)
    base=(shell^box(-150,-400,-100,150,400,-P['seam_gap']/2))+(shell^rim)
    full_lid=shell^box(-150,-400,P['seam_gap']/2,150,400,100)
    lid=full_lid-y_cyl(R+clearance,-400,400,axis,z)
    for cy in P['hinge_centers']:
        # The middle knuckle belongs to the lid and joins its shell directly.
        base-=y_cyl(R+clearance,cy-8-gap,cy+8+gap,axis,z)
        lid+=full_lid^box(-150,cy-8,-100,150,cy+8,100)
        for lo,hi in ((cy-14-gap,cy-8-gap),(cy+8+gap,cy+14+gap)):
            lid-=y_cyl(R+clearance,lo-gap,hi+gap,axis,z)
            base+=y_cyl(R,lo,hi,axis,z)
        base+=y_cyl(P['pin_radius'],cy-13-gap,cy+13+gap,axis,z)
        lid+=y_cyl(R,cy-8,cy+8,axis,z)
        lid-=y_cyl(P['pin_radius']+clearance,cy-15,cy+15,axis,z)
    return clean(base),clean(lid),axis


def latches(base,lid,belt):
    """Two shell-contoured tongues with deep hooks and reinforced catch rails."""
    features=[];outer=base_geometry(True)[-1]
    t=P['latch_thickness'];w=P['latch_width'];low=-10.;top=low+P['latch_length']
    def skin(offset0,offset1,clip):
        return (outer.translate([-offset0,0,0])-outer.translate([-offset1,0,0]))^clip
    for y in P['latch_centers']:
        y0=y-w/2;y1=y+w/2
        # The thin tongue follows the actual surface, including the belt ledges.
        local_shell=outer^box(20,y0-5,low-5,100,y1+5,top+6)
        eroded=local_shell.minkowski_difference(Manifold.sphere(t,16))
        arm=(local_shell-eroded)^box(25,y0,low,100,y1,top+1)
        # Rebuild a flexible U-cut tongue, with a thicker transition into the lid.
        lid-=box(20,y0-.6,0,100,y1+.6,top-.5)
        recess=skin(-1,t+P['latch_relief'],box(20,y0-.6,low-.6,100,y1+.6,0))
        base-=recess
        root=skin(0,P['latch_root_thickness'],box(20,y0-1.5,top,100,y1+1.5,top+4))
        # The receiver is 5.2 mm deep behind the running gap. Its
        # nominal undercut retains a 3.65 mm back wall and a 5 mm tall rail.
        backing=skin(t+P['latch_relief'],t+P['latch_relief']+P['catch_backing'],
                     box(20,y0-2,low-2,100,y1+2,-P['seam_gap']/2))
        base+=backing-old.capsule(old.BORE_R,old.BORE_L)
        shoulder=-5.5;ramp_start=low+1;ramp_end=-7.
        ramp_outer=(outer.translate([-t,0,0]))^box(20,y0+2,ramp_start,100,y1-2,ramp_end)
        def ramp(v):
            x,yy,z=v
            return (x-P['latch_hook']*(z-ramp_start)/(ramp_end-ramp_start),yy,z)
        hook=ramp_outer-ramp_outer.warp(ramp)
        hook+=skin(t,t+P['latch_hook'],box(20,y0+2,ramp_end,100,y1-2,shoulder))
        pocket=skin(t-.2,t+P['latch_hook']+P['catch_pocket_extra'],
                    box(20,y0+1.6,ramp_start-.4,100,y1-1.6,shoulder+P['catch_shoulder_gap']))
        base-=pocket
        base-=clearance_envelope(arm,P['latch_relief'])
        # A short bevel above the retaining shoulder clears the released hook
        # as it rises toward the wider belt. Keep the retaining face intact.
        z0=shoulder+P['catch_shoulder_gap']+.3;z1=-2.
        front=(outer.translate([-t-P['latch_relief'],0,0]))^box(20,y0+1.5,z0,100,y1-1.5,z1)
        def exit_bevel(v):
            x,yy,z=v
            return (x-P['catch_exit_relief']*(z-z0)/(z1-z0),yy,z)
        base-=front-front.warp(exit_bevel)
        base-=skin(t+P['latch_relief'],t+P['latch_relief']+P['catch_exit_relief'],
                   box(20,y0+1.5,z1,100,y1-1.5,-P['seam_gap']/2))
        # A small thumb lip is the only deliberate outward projection.
        lip=skin(-P['thumb_lip'],t,box(20,y0+3,low,100,y1-3,low+1.2))
        tongue=clean(arm+root+hook+lip)
        lid+=tongue
        local=outer^box(20,y0,low,100,y1,top)
        features.append({'y':y,'x':local.bounding_box()[3], 'root_z':top,'tip_z':low,
                         'release_min_x':min(tongue.bounding_box()[0],32)-.1,
                         'hook_shoulder_z':shoulder,'engagement_mm':P['latch_hook']-P['latch_relief'],
                         'receiver_lip_projection_mm':P['latch_hook']+P['catch_pocket_extra']-P['latch_relief'],
                         'receiver_back_wall_mm':P['catch_backing']-P['latch_hook']-P['catch_pocket_extra']+P['latch_relief'],
                         'solid':tongue})
    return clean(base),clean(lid),features


def make_sleeves(base,lid,socket,axis):
    L=P['sleeve_length'];j=old.JOINT_Y
    outer=socket.buffer(-P['sleeve_clearance'],quad_segs=12)
    inner=outer.buffer(-P['sleeve_wall'],quad_segs=12)
    ring=prof_extrude(outer.difference(inner),L).translate([0,j-L/2,0])
    ring-=old.capsule(old.BORE_R,old.BORE_L)
    sleeves={}
    for n,clip in [('base',box(-200,-400,-100,200,400,-.7)),('lid',box(-200,-400,.7,200,400,100))]:
        region=ring^clip
        if n=='lid':region-=box(-200,-400,0,-20,400,8.5)
        else:region-=box(-200,-400,-4,-20,400,0)
        pieces=sorted([p for p in region.decompose() if p.volume()>.001],key=lambda p:p.bounding_box()[0])
        for index,piece in enumerate(pieces):
            label=n if len(pieces)==1 else f'{n}_{index+1}'
            sleeves[label]=piece
    return sleeves


def released(lid,features,travel):
    if not travel:return lid
    def move(v):
        x,y,z=v
        for f in features:
            if abs(y-f['y'])<P['latch_width']/2+.1 and x>f['release_min_x']:
                q=max(0,min(1,(f['root_z']-z)/(f['root_z']-f['tip_z'])))
                x+=travel*q*q*(3-2*q)
        return (x,y,z)
    return lid.warp(move)


def print_pose(solid,side):
    s=solid.rotate([-90 if side=='A' else 90,0,0]);bb=s.bounding_box()
    return s.translate([-(bb[0]+bb[3])/2,-(bb[1]+bb[4])/2,-bb[2]])


def build():
    set_circular_segments(64)
    base,lid,old_axis,D,socket,belt=base_geometry()
    base,lid,axis=hinge(base,lid,old_axis)
    base,lid,features=latches(base,lid,belt)
    sleeves=make_sleeves(base,lid,socket,axis)
    cuts={'A':box(-200,-400,-150,200,old.JOINT_Y-P['joint_gap']/2,150),
          'B':box(-200,old.JOINT_Y+P['joint_gap']/2,-150,200,400,150)}
    parts={};printables={}
    for side,cut in cuts.items():
        b=clean(base^cut);l=clean(lid^cut)
        parts['base_'+side]=b;parts['lid_'+side]=l
        printables['segment_'+side]=clean(print_pose(b+open_lid(l,axis,P['max_open_angle']),side))
    parts.update({f'sleeve_{n}':s for n,s in sleeves.items()})
    for n,s in sleeves.items():
        printables[f'sleeve_{n}']=print_pose(s,'B')
    return parts,printables,features,axis,D


def metrics(solid):
    mesh=to_trimesh(solid);bb=np.array(solid.bounding_box());pieces=solid.decompose()
    return {'triangles':len(mesh.faces),'watertight':bool(mesh.is_watertight),'consistent_winding':bool(mesh.is_winding_consistent),
            'volume_mm3':solid.volume(),'mass_g_at_1_24':solid.volume()*.00124,'components':len(pieces),'component_volumes_mm3':[s.volume() for s in pieces],
            'bounds_mm':bb.tolist(),'size_mm':(bb[3:]-bb[:3]).tolist()}


def run():
    out=ROOT/'output';out.mkdir(exist_ok=True)
    parts,prints,features,axis,D=build()
    base=parts['base_A']+parts['base_B'];lid=parts['lid_A']+parts['lid_B']
    report={'generator_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'revision':'V3.4 direct rim hinge engineering prototype','parameters':P,'hinge_axis':[axis,0,P['hinge_axis_z']], 'printables':{},'parts':{},'sweep':[],
            'joinery':'Separate keyed internal bonding sleeves; adhesives require material compatibility and physical validation.',
            'latches':[ {k:v for k,v in f.items() if k!='solid'} for f in features]}
    for n,s in parts.items():
        report['parts'][n]=metrics(s);to_trimesh(s).export(out/f'{n}.stl')
    for n,s in prints.items():
        report['printables'][n]=metrics(s);to_trimesh(s).export(out/f'baguette_v3_{n}.stl')
        write_3mf(out/f'baguette_v3_{n}.3mf',[(n,to_trimesh(s))])
    free=released(lid,features,P['release_travel'])
    for angle in range(0,P['max_open_angle']+1,5):
        vol=(base^open_lid(free,axis,angle)).volume()
        report['sweep'].append({'angle_degrees':angle,'released_overlap_mm3':vol})
        print(f'sweep {angle}: {vol:.5f} mm3',flush=True)
    report['closed_overlap_mm3']=(base^lid).volume()
    report['sleeve_interference_mm3']={n:(s^(base+lid)).volume() for n,s in parts.items() if n.startswith('sleeve')}
    report['approx_latch_strain_at_release']=1.5*P['latch_thickness']*P['release_travel']/P['latch_length']**2
    (out/'review.json').write_text(json.dumps(report,indent=2))
    payload={'axis':[0,P['hinge_axis_z'],axis], 'preview_tolerance_mm':.02, 'parts':[]}
    for n,s in parts.items():
        tm=to_trimesh(s.simplify(.02))
        payload['parts'].append({'name':n,'vertices':np.round(tm.vertices[:,[1,2,0]],5).tolist(),'triangles':tm.faces.tolist()})
    (out/'assembly.json').write_text(json.dumps(payload,separators=(',',':')))
    print(json.dumps({'max_sweep_overlap':max(r['released_overlap_mm3'] for r in report['sweep']), 'closed_overlap':report['closed_overlap_mm3'],'parts':{n:r['size_mm'] for n,r in report['printables'].items()}},indent=2))

if __name__=='__main__':run()
