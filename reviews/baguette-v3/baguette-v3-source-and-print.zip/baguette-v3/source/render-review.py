import bpy,math,os
from pathlib import Path
from mathutils import Vector
ROOT=Path(__file__).resolve().parents[1]
bpy.ops.wm.read_factory_settings(use_empty=True)
bpy.ops.import_scene.gltf(filepath=str(ROOT/'review/baguette-v3.glb'))
for obj in list(bpy.data.objects):
 if obj.type=='MESH' and obj.get('reviewSection'):bpy.data.objects.remove(obj,do_unlink=True)
root=bpy.data.objects['BaguetteV3'];root.scale=(.01,)*3
scene=bpy.context.scene;scene.render.engine='CYCLES';scene.cycles.samples=32
scene.render.resolution_x=1440;scene.render.resolution_y=900;scene.render.resolution_percentage=100
scene.render.image_settings.file_format='PNG';scene.render.film_transparent=False
scene.world=bpy.data.worlds.new('Review world');scene.world.color=(.16,.16,.16)
world=scene.world;world.use_nodes=True;world.node_tree.nodes['Background'].inputs['Color'].default_value=(.16,.18,.23,1);world.node_tree.nodes['Background'].inputs['Strength'].default_value=.5
scene.view_settings.view_transform='AgX'
for location,power,size in [((1,-3,7),1100,6),((-4,-1,2),550,5),((1,5,4),950,4)]:
 bpy.ops.object.light_add(type='AREA',location=location);light=bpy.context.object;light.data.energy=power;light.data.shape='DISK';light.data.size=size;light.rotation_euler=(Vector((0,0,0))-light.location).to_track_quat('-Z','Y').to_euler()
bpy.ops.object.camera_add();camera=bpy.context.object;scene.camera=camera;camera.data.type='ORTHO'
rests={obj.name:obj.location.copy() for obj in bpy.data.objects if obj.type=='MESH'}
def render(name,location,target,scale,angle=0,separate=0):
 if os.environ.get('BAGUETTE_RENDER_VIEW') and name!=os.environ['BAGUETTE_RENDER_VIEW']:return
 for obj in bpy.data.objects:
  if obj.type=='MESH' and obj.name in rests:
   obj.location=rests[obj.name].copy()
   if obj.name.endswith('_A'):obj.location.x-=separate
   elif obj.name.endswith('_B'):obj.location.x+=separate
 bpy.data.objects['LidHinge'].rotation_mode='XYZ';bpy.data.objects['LidHinge'].rotation_euler.x=-math.radians(angle)
 for obj in bpy.data.objects:
  if obj.type=='MESH' and obj.data.shape_keys:
   for key in list(obj.data.shape_keys.key_blocks)[1:]:key.value=1 if angle else 0
 camera.location=location;camera.rotation_euler=(Vector(target)-camera.location).to_track_quat('-Z','Y').to_euler();camera.data.ortho_scale=scale
 scene.render.filepath=str(ROOT/'review'/f'{name}.png');bpy.ops.render.render(write_still=True)
render('latch',(1.7,-4,.7),(1.5,-.43,0),.70)
render('latch-under',(1.66,-2.4,-2.4),(1.5,-.44,-.085),.60)
render('strap',(3.2,-1.4,-.75),(2.715,-.5,-.035),.92)
render('strap-tail',(2.9,-.45,-2.2),(2.9,-.45,-.035),.55)
render('closed',(3,-7,4.2),(0,0,0),7)
render('open',(2.2,-8,5),(0,.25,0),7,100)
render('rear',(3,7,4.2),(0,0,0),7)
render('hinge',(1.9,-.1,1.5),(1.5,.404,0),.64,100)
render('hinge-mid',(1.9,-1.2,.2),(1.5,.404,0),.64,50)
render('hinge-closed',(1.9,1.5,.3),(1.5,.404,0),.64,0)
render('joint',(-.85,-2.2,1.5),(-.04,0,.10),1.5,100,24)

# Review-only sections are cut from the final manufacturing solids.
for obj in list(bpy.data.objects):
 if obj.type=='MESH':bpy.data.objects.remove(obj,do_unlink=True)
bpy.ops.wm.stl_import(filepath=str(ROOT/'output/latch-tongue.stl'))
obj=bpy.context.object;obj.rotation_euler.z=-math.pi/2;obj.scale=(.01,)*3
mat=bpy.data.materials.new('Unloaded tongue');mat.diffuse_color=(.63,.40,.17,1);mat.use_nodes=True
mat.node_tree.nodes['Principled BSDF'].inputs['Base Color'].default_value=(.63,.40,.17,1)
mat.node_tree.nodes['Principled BSDF'].inputs['Roughness'].default_value=.55;obj.data.materials.append(mat)
render('latch-bevel',(1.04,-1.3,-.35),(1.5,-.43,-.02),.43)
for obj in list(bpy.data.objects):
 if obj.type=='MESH':bpy.data.objects.remove(obj,do_unlink=True)
for name,color in [('base',(.23,.42,.5,1)),('lid',(.63,.40,.17,1))]:
 bpy.ops.wm.stl_import(filepath=str(ROOT/'output'/f'latch-section-{name}.stl'))
 obj=bpy.context.object;obj.rotation_euler.z=-math.pi/2;obj.scale=(.01,)*3
 mat=bpy.data.materials.new('Section '+name);mat.diffuse_color=color;mat.use_nodes=True
 mat.node_tree.nodes['Principled BSDF'].inputs['Base Color'].default_value=color
 mat.node_tree.nodes['Principled BSDF'].inputs['Roughness'].default_value=.55
 obj.data.materials.clear();obj.data.materials.append(mat)
render('catch',(3,-.50,.03),(1.5,-.415,-.01),.42)

for obj in list(bpy.data.objects):
 if obj.type=='MESH':bpy.data.objects.remove(obj,do_unlink=True)
for name,color in [('base',(.23,.42,.5,1)),('lid',(.63,.40,.17,1))]:
 bpy.ops.wm.stl_import(filepath=str(ROOT/'output'/f'hinge-section-{name}.stl'))
 obj=bpy.context.object;obj.rotation_euler.z=-math.pi/2;obj.scale=(.01,)*3
 mat=bpy.data.materials.new('Hinge section '+name);mat.diffuse_color=color;mat.use_nodes=True
 mat.node_tree.nodes['Principled BSDF'].inputs['Base Color'].default_value=color
 mat.node_tree.nodes['Principled BSDF'].inputs['Roughness'].default_value=.55
 obj.data.materials.clear();obj.data.materials.append(mat)
render('hinge-section',(.5,.44,.02),(1.5,.404,0),.30)

for obj in list(bpy.data.objects):
 if obj.type=='MESH':bpy.data.objects.remove(obj,do_unlink=True)
for side,color in [('A',(.63,.40,.17,1)),('B',(.26,.13,.07,1))]:
 bpy.ops.wm.stl_import(filepath=str(ROOT/'output'/f'joint-section-{side}.stl'))
 obj=bpy.context.object;obj.rotation_euler.z=-math.pi/2;obj.scale=(.01,)*3
 mat=bpy.data.materials.new('Joint section '+side);mat.diffuse_color=color;mat.use_nodes=True
 mat.node_tree.nodes['Principled BSDF'].inputs['Base Color'].default_value=color
 mat.node_tree.nodes['Principled BSDF'].inputs['Roughness'].default_value=.55
 obj.data.materials.clear();obj.data.materials.append(mat)
render('joint-section',(.015,-.398,1),(.015,-.398,0),.43)
