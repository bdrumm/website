"""Fail closed if the reviewed CAD, preview, slices or print pack are stale."""
from pathlib import Path
import base64,gzip,hashlib,json,re,struct,zipfile
ROOT=Path(__file__).resolve().parents[1]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
r=json.loads((ROOT/'output/review.json').read_text())
assert r['generator_sha256']==sha(ROOT/'source/baguette_v3.py'),'Generator changed after CAD export'
v=r['validation'];assert v['failed']==0 and v['passed']==len(v['checks']) and all(c['passed'] for c in v['checks'])
assert v['continuous_sweep_proven'] and v['rotation_clearance_certificate']['certified_minimum_gap_mm']>0
review=json.loads((ROOT/'output/design-review.json').read_text())
assert review['generator_sha256']==r['generator_sha256']
assert review['reviewed_views']==['closed','rear','open','hinge-closed','hinge-mid','hinge','hinge-section','latch','catch','joint','joint-section','slice-walls','latch-under']
for rel,digest in review['files_sha256'].items():assert sha(ROOT/rel)==digest,'Review evidence changed: '+rel
assert review['files_sha256']['review/baguette-v3.glb']==sha(ROOT/'review/baguette-v3.glb')
blob=(ROOT/'review/baguette-v3.glb').read_bytes();length,kind=struct.unpack_from('<II',blob,12);assert kind==0x4e4f534a
model=json.loads(blob[20:20+length]);root=next(n for n in model['nodes'] if n.get('name')=='BaguetteV3')
assert root['extras']['generatorSha256']==r['generator_sha256']
assert gzip.decompress((ROOT/'review/baguette-v3.glb.gz').read_bytes())==blob
inline=(ROOT.parent/'baguette-v3-review.html').read_text();assert len(inline.encode())<1_000_000
assert gzip.decompress(base64.b64decode(re.search("const encoded='([^']+)'",inline)[1]))==blob
assert not re.search(r'\bfetch\s*\(',inline)
for side,sliced in r['slicing'].items():
 assert sliced['sent_to_printer'] is False
 assert sliced['input_stl_sha256']==sha(ROOT/'output'/f'baguette_v3_segment_{side}.stl')
 proof=sliced['provenance'];assert proof['input_stl_sha256']==sliced['input_stl_sha256']
 assert proof['output_gcode_sha256']==sha(ROOT/'output/slicer'/f'segment-{side}'/'plate_1.gcode')
 for name,digest in proof['settings_sha256'].items():assert digest==sha(ROOT/'output/slicer'/f'{name}.json')
slices=json.loads((ROOT/'output/slice-wall-review.json').read_text())
assert len(slices['sections'])==4
for section in slices['sections']:
 assert section['gcode_sha256']==r['slicing'][section['segment']]['provenance']['output_gcode_sha256']
 assert section['planned_bead_regions_over_1_mm2']==2
for rel in ('source/joint-profile.json','source/joint-blend.py.txt','output/slice-wall-review.json'):
 assert review['files_sha256'][rel]==sha(ROOT/rel)
with zipfile.ZipFile(ROOT/'review/baguette-v3-print-pack.zip') as z:
 prefix='baguette-v3-print-pack/';manifest=json.loads(z.read(prefix+'sha256.json'))
 assert set(z.namelist())=={prefix+k for k in manifest}|{prefix+'sha256.json'}
 for rel,digest in manifest.items():
  data=z.read(prefix+rel);assert hashlib.sha256(data).hexdigest()==digest
  if rel.startswith('parts/'):src=ROOT/'output'/Path(rel).name
  elif rel.startswith('coupons/'):src=ROOT/'output'/rel
  elif rel.startswith('slicer-settings/'):src=ROOT/'output/slicer'/Path(rel).name
  elif rel=='engineering-review.md':src=ROOT/'review'/rel
  elif rel=='README.md':src=ROOT/'print-pack'/rel
  else:src=ROOT/'output'/rel
  assert data==src.read_bytes(),'Packaged file is stale: '+rel
 assert len([k for k in manifest if k.startswith('parts/')])==4
 assert len([k for k in manifest if k.startswith('coupons/') and k.endswith(('.stl','.3mf'))])==14
assert (ROOT/'review/review.json').read_bytes()==(ROOT/'output/review.json').read_bytes()
markup=(ROOT/'review/index.html').read_text()
for href in re.findall(r'(?:src|href)="([^"]+)"',markup):
 if href.startswith(('/','http','#')):continue
 assert (ROOT/'review'/href.split('?')[0]).exists(),href
print('Prepublish gate passed: reviewed CAD, continuous motion, exact sections, slices, inline preview and print pack agree.')
