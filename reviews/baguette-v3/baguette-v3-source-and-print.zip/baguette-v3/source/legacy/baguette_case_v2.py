#!/usr/bin/env python3
"""Crossbody baguette case v2 — the case IS a baguette. VERTICAL print.

Exterior comes from a reference model: "Baguette" by Isa Lousberg,
CC0 / Public Domain, via poly.pizza (https://poly.pizza/m/HPvkMpqqTg),
downloaded to ref_models/baguette_isa.glb. No attribution required (CC0),
credited anyway. The low-poly source is subdivision-smoothed into an
organic crust (score ridges survive as soft diagonal swells).

PRINT ORIENTATION: each segment stands VERTICALLY on its joint face
(nose up), in the open butterfly pose. Layer lines run along the loaf and
the crust needs no supports. "Down" during printing is therefore TOWARD
THE JOINT — opposite directions for segments A (y<0) and B (y>0) — and
every feature that would create a 90 deg overhang blends into the body
with a 45 deg slope on its joint side:

  ribs   - revolved rings about the bore axis with 45 deg support cones
  cavity - the solid tips meet the interior through 45 deg cone ceilings
  hinge  - barrels and pin print as clean vertical cylinders (no sag
           slack needed); the relief gutters terminate in 45 deg cones
  latch  - tab roots get 45 deg under-wedges, catch blocks get pyramids
  lugs   - vertical fins on the latch side with 45 deg sloped lower edges

Everything is built in the CLOSED frame (parting plane z=0, bore axis on
it); print poses are derived by opening the lid 180 deg about the hinge
axis, then standing the segment on its joint face.

The segments slot together with an INTEGRATED lip (no separate part):
segment A carries a spigot ring fused into both its halves that slides
into segment B's prismatic socket. The exterior stays a plain butt seam.

Parts: baguette_v2_seg_A.stl (male), baguette_v2_seg_B.stl (female)

Usage:
  .venv/bin/python baguette_case_v2.py preview
  .venv/bin/python baguette_case_v2.py final
"""
import sys
from pathlib import Path

import numpy as np
import shapely
import shapely.affinity
import shapely.geometry as sg
import shapely.ops
import trimesh
from manifold3d import CrossSection, Manifold, Mesh, set_circular_segments

from baguette_case import (PLA_G_CM3, box, cs_of, prof_extrude, render,
                           to_trimesh, write_3mf, xz_wedge, y_cyl)

OUT_DIR = Path(__file__).resolve().parent
REF = OUT_DIR / "ref_models" / "baguette_isa.glb"

# ---- closed-frame dimensions (mm) ----
CASE_L = 620.0          # crust tip to tip; each seg ~310 + lip stands <320
CROSS_W = 78.0          # crust width at the fattest point
CROSS_H = 74.0          # crust height at the fattest point
BORE_R = 31.0           # o62 capsule bore
BORE_L = 600.0          # capsule total length (incl. spherical caps)
MIN_WALL = 2.0          # verified by probe; crust fattened until it holds
FAT_SRC = 200.0         # source |y| where the reference's fat zone ends
FAT_DST = 270.0         # stretched so the fat zone covers the bore
FLAT = 1.5              # table flats cut top and bottom of the closed case
SMOOTH_REFINE = 4       # subdivision level for the low-poly source

# ---- belt ----
BELT_OFF = 1.5          # silhouette offset
BELT_HT = 3.5           # each side of the parting plane

# ---- hinge (confined to the fat zone; prints as vertical cylinders) ----
HINGE_HL = 240.0        # hinge half-length; pin ends flush in end knuckles
N_KNUCKLE = 13          # odd, A at both ends AND astride the mid joint
K_GAP = 0.4
BARREL_R = 3.4          # slim barrels: hinge hugs the body
PIN_R = 1.6
PIN_HOLE_R = 2.0        # 0.4 radial print-in-place clearance
ARM_Z = 4.5
NOTCH_R = 10.4          # mortise gutters: with the axis embedded, all
                        # crust/belt within this radius must clear on the
                        # opposite half (the crust bulges widest ~9 mm
                        # below the seam, which sets this)
AXIS_EMBED = 2.6        # axis sits INSIDE the belt outline: barrels stand
                        # only BARREL_R - AXIS_EMBED = 0.8 proud of the edge
RELIEF_HL = 292.0       # gutter continues past the last knuckle until the
                        # taper pulls the belt edge clear; ends in 45 cones

# ---- latch (tab widened so the 45 deg sloped lower edge still leaves a
# full-strength bump band at the free tip) ----
TAB_Y = (-225.0, -90.0, 90.0, 225.0)
TAB_W = 24.0
TAB_T = 2.0             # plate thickness (robust)
TAB_TILT = 1.2          # plate leans inward over its length: the bump is
                        # driven into the catch and bites deeper

# ---- strap lugs: vertical fins on the LATCH side, trough half only,
# 45 deg sloped lower edge so they print support-free standing up ----
CONN_Y = (-255.0, 255.0)   # fin base centers (outside the hinge span)
FIN_OUT = 14.0             # protrusion beyond the local belt edge
FIN_Z = (-6.5, -0.5)       # fin plate thickness band (below the parting)
FIN_SLOT = (19.0, 5.0)     # hook slot (along y, across)

# ---- interior ----
CAV_WALL = 3.0          # target crust wall (scaled-cavity approximation)
CAV_GUARD = 1.4         # erosion guard: min skin kept over the score dips
BULK_T = 3.2            # rib ring thickness
BULK_Y = (-220.0, -140.0, -60.0, 60.0, 140.0, 220.0)
RIB_D = 4.0             # shallow hoops: nominal depth from the wall
RIB_SUP = 6.0           # 45 deg support cone run on the joint side

# ---- mid joint (integrated spigot on A -> prismatic socket on B) ----
JOINT_Y = -4.0          # joint plane, biased so the longer spigot still
                        # fits both segments under the 320 mm print height
JOINT_HL = 20.0         # interior is prismatic within +-this of the joint
JOINT_GAP = 0.2         # exterior butt gap between the segments
LIP_T = 1.8             # spigot wall thickness
LIP_CLR = 0.3           # sliding clearance spigot-to-socket
LIP_LEN = 12.0          # spigot protrusion into segment B (deep nesting)
RIDGE_H = 0.7           # snap ridge height on the spigot; 45 deg lead-in
RIDGE_Y = 8.0           # ridge steep face, local spigot coordinates
LIP_ANCHOR = 8.0        # spigot length fused back into segment A
LIP_TIP = 2.0           # lead-in chamfer length at the spigot mouth


# ---------- reference model -> smooth crust ----------
def load_crust():
    scene = trimesh.load(REF)
    geoms = list(scene.geometry.values()) if hasattr(scene, "geometry") else [scene]
    tm = trimesh.util.concatenate(geoms)
    tm.merge_vertices(merge_tex=True, merge_norm=True)
    tm.update_faces(tm.nondegenerate_faces())
    if not tm.is_watertight:
        trimesh.repair.fill_holes(tm)
    trimesh.repair.fix_normals(tm)
    assert tm.is_watertight, "reference mesh could not be made watertight"

    m = Manifold(Mesh(vert_properties=tm.vertices.astype(np.float32),
                      tri_verts=tm.faces.astype(np.uint32)))
    assert m.volume() > 0, "reference mesh is not a valid manifold"
    m = Manifold.smooth(m.to_mesh()).refine(SMOOTH_REFINE)
    m = m.rotate([90, 0, 0])          # length z->y, height y->z
    return m


def fit_crust(m, sxz=1.0):
    """Center and scale the crust to case dimensions (sxz fattens x/z)."""
    bb = np.asarray(m.bounding_box())
    size = bb[3:] - bb[:3]
    mid = (bb[3:] + bb[:3]) / 2
    m = m.translate([-mid[0], -mid[1], 0])
    m = m.scale([CROSS_W * sxz / size[0], CASE_L / size[1],
                 CROSS_H * sxz / size[2]])
    # center the fat mid-span on the bore axis (z=0)
    mid_bb = np.asarray((m ^ box(-99, -220, -99, 99, 220, 99)).bounding_box())
    m = m.translate([0, 0, -(mid_bb[5] + mid_bb[2]) / 2])

    # remap y: stretch the fat middle over the bore span, squeeze the
    # tapered tips into the last stretch (truer baguette proportions, too)
    L = CASE_L / 2

    def remap(v):
        x, y, z = v
        a = abs(y)
        if a <= FAT_SRC:
            a = a * FAT_DST / FAT_SRC
        else:
            a = FAT_DST + (a - FAT_SRC) * (L - FAT_DST) / (L - FAT_SRC)
        return (x, a if y >= 0 else -a, z)

    return m.warp(remap)


def capsule(r, total_len):
    cyl_l = total_len - 2 * r
    c = y_cyl(r, -cyl_l / 2, cyl_l / 2, 0, 0)
    for s in (-1, 1):
        c += Manifold.sphere(r).translate([0, s * cyl_l / 2, 0])
    return c


def y_cone(r0, r1, y0, length, x=0.0, z=0.0):
    """Cone/frustum along +y: radius r0 at y0, r1 at y0+length."""
    c = Manifold.cylinder(length, max(r0, 0.05), max(r1, 0.05))
    return c.rotate([-90, 0, 0]).translate([x, y0, z])


# ---------- 2D silhouette helpers ----------
def silhouette(m, z=0.0):
    """Crust outline at height z, as a shapely polygon."""
    slab = m ^ box(-200, -400, z - 0.2, 200, 400, z + 0.2)
    polys = (slab.project()).to_polygons()
    shp = shapely.ops.unary_union(
        [sg.Polygon(p) for p in polys if sg.Polygon(p).area > 1])
    if shp.geom_type == "MultiPolygon":
        shp = max(shp.geoms, key=lambda g: g.area)
    return shp.simplify(0.1)


def band_bounds(poly, y0, y1):
    """(min_x, max_x) of a silhouette within a y band."""
    b = poly.intersection(sg.box(-200, y0, 200, y1))
    return (b.bounds[0], b.bounds[2]) if not b.is_empty else (-1, 1)


def rounded(x0, y0, x1, y1, r):
    return sg.box(x0 + r, y0 + r, x1 - r, y1 - r).buffer(r, quad_segs=8)


def biggest(p):
    """Largest polygon of a (possibly Multi) shapely result."""
    if p.geom_type == "MultiPolygon":
        return max(p.geoms, key=lambda g: g.area)
    return p


# ---------- hinge ----------
def knuckle_spans():
    k = (2 * HINGE_HL - (N_KNUCKLE - 1) * K_GAP) / N_KNUCKLE
    spans, y = [], -HINGE_HL
    for i in range(N_KNUCKLE):
        spans.append((y, y + k, "A" if i % 2 == 0 else "B"))
        y += k + K_GAP
    return spans


def wedge(pts, y0, y1):
    """xz_wedge with winding normalized to CCW (CW polys extrude empty)."""
    area = sum(pts[i][0] * pts[(i + 1) % len(pts)][1]
               - pts[(i + 1) % len(pts)][0] * pts[i][1]
               for i in range(len(pts)))
    return xz_wedge(pts if area > 0 else pts[::-1], y0, y1)


def force(m, tag=""):
    """Evaluate the lazy CSG tree now. Large deferred trees crash the
    batch-union path in manifold3d 3.5 on macOS ARM; keeping each
    evaluation small avoids it (and localizes failures to a stage)."""
    n = m.num_tri()
    if tag:
        print(f"    [{tag}: {n} tris]")
    return m


def open_about(m, x_axis, theta):
    """Rotate about the hinge axis (x=x_axis, z=0); theta=180 = fully open."""
    return m.translate([-x_axis, 0, 0]).rotate([0, -theta, 0]) \
            .translate([x_axis, 0, 0])


# ---------- build (closed frame) ----------
def build(mode):
    print("loading + smoothing reference crust ...")
    raw = load_crust()

    crust, probe_vol = None, None
    sxz = 1.0
    for it in range(6):
        crust = fit_crust(raw, sxz)
        probe = capsule(BORE_R + MIN_WALL, BORE_L) - crust
        probe_vol = probe.volume()
        print(f"  wall probe (scale {sxz:.2f}): residual {probe_vol:.1f} mm^3")
        if probe_vol < 1.0:
            break
        sxz *= 1.05
    assert probe_vol < 1.0, "could not achieve minimum wall thickness"

    sil = silhouette(crust)
    belt_poly = sil.buffer(BELT_OFF, quad_segs=8).simplify(0.05)

    belt = Manifold.extrude(cs_of(belt_poly), 2 * BELT_HT) \
        .translate([0, 0, -BELT_HT])
    body = force(crust + belt, "crust+belt")

    # interior: scaled-crust cavity — the wall continues at constant-ish
    # thickness all the way around the nose domes (fully rounded ends,
    # conforming to the outside; no cone caps or steps)
    bbf = np.asarray(crust.bounding_box())
    hw, hh = min(bbf[3], -bbf[0]), min(bbf[5], -bbf[2])

    def hollowed(depth):
        return crust.scale([1 - depth / hw, 1 - depth / (CASE_L / 2),
                            1 - depth / hh])

    # the scaled cavity is not a true surface offset: inside the concave
    # score-mark dips it can thin to zero and punch pinholes through the
    # crust. Guard by intersecting with an EROSION of the crust (translated
    # copies in 10 directions): the cavity then provably keeps ~CAV_GUARD
    # of skin everywhere, following the dips instead of cutting them.
    ero = crust
    for dx, dz in ((1, 0), (-1, 0), (0, 1), (0, -1),
                   (0.71, 0.71), (-0.71, 0.71), (0.71, -0.71),
                   (-0.71, -0.71)):
        ero ^= crust.translate([-CAV_GUARD * dx, 0, -CAV_GUARD * dz])
    for dy in (1, -1):
        ero ^= crust.translate([0, -CAV_GUARD * dy, 0])
    ero = force(ero, "erosion guard")

    c0 = hollowed(CAV_WALL)
    patched = (c0 - ero).volume()
    print(f"    dip patches filled by the guard: {patched:.1f} mm^3")
    c1 = c0 ^ ero
    assert (c1 - crust).volume() < 0.01, "cavity breaches the crust"

    # around the mid joint the interior becomes PRISMATIC (the joint-plane
    # cavity profile extruded straight): deterministic coupler sockets
    slab = c1 ^ box(-99, JOINT_Y - 0.3, -99, 99, JOINT_Y + 0.3, 99)
    polys = slab.rotate([-90, 0, 0]).project().to_polygons()
    jp = shapely.ops.unary_union(
        [sg.Polygon(p) for p in polys if sg.Polygon(p).area > 1])
    if jp.geom_type == "MultiPolygon":
        jp = max(jp.geoms, key=lambda g: g.area)
    jp = jp.simplify(0.05)

    # thicker wall at the connection: the prism profile comes from one
    # station, but the crust waists/dips within the joint span — shrink
    # the joint cavity until it stays fully inside the crust everywhere
    jc, joint_cav, over = jp, None, None
    for extra in (2.0, 3.0, 4.0, 5.0):
        jc = jp.buffer(-extra, quad_segs=8)
        joint_cav = prof_extrude(jc, 2 * JOINT_HL) \
            .translate([0, JOINT_Y - JOINT_HL, 0])
        over = (joint_cav - body).volume()
        print(f"    joint wall +{extra:.0f}: prism overshoot {over:.1f} mm^3")
        if over < 0.5:
            break
    assert over < 0.5, "joint cavity still breaches the crust"

    cavity = (c1 - box(-99, JOINT_Y - JOINT_HL, -99,
                       99, JOINT_Y + JOINT_HL, 99)) + joint_cav

    # keep a solid tube of material around the hinge gutters so the deep
    # mortise cuts can never break through into the interior
    x_axis = belt_poly.bounds[0] + AXIS_EMBED
    cavity -= y_cyl(NOTCH_R + 2.2, -RELIEF_HL - NOTCH_R - 2,
                    RELIEF_HL + NOTCH_R + 2, x_axis, 0)

    shell = body - cavity - capsule(BORE_R, BORE_L)

    # rib hoops with SMOOTH edges: the inner boundary is a per-station
    # ellipse fitted to the cavity cross-section (not a crust offset, so
    # no organic ripple reaches the exposed rib faces), and the joint-side
    # support is an exact ruled elliptical cone growing 1:1 per axis
    # (true 45 deg). Where the wall undulates, the rib just blends
    # deeper into it instead of copying the bumps.
    circ = sg.Point(0, 0).buffer(1, quad_segs=32)
    for wy in BULK_Y:
        s = 1 if wy > 0 else -1
        face = wy - s * BULK_T / 2            # joint-side face of the rib
        lo = min(face - s * RIB_SUP, wy + s * BULK_T / 2)
        hi = max(face - s * RIB_SUP, wy + s * BULK_T / 2)
        slab = c0 ^ box(-99, lo, -99, 99, hi, 99)
        bbs = np.asarray(slab.bounding_box())
        cx, cz = (bbs[0] + bbs[3]) / 2, (bbs[2] + bbs[5]) / 2
        a = (bbs[3] - bbs[0]) / 2 - RIB_D
        b = (bbs[5] - bbs[2]) / 2 - RIB_D

        band = prof_extrude(
            shapely.affinity.translate(
                shapely.affinity.scale(circ, a, b), cx, cz),
            BULK_T + 0.2).translate([0, wy - BULK_T / 2 - 0.1, 0])

        R = RIB_SUP
        cone = Manifold.extrude(
            cs_of(shapely.affinity.scale(circ, a + R, b + R)), R, 0, 0.0,
            (a / (a + R), b / (b + R)))
        if s > 0:
            cone = cone.rotate([-90, 0, 0]).translate([cx, face - R, cz])
        else:
            cone = cone.rotate([90, 0, 0]).translate([cx, face + R, cz])

        shell += (slab - band - cone) ^ crust
    shell = force(shell, "cavity+ribs")

    # strap lug fins: vertical plates on the latch side, trough half only,
    # lower edge sloped 45 deg toward the joint. Corners rounded (arcs
    # only swing between 45 deg and vertical tangents, so still support-
    # free); the hook slot opens all the way inboard to the body wall for
    # clip flexibility, with a 45 deg gable on its away-from-joint end.
    for cy in CONN_Y:
        s = 1 if cy > 0 else -1
        yb0, yb1 = min(cy - s * 16, cy + s * 30), max(cy - s * 16, cy + s * 30)
        _, bx1 = band_bounds(belt_poly, yb0, yb1)
        x_in, x_tip = bx1 - 6, bx1 + FIN_OUT
        pts = [(x_in, cy - s * 16), (x_tip, cy + s * 4),
               (x_tip, cy + s * 30), (x_in, cy + s * 30)]
        fp = sg.Polygon(pts).buffer(-6, quad_segs=8).buffer(6, quad_segs=8)

        # cove blend: the top edge sweeps concavely into the wall. The
        # wall side follows the ACTUAL tapering silhouette (sampled in
        # steps), and the fillet terminates exactly where the arc meets
        # the buried wall line — nothing can overshoot the crust.
        top, L = cy + s * 30, 12.0
        x_t = band_bounds(sil, *sorted((top, top + s * 0.8)))[1] - 0.8
        cxA = x_t + L
        arc_pts, wall_pts = [], []
        t = 0.5
        while t <= L:
            yy = top + s * t
            xa = cxA - (L * L - (t - L) ** 2) ** 0.5
            xw_loc = band_bounds(sil, *sorted((yy, yy + s * 0.5)))[1] - 0.8
            if xa <= xw_loc:                  # arc reached the wall: close
                arc_pts.append((xw_loc, yy))
                break
            arc_pts.append((xa, yy))
            wall_pts.append((xw_loc, yy))
            t += 0.5
        verts = [(cxA, top)] + arc_pts + wall_pts[::-1] + [(x_t, top)]
        fp = biggest(fp.union(sg.Polygon(verts).buffer(0)))

        # plate with broken (chamfered) outline edges: full outline only
        # in the mid-thickness band, stepped in toward both faces
        tz0, tz1 = FIN_Z
        fin = Manifold.extrude(cs_of(biggest(fp.buffer(-1.2, quad_segs=4))),
                               tz1 - tz0).translate([0, 0, tz0])
        fin += Manifold.extrude(cs_of(biggest(fp.buffer(-0.55, quad_segs=4))),
                                tz1 - tz0 - 1.2).translate([0, 0, tz0 + 0.6])
        fin += Manifold.extrude(cs_of(fp), tz1 - tz0 - 2.4) \
            .translate([0, 0, tz0 + 1.2])

        # base fairing: stepped collars built from OUTWARD OFFSETS of the
        # crust itself, so the blend follows the organic wall exactly and
        # the fin reads as grown out of it (clipped below the parting
        # plane so the closing lid stays clear). The collars are cut off
        # at the fin's sloped lower edge — otherwise they trail a proud
        # strip down the wall below the anchor.
        lowcut = sg.Polygon([(x_in - 25, cy - s * 41.5),
                             (x_tip + 25, cy + s * 28.5),
                             (x_tip + 25, cy - s * 120),
                             (x_in - 25, cy - s * 120)])
        for w_lat, d in ((3.0, 0.8), (2.0, 1.6), (1.0, 2.4)):
            ring = crust.scale([(hw + d) / hw, 1, (hh + d) / hh]) - crust
            pad_poly = biggest(
                fp.buffer(w_lat, quad_segs=4).difference(lowcut))
            pad = Manifold.extrude(
                cs_of(pad_poly), (FIN_Z[1] - FIN_Z[0]) + w_lat) \
                .translate([0, 0, FIN_Z[0] - w_lat])
            fin += pad ^ ring

        # rounded-rectangle aperture, held clear of the body wall so the
        # opening is fully framed by the fin (small ceiling flat bridges)
        sx0, sx1 = bx1 + 2, x_tip - 3
        sl0, sl1 = min(cy + s * 7, cy + s * 26), max(cy + s * 7, cy + s * 26)
        sp = rounded(sx0, sl0, sx1, sl1, 2.5)
        fin -= Manifold.extrude(cs_of(sp), 60).translate([0, 0, -30])

        # fade the cove's top into the wall: above the plate's top edge
        # the fin may protrude at most (y_end - y) beyond the crust,
        # decaying to zero — the blend melts into the surface instead of
        # ending in a proud blunt column
        P = 10.0

        def fade(v, top=top, s=s):
            x, y, z = v
            g = 1.0 - max(0.0, min((y - top) * s / P, 1.0))
            return (x * (hw + P * g) / (hw + P), y,
                    z * (hh + P * g) / (hh + P))

        env = crust.scale([(hw + P) / hw, 1, (hh + P) / hh]) \
            .refine(2).warp(fade)
        if s > 0:
            below = box(-300, -400, -300, 300, top + 0.3, 300)
        else:
            below = box(-300, top - 0.3, -300, 300, 400, 300)
        fin ^= env + below

        shell += fin
    shell = force(shell, "fins")

    # split at the parting plane
    BIG = box(-300, -400, -300, 300, 400, 300)
    trough = shell ^ BIG.translate([0, 0, -300])
    lid = shell ^ BIG.translate([0, 0, 300])

    # table flats (also usable as an optional lying-down print base)
    bb = np.asarray(shell.bounding_box())
    D = min(-bb[2], bb[5]) - FLAT
    trough ^= box(-300, -400, -D, 300, 400, 0)
    lid ^= box(-300, -400, 0, 300, 400, D)

    # vents through the trough's flat (vertical slots in vertical print)
    for vy in (-200, -80, 80, 200):
        v = rounded(-3, vy - 15, 3, vy + 15, 2.9)
        trough -= Manifold.extrude(cs_of(v), 6).translate([0, 0, -D - 1])
    trough = force(trough, "trough split")
    lid = force(lid, "lid split")

    # hinge: vertical barrels and pin print in place with no sag slack
    notch_spans = {"trough": [], "lid": []}
    for y0, y1, owner in knuckle_spans():
        bx0, _ = band_bounds(belt_poly, y0, y1)
        barrel = y_cyl(BARREL_R, y0, y1, x_axis, 0)
        arm_t = box(x_axis, y0, -ARM_Z, bx0 + 6, y1, 0)
        arm_l = box(x_axis, y0, 0, bx0 + 6, y1, ARM_Z)
        if owner == "A":
            trough += barrel + arm_t
            lid -= y_cyl(NOTCH_R, y0 - K_GAP, y1 + K_GAP, x_axis, 0)
            notch_spans["lid"].append((y0 - K_GAP, y1 + K_GAP))
        else:
            bore = y_cyl(PIN_HOLE_R, y0 - 1, y1 + 1, x_axis, 0)
            # bore is cut from the WHOLE lid: with the embedded axis the
            # belt edge dips inside the pin radius at B spans
            lid = (lid + barrel + arm_l) - bore
            trough -= y_cyl(NOTCH_R, y0 - K_GAP, y1 + K_GAP, x_axis, 0)
            notch_spans["trough"].append((y0 - K_GAP, y1 + K_GAP))

    # 45 deg terminations on every notch end facing away from the joint:
    # the arm/belt material above each gutter void then grows on a ramp
    # instead of a flat 90 deg overhang. The cones are ANNULAR — they
    # spare the barrel column — so bearing length, pin and swing
    # clearance are unchanged; the arms just start ~6 mm later.
    BR2 = BARREL_R + 0.8
    CLEN = NOTCH_R - BR2
    spare = None
    for half_name in ("trough", "lid"):
        cones = None
        for y0, y1 in notch_spans[half_name]:
            ends = []
            if y1 > JOINT_Y + 1:
                ends.append((y1, +1))
            if y0 < JOINT_Y - 1:
                ends.append((y0, -1))
            for ye, e in ends:
                if e > 0:
                    c = y_cone(NOTCH_R, BR2, ye, CLEN, x_axis, 0)
                else:
                    c = y_cone(BR2, NOTCH_R, ye - CLEN, CLEN, x_axis, 0)
                c -= y_cyl(BARREL_R + 0.1, ye - CLEN - 1, ye + CLEN + 1,
                           x_axis, 0)
                cones = c if cones is None else cones + c
        if half_name == "trough":
            trough -= cones
        else:
            lid -= cones

    trough += y_cyl(PIN_R, -HINGE_HL + 3, HINGE_HL - 3, x_axis, 0)

    # beyond the knuckles the seam CLOSES: instead of relief gutters,
    # both halves are trimmed flush to the hinge-axis plane out to the
    # nose. Nothing crosses the plane there, so the 180 deg swing clears
    # by construction and the silhouette edge stays continuous — just a
    # subtle flat on the hinge-side cheek (the interior keep-tube holds
    # the wall solid behind it).
    for s in (-1, 1):
        t = box(-99, min(s * HINGE_HL, s * 400), -50,
                x_axis + 0.1, max(s * HINGE_HL, s * 400), 50)
        trough -= t
        lid -= t
    trough = force(trough, "trough hinge")
    lid = force(lid, "lid hinge")

    # latch: tabs on the lid snap into a RECESSED LAND milled into the
    # trough wall's outside — nothing protrudes into the interior. The
    # land position is measured from the actual crust at the groove
    # height, so engagement on the organic wall is deterministic.
    sil_g = silhouette(crust, -10)
    for ty in TAB_Y:
        s = 1 if ty > 0 else -1
        _, xe = band_bounds(belt_poly, ty - TAB_W / 2, ty + TAB_W / 2)
        y0, y1 = ty - TAB_W / 2, ty + TAB_W / 2
        y_dn = y0 if s > 0 else y1           # joint-side edge of the tab
        y_far = y1 if s > 0 else y0          # edge away from the joint
        _, land = band_bounds(sil_g, y0, y1)  # local wall at groove height

        xo = xe + 0.5                       # plate inner face at the root
        # tab plate leans TAB_TILT inward toward its free end, driving the
        # bump into the catch; root is deeper and taller for robustness
        plate = wedge([(xo, 3), (xo + TAB_T, 3),
                       (xo + TAB_T - TAB_TILT, -13),
                       (xo - TAB_TILT, -13)], y0, y1)
        lid += box(xe - 5, y0, 0, xo + TAB_T, y1, 3.5) + plate
        # root under-wedge (45 deg toward the wall)
        rw = sg.Polygon([(xo + TAB_T, y_dn), (xe - 5, y_dn - s * 7.1),
                         (xe - 5, y_dn)])
        lid += Manifold.extrude(cs_of(rw), 3.5)
        # tab plate bottom edge chamfer across the thickness (root zone)
        ch = sg.Polygon([(xo - TAB_TILT, y_dn), (xo + TAB_T, y_dn),
                         (xo + TAB_T, y_dn + s * (TAB_T + TAB_TILT))])
        lid -= Manifold.extrude(cs_of(ch), 13.6).translate([0, 0, -13.5])
        # the plate's lower edge slopes 45 deg ALONG ITS LENGTH: lowest at
        # the supported root (z=0), rising to the free tip (z=-13), so no
        # horizontal cantilever line is left hanging
        sl = sg.Polygon([(0, y_dn), (13, y_dn), (13, y_dn + s * 13)])
        lid -= Manifold.extrude(cs_of(sl), TAB_T + TAB_TILT + 0.4) \
            .rotate([0, 90, 0]).translate([xo - TAB_TILT - 0.2, 0, 0])
        # bump: centered on the tilted inner face at groove height, sized
        # to bite 1.15 past the recess land
        xb = xo - TAB_TILT * 13 / 16
        bump_r = xb - (land - 1.05)
        b0 = y_dn + s * 12
        if s > 0:
            bump = y_cyl(bump_r, b0 + bump_r, y_far, xb, -10) \
                + y_cone(0, bump_r, b0, bump_r, xb, -10)
        else:
            bump = y_cyl(bump_r, y_far, b0 - bump_r, xb, -10) \
                + y_cone(bump_r, 0, b0 - bump_r, bump_r, xb, -10)
        lid += bump

        # latch recess: trim the belt edge and crust bulge to a flat land
        # (the closing bump then flexes a constant 0.6 mm over it)
        trough -= box(land + 0.1, y0 - 0.4, -13.5, xe + 8, y1 + 0.4, 0.01)
        y_up = y1 + 0.4 if s > 0 else y0 - 0.4
        rt = sg.Polygon([(land + 0.1, y_up), (xe + 8, y_up),
                         (xe + 8, y_up + s * (xe + 8 - land - 0.1))])
        trough -= Manifold.extrude(cs_of(rt), 13.6).translate([0, 0, -13.5])
        # groove cut straight into the wall behind the land (floor 0.25
        # clear of the deeper-biting bump so the snap seats snugly)
        gz = bump_r + 0.4
        g0, g1 = sorted((y_dn + s * 11.6, y_far + s * 0.4))
        trough -= box(land - 1.3, g0, -10 - gz, land + 2, g1, -10 + gz)
        # groove roof: 45 deg taper on the end facing away from the joint
        yg = g1 if s > 0 else g0
        gr = sg.Polygon([(land + 2, yg), (land - 1.3, yg),
                         (land + 2, yg + s * 3.3)])
        trough -= Manifold.extrude(cs_of(gr), 2 * gz) \
            .translate([0, 0, -10 - gz])
    trough = force(trough, "trough latch")
    lid = force(lid, "lid latch")

    # integrated spigot ring on segment A: a thin ring that FUSES into A
    # over the anchor length (outer = socket wall jc, welded to A's wall)
    # and protrudes into B's socket with sliding clearance (outer =
    # jc-LIP_CLR). Bore stays open (ring is well outboard of BORE_R).
    b_wall = jc.buffer(0.4)              # anchor outer: bites into A's wall
    b_out = jc.buffer(-LIP_CLR)          # spigot outer: clearance in socket
    b_tip = jc.buffer(-LIP_CLR - 0.6)    # lead-in chamfer mouth
    b_in = jc.buffer(-LIP_CLR - LIP_T)   # ring inner (both regions)

    # 45 deg cone builder for the joint: boundary = b_out dilated by an
    # offset that shrinks 1:1 with y (warp-loft between true 2D offsets;
    # male and female share the construction, so they mate uniformly)
    bbp = b_out.bounds
    cxj, czj = (bbp[0] + bbp[2]) / 2, (bbp[1] + bbp[3]) / 2
    exj, ezj = (bbp[2] - bbp[0]) / 2, (bbp[3] - bbp[1]) / 2

    def cone45(off_hi, off_lo, y_start, y_pivot):
        h = (y_pivot - y_start) + (off_hi - off_lo)
        base = prof_extrude(b_out.buffer(off_hi), h).translate([0, y_start, 0])

        def f(v):
            x, y, z = v
            off = off_hi - min(max(y - y_pivot, 0), off_hi - off_lo)
            fx = (exj + off) / (exj + off_hi)
            fz = (ezj + off) / (ezj + off_hi)
            return (cxj + (x - cxj) * fx, y, czj + (z - czj) * fz)

        return base.refine(3).warp(f)

    # flare width: face ring minus a ~2.3 mm flat land at the crust rim
    W = extra + CAV_WALL + LIP_CLR - 2.3

    anchor = prof_extrude(b_wall, LIP_ANCHOR).translate([0, -LIP_ANCHOR, 0])
    spigot = prof_extrude(b_out, LIP_LEN - LIP_TIP)
    mouth = prof_extrude(b_tip, LIP_TIP).translate([0, LIP_LEN - LIP_TIP, 0])
    # male skirt: 45 deg flare from the spigot out to A's face (prints as
    # a widening cone above the spigot — no flat overhang ring)
    skirt = cone45(W, 0.0, JOINT_Y - 0.6, JOINT_Y - 0.1)
    # snap ridge: steep retention face toward A (faces UP in A's print,
    # so 90 deg is allowed there), 45 deg lead-in toward the tip
    ridge = cone45(RIDGE_H, 0.0, JOINT_Y + RIDGE_Y,
                   JOINT_Y + RIDGE_Y + 1.0).translate([0, -JOINT_Y, 0])
    lip = (anchor + spigot + mouth + ridge
           + skirt.translate([0, -JOINT_Y, 0])) \
        - prof_extrude(b_in, LIP_ANCHOR + LIP_LEN + 2).translate([0, -LIP_ANCHOR - 1, 0])
    lip = lip.translate([0, JOINT_Y, 0])
    lip -= capsule(BORE_R, BORE_L)       # keep the bread bore open at the joint
    # clear the hinge corner (the keep-tube makes B solid there)
    lip -= y_cyl(NOTCH_R + 2.6, JOINT_Y - LIP_ANCHOR - 1,
                 JOINT_Y + LIP_LEN + 1, x_axis, 0)
    lip = force(lip, "spigot lip")

    # female side: matching 45 deg countersink into B's socket mouth
    # (0.35 radial clearance), tapering to the straight socket wall jc;
    # the hinge corner keeps its flat butt face
    fem = cone45(W + 0.35, LIP_CLR, JOINT_Y + 0.05, JOINT_Y + 0.1)
    fem -= y_cyl(NOTCH_R + 2.6, JOINT_Y - 1, JOINT_Y + W + 2, x_axis, 0)
    trough -= fem
    lid -= fem

    # snap groove in B's socket wall: steep floor toward B's face (faces
    # UP in B's print — the retention face), 45 deg roof going deeper
    # (the overhang side). The ridge seats with 0.15 axial slack.
    gcut = cone45(LIP_CLR + 0.5, LIP_CLR,
                  JOINT_Y + RIDGE_Y - 0.15,
                  JOINT_Y + RIDGE_Y - 0.15 + 1.9)
    trough -= gcut
    lid -= gcut

    # backward 45 deg chamfer on A's entire face edge: everything
    # outboard of the skirt (crust rim, belt ends, hinge corner, barrel
    # stubs) recedes into A at 45 deg, leaving NO flat face ring at all.
    # It recedes away from B, so the mating is untouched; the seam gains
    # a small chamfer reveal on A's side.
    Wmax = W + 8.0
    K = Wmax - W
    prismA = prof_extrude(b_out.buffer(Wmax + 6), K) \
        .translate([0, JOINT_Y - 0.1 - K, 0])
    coneA = cone45(Wmax, W, JOINT_Y - 0.1 - K - 0.3, JOINT_Y - 0.1 - K)
    cham = prismA - coneA
    trough -= cham
    lid -= cham
    trough = force(trough, "joint cones")

    return trough, lid, lip, x_axis, D


CUT_A = box(-300, -400, -300, 300, JOINT_Y - JOINT_GAP / 2, 300)
CUT_B = box(-300, JOINT_Y + JOINT_GAP / 2, -300, 300, 400, 300)
Z_LO = box(-300, -400, -300, 300, 400, 0)   # trough (parting) half
Z_HI = box(-300, -400, 0, 300, 400, 300)     # lid half


def segment_A(trough, lid, lip, x_axis):
    """Segment A, open butterfly: its own crust plus the integrated spigot,
    split across the parting plane so each half carries its lip arc."""
    a_tr = (trough ^ CUT_A) + (lip ^ Z_LO)
    a_ld = (lid ^ CUT_A) + (lip ^ Z_HI)
    return a_tr + open_about(a_ld, x_axis, 180)


def segment_B(trough, lid, x_axis):
    return (trough ^ CUT_B) + open_about(lid ^ CUT_B, x_axis, 180)


# ---------- verification ----------
def verify(trough, lid, lip, x_axis, D):
    ok = True
    print("hinge sweep collision check (mm^3):")
    for th in (0, 15, 30, 60, 90, 120, 150, 180):
        vol = (open_about(lid, x_axis, th) ^ trough).volume()
        flag = ""
        if vol > 0.5:
            flag, ok = "  << COLLISION", False
        print(f"  theta={th:3d}  vol={vol:9.3f}{flag}")

    # spigot must slide into B's socket without interference
    clr = (lip ^ ((trough + lid) ^ CUT_B)).volume()
    print(f"spigot-to-socket interference: {clr:.3f} mm^3")
    if clr > 0.5:
        ok = False

    # bore must stay open through the joint (spigot is a ring, not a plug)
    bore_blocked = (capsule(BORE_R - 0.5, BORE_L) ^ lip).volume()
    print(f"spigot blocking the bore: {bore_blocked:.3f} mm^3")
    if bore_blocked > 0.5:
        ok = False

    for name, seg in (("segment A", segment_A(trough, lid, lip, x_axis)),
                      ("segment B", segment_B(trough, lid, x_axis))):
        bb = np.asarray(seg.bounding_box())
        size = bb[3:] - bb[:3]
        fits = size[1] <= 320.01 and size[0] <= 325.01
        print(f"{name}: vertical print {size[0]:.1f} x {size[2]:.1f} mm "
              f"plan, {size[1]:.1f} mm tall  {'ok' if fits else '<< EXCEEDS'}")
        ok &= fits
        tm = to_trimesh(seg)
        print(f"  watertight: {tm.is_watertight}   "
              f"mass ~{seg.volume() * PLA_G_CM3 / 1000:.0f} g PLA")
        ok &= tm.is_watertight
    return ok


# ---------- main ----------
CREAM = (0.93, 0.88, 0.78)
CRUST_C = (0.79, 0.56, 0.30)


def main():
    mode = sys.argv[1] if len(sys.argv) > 1 else "preview"
    set_circular_segments(64 if mode == "final" else 24)

    trough, lid, lip, x_axis, D = build(mode)
    ok = verify(trough, lid, lip, x_axis, D)

    # vertical print poses: stand each open segment on its joint face
    segs = {}
    for name, seg0, rot in (
            ("A", segment_A(trough, lid, lip, x_axis), [-90, 0, 0]),
            ("B", segment_B(trough, lid, x_axis), [90, 0, 0])):
        seg = seg0.rotate(rot)
        bb = np.asarray(seg.bounding_box())
        segs[name] = seg.translate([0, 0, -bb[2]])

    closed = trough + lid + lip

    print("rendering ...")
    render([(to_trimesh(segs["A"].translate([-120, 0, 0])), CREAM),
            (to_trimesh(segs["B"].translate([120, 0, 0])), CREAM)],
           OUT_DIR / "baguette_v2_print_plate.png", elev=8, azim=-50)
    render([(to_trimesh(closed), CRUST_C)],
           OUT_DIR / "baguette_v2_closed.png", elev=16, azim=-55)
    half = box(-300, -400, -300, 300, -30, 300)
    render([(to_trimesh(closed - half), CRUST_C),
            (to_trimesh(closed ^ half.translate([0, 0.01, 0])), CREAM)],
           OUT_DIR / "baguette_v2_section.png", elev=10, azim=-35)

    if mode == "final":
        to_trimesh(segs["A"]).export(OUT_DIR / "baguette_v2_seg_A.stl")
        to_trimesh(segs["B"]).export(OUT_DIR / "baguette_v2_seg_B.stl")
        write_3mf(OUT_DIR / "baguette_v2.3mf",
                  [("Segment A", to_trimesh(segs["A"].translate([-120, 0, 0]))),
                   ("Segment B", to_trimesh(segs["B"].translate([120, 0, 0])))])
        print("  wrote baguette_v2_seg_A.stl / baguette_v2_seg_B.stl / "
              "baguette_v2.3mf")

    print("OK" if ok else "CHECKS FAILED")
    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
