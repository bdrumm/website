#!/usr/bin/env python3
"""Crossbody baguette case — parametric, print-in-place hinge, no hardware.

A 630 mm clamshell tube for a French baguette (55-65 cm, Ø50-60 mm) that
opens lengthwise and has two strap lugs for a 25 mm crossbody webbing strap.

Built for a Bambu Lab H2C (325 x 320 x 320 usable): the case is TWO mirrored
315 mm segments, each printed as a single piece lying open like a book —
trough + lid joined by a full-length print-in-place barrel hinge (Ø4 pin
fused into the trough knuckles, Ø4.9 clearance holes in the lid knuckles).
Knuckle interdigitation clearance is cut as cylinders AROUND THE HINGE AXIS,
so the moving half clears at every opening angle by construction. (The
notches leave small slits at the seam near the hinge — free ventilation.)

Parts printed:  baguette_seg_A.stl (x1), baguette_seg_B.stl (x1, mirror),
                baguette_splice.stl (x1 U-channel joining the two troughs)

Geometry is exact CSG via manifold3d (no voxels), exported with trimesh.

Usage:
  .venv/bin/python baguette_case.py preview   # coarse circles, PNGs + checks
  .venv/bin/python baguette_case.py final     # smooth, STL + 3MF + PNGs
"""
import sys
import zipfile
from pathlib import Path

import numpy as np
import shapely
import shapely.geometry as sg
from manifold3d import CrossSection, Manifold, set_circular_segments
import trimesh

OUT_DIR = Path(__file__).resolve().parent

# ---- core dimensions (mm) ----
BORE = 64.0          # internal width & height of closed case (baguette Ø50-60)
WALL = 2.4           # shell wall / floor thickness
SEG_L = 315.0        # one segment (x2 = 630 outer, ~625 internal length)
R_OUT = 10.0         # outer corner radius of the closed rounded-square profile
GAP = 7.0            # open-state gap between the two half-shells at the hinge

W_OUT = BORE + 2 * WALL          # 68.8 outer width
RIM = W_OUT / 2.0                # 34.4 half-height; hinge axis height = rim
X0 = GAP / 2.0                   # trough inner edge (lid mirrored at -X0)

# ---- hinge ----
N_KNUCKLE = 15       # odd; trough owns both ends so the lid is captured
K_GAP = 0.4          # axial clearance between knuckles
BARREL_R = 4.0
PIN_R = 2.0
PIN_HOLE_R = 2.45    # lid knuckle bore (0.45 radial clearance)
SAG_Z = 0.35         # bores also cut shifted up: slack for bridge sag
ARM_Z = 4.5          # knuckle arm depth below rim
NOTCH_R = 8.2        # opposite-shell clearance cylinder about the axis

# ---- latch (two flex tabs per segment, on the lid) ----
TAB_Y = (70.0, 245.0)   # tab centers along the segment
TAB_W = 16.0
TAB_T = 1.6             # tab thickness -> flex strain ~1.3% at 0.6 mm travel
TAB_H = 16.0            # tab extent above rim
BUMP_R = 1.2
BUMP_Z = 13.0           # bump center above rim (flex arm ~10.4 mm)
GROOVE_D = 1.3          # groove depth in trough wall
GROOVE_CLR = 0.4        # extra groove width each side

# ---- strap lug (one per segment near the closed end) ----
LUG_Y = (13.0, 47.0)    # y-extent of the block
LUG_OUT = 9.7           # protrusion beyond the trough wall
LUG_Z = (20.0, 32.4)    # block z-extent (top just below rim)
LUG_SLOT_W = 27.0       # clip/webbing slot (25 mm webbing + slack)
LUG_BAR_T = 3.0

# ---- segment coupling ----
REB_L = 14.0            # female rebate depth at the coupling end
REB_T = 1.3             # rebate cut into the wall (leaves 1.1)
SPL_CLR = 0.15          # splice-to-rebate clearance
SPL_T = 1.15            # splice channel wall thickness

# ---- vents (through the lid's flat face, printed on the bed) ----
VENT_Y = (45.0, 125.0, 190.0, 270.0)
VENT_L, VENT_W = 34.0, 5.0

PLA_G_CM3 = 1.24


# ---------- 2D helpers (shapely -> CrossSection) ----------
def cs_of(poly):
    """shapely Polygon (no holes) -> manifold CrossSection."""
    p = shapely.geometry.polygon.orient(poly, 1.0)
    return CrossSection([np.asarray(p.exterior.coords)[:-1]])


def rounded_rect(x0, y0, x1, y1, r):
    return sg.box(x0 + r, y0 + r, x1 - r, y1 - r).buffer(r, quad_segs=8)


def half_outer_profile():
    """Bottom half of the closed rounded-square; rim edge square at z=RIM."""
    full = rounded_rect(0, 0, W_OUT, W_OUT, R_OUT)
    return full.intersection(sg.box(0, 0, W_OUT, RIM))


def cavity_profile(grow=0.0):
    """Bore half-profile (optionally dilated), opened well past the rim."""
    r = max(R_OUT - WALL + grow, 0.5)
    full = rounded_rect(WALL - grow, WALL - grow,
                        W_OUT - WALL + grow, W_OUT, r)
    return full.intersection(sg.box(-5, WALL - grow, W_OUT + 5, RIM + 5))


def prof_extrude(poly, length):
    """Extrude an XZ profile along +Y over [0, length]."""
    m = Manifold.extrude(cs_of(poly), length)      # profile in XY, runs +Z
    return m.rotate([90, 0, 0]).translate([0, length, 0])


def xz_wedge(pts, y0, y1):
    """Triangle/polygon in the XZ plane extruded over y in [y0, y1]."""
    m = Manifold.extrude(CrossSection([pts]), y1 - y0)
    return m.rotate([90, 0, 0]).translate([0, y1, 0])


def y_cyl(r, y0, y1, x, z):
    """Cylinder of radius r along +Y from y0 to y1, centered at (x, z)."""
    c = Manifold.cylinder(y1 - y0, r).rotate([-90, 0, 0])
    return c.translate([x, y0, z])


def box(x0, y0, z0, x1, y1, z1):
    return Manifold.cube([x1 - x0, y1 - y0, z1 - z0]).translate([x0, y0, z0])


# ---------- hinge layout ----------
def knuckle_spans():
    """[(y0, y1, owner)]; owner 'A' = trough, 'B' = lid. A at both ends."""
    k = (SEG_L - (N_KNUCKLE - 1) * K_GAP) / N_KNUCKLE
    spans, y = [], 0.0
    for i in range(N_KNUCKLE):
        spans.append((y, y + k, 'A' if i % 2 == 0 else 'B'))
        y += k + K_GAP
    return spans


def knuckle(y0, y1):
    """Barrel on the hinge axis + arm reaching into the shell wall."""
    return y_cyl(BARREL_R, y0, y1, 0, RIM) \
        + box(0, y0, RIM - ARM_Z, X0 + WALL + 0.4, y1, RIM)


# ---------- part builders (print orientation: open flat, +Z up) ----------
def shell_body():
    """Half-shell trough, cavity up, closed end wall at y=0, rebate at y=L."""
    body = prof_extrude(half_outer_profile(), SEG_L) \
        - prof_extrude(cavity_profile(), SEG_L - WALL).translate([0, WALL, 0])
    body -= prof_extrude(cavity_profile(REB_T), REB_L) \
        .translate([0, SEG_L - REB_L, 0])
    return body.translate([X0, 0, 0])


def build_trough():
    body = shell_body()
    for y0, y1, owner in knuckle_spans():
        if owner == 'A':
            body += knuckle(y0, y1)
        else:  # carve the lid knuckle's swing envelope out of our rim
            body -= y_cyl(NOTCH_R, y0 - K_GAP, y1 + K_GAP, 0, RIM)
    body += y_cyl(PIN_R, 3.0, SEG_L - 3.0, 0, RIM)   # pin, fused to trough

    # latch grooves: the lid bump lands at z = RIM - BUMP_Z when closed
    xw = X0 + W_OUT
    gz = RIM - BUMP_Z
    for ty in TAB_Y:
        gw = TAB_W / 2 + GROOVE_CLR
        body -= box(xw - GROOVE_D, ty - gw, gz - BUMP_R - 0.5,
                    xw + 1, ty + gw, gz + BUMP_R + 0.5)

    # strap lug: block + ~46 deg support wedge, vertical slot cut through
    lug = box(xw - 1, LUG_Y[0], LUG_Z[0], xw + LUG_OUT, LUG_Y[1], LUG_Z[1])
    lug += xz_wedge([(xw - 1, 9.0), (xw + LUG_OUT, LUG_Z[0] + 0.01),
                     (xw - 1, LUG_Z[0] + 0.01)], LUG_Y[0], LUG_Y[1])
    sy0 = (LUG_Y[0] + LUG_Y[1] - LUG_SLOT_W) / 2
    slot = box(xw + 2.5, sy0, -1,
               xw + LUG_OUT - LUG_BAR_T, sy0 + LUG_SLOT_W, RIM)
    return body + lug - slot


def build_lid():
    body = shell_body()
    for y0, y1, owner in knuckle_spans():
        if owner == 'B':
            bore = y_cyl(PIN_HOLE_R, y0 - 1, y1 + 1, 0, RIM) \
                + y_cyl(PIN_HOLE_R, y0 - 1, y1 + 1, 0, RIM + SAG_Z)
            body += knuckle(y0, y1) - bore
        else:
            body -= y_cyl(NOTCH_R, y0 - K_GAP, y1 + K_GAP, 0, RIM)

    # latch tabs: root bridges outward from the wall top, thin tab rises,
    # bump on the inner face snaps into the trough groove when closed
    xw = X0 + W_OUT
    for ty in TAB_Y:
        y0, y1 = ty - TAB_W / 2, ty + TAB_W / 2
        # root below the rim spans the wall; above the rim it steps outboard
        # (x > wall exterior + 0.3) so it clears the trough wall when closed
        root = box(xw - WALL, y0, RIM - 3, xw + 2.2, y1, RIM) \
            + box(xw + 0.3, y0, RIM, xw + 2.2, y1, RIM + 2.6)
        cham = xz_wedge([(xw, RIM - 5.2), (xw + 2.2, RIM - 3),
                         (xw, RIM - 3)], y0, y1)
        tab = box(xw + 2.2 - TAB_T, y0, RIM + 2.6, xw + 2.2, y1, RIM + TAB_H)
        bump = y_cyl(BUMP_R, y0, y1, xw + 2.2 - TAB_T, RIM + BUMP_Z)
        body += root + cham + tab + bump

    # vents through the flat base (prints face-down on the bed: clean holes)
    for vy in VENT_Y:
        for cx in (X0 + W_OUT / 2 - 12, X0 + W_OUT / 2 + 12):
            v = rounded_rect(cx - VENT_W / 2, vy - VENT_L / 2,
                             cx + VENT_W / 2, vy + VENT_L / 2, VENT_W / 2 - 0.01)
            body -= Manifold.extrude(cs_of(v), WALL + 2).translate([0, 0, -1])

    return body.mirror([1, 0, 0])   # lid lives at x < -X0 in print orientation


def build_splice():
    """U-channel that bridges the two trough rebates at the mid joint."""
    outer = cavity_profile(REB_T - SPL_CLR)
    inner = cavity_profile(REB_T - SPL_CLR - SPL_T)
    prof = outer.difference(inner).intersection(
        sg.box(-5, 0, W_OUT + 5, RIM - 0.4))
    return prof_extrude(prof, 2 * REB_L - 0.6).translate([X0, 0, 0])


# ---------- poses ----------
def close_lid(lid, theta=180.0):
    """Rotate the lid about the hinge axis (x=0, z=RIM) by theta degrees."""
    return lid.translate([0, 0, -RIM]).rotate([0, theta, 0]) \
              .translate([0, 0, RIM])


def to_trimesh(m):
    mesh = m.to_mesh()
    return trimesh.Trimesh(
        vertices=np.asarray(mesh.vert_properties)[:, :3],
        faces=np.asarray(mesh.tri_verts), process=False)


# ---------- verification ----------
def verify(trough, lid):
    ok = True
    print("hinge sweep collision check (intersection volume, mm^3):")
    for th in (0, 30, 60, 90, 120, 150, 165, 175, 180):
        vol = (close_lid(lid, th) ^ trough).volume()
        flag = ""
        if th <= 165 or th == 180:
            if vol > 0.5:
                flag, ok = "  << COLLISION", False
        else:
            flag = "  (snap interference — tab flexes over this)"
        print(f"  theta={th:3d}  vol={vol:9.3f}{flag}")

    seg = trough + lid
    bb = np.asarray(seg.bounding_box())
    size = bb[3:] - bb[:3]
    print(f"print footprint: {size[0]:.1f} x {size[1]:.1f} x {size[2]:.1f} mm")
    if size[0] > 325 or size[1] > 320:
        print("  << EXCEEDS H2C BED"); ok = False

    tm = to_trimesh(seg)
    print(f"watertight: {tm.is_watertight}   "
          f"segment mass ~{seg.volume() * PLA_G_CM3 / 1000:.0f} g PLA")
    if not tm.is_watertight:
        ok = False
    return ok


# ---------- render (house style, after planter.py) ----------
def render(meshes_colors, path, elev=18, azim=-60):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from mpl_toolkits.mplot3d.art3d import Poly3DCollection

    fig = plt.figure(figsize=(10, 7), dpi=130)
    ax = fig.add_subplot(111, projection="3d")
    light = np.array([0.45, -0.5, 0.75]); light /= np.linalg.norm(light)
    lo = np.full(3, 1e9); hi = np.full(3, -1e9)
    for m, base in meshes_colors:
        tris = m.vertices[m.faces]
        lam = np.clip(m.face_normals @ light, 0, 1)[:, None]
        cols = np.clip(np.array(base)[None, :3] * (0.35 + 0.65 * lam), 0, 1)
        ax.add_collection3d(Poly3DCollection(tris, facecolors=cols,
                                             edgecolors="none"))
        lo = np.minimum(lo, m.vertices.min(0)); hi = np.maximum(hi, m.vertices.max(0))
    c, half = (lo + hi) / 2, (hi - lo).max() / 2
    ax.set_xlim(c[0] - half, c[0] + half)
    ax.set_ylim(c[1] - half, c[1] + half)
    ax.set_zlim(c[2] - half, c[2] + half)
    ax.set_box_aspect((1, 1, 1)); ax.view_init(elev=elev, azim=azim)
    ax.axis("off"); fig.tight_layout(pad=0)
    fig.savefig(path, facecolor="#e8e8ea"); plt.close(fig)
    print(f"  wrote {path}")


# ---------- 3mf export (after planter.py) ----------
def write_3mf(path, objects):
    def mesh_xml(obj_id, name, m):
        vs = "".join(f'<vertex x="{x:.3f}" y="{y:.3f}" z="{z:.3f}"/>'
                     for x, y, z in m.vertices)
        ts = "".join(f'<triangle v1="{a}" v2="{b}" v3="{c}"/>'
                     for a, b, c in m.faces)
        return (f'<object id="{obj_id}" name="{name}" type="model">'
                f"<mesh><vertices>{vs}</vertices>"
                f"<triangles>{ts}</triangles></mesh></object>")

    model = (
        '<?xml version="1.0" encoding="UTF-8"?>'
        '<model unit="millimeter" xml:lang="en-US" '
        'xmlns="http://schemas.microsoft.com/3dmanufacturing/core/2015/02">'
        "<resources>"
        + "".join(mesh_xml(i + 1, n, m) for i, (n, m) in enumerate(objects))
        + "</resources><build>"
        + "".join(f'<item objectid="{i + 1}"/>' for i in range(len(objects)))
        + "</build></model>")
    content_types = (
        '<?xml version="1.0" encoding="UTF-8"?>'
        '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
        '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
        '<Default Extension="model" ContentType="application/vnd.ms-package.3dmanufacturing-3dmodel+xml"/>'
        "</Types>")
    rels = (
        '<?xml version="1.0" encoding="UTF-8"?>'
        '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
        '<Relationship Target="/3D/3dmodel.model" Id="rel-1" '
        'Type="http://schemas.microsoft.com/3dmanufacturing/2013/01/3dmodel"/>'
        "</Relationships>")
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("[Content_Types].xml", content_types)
        z.writestr("_rels/.rels", rels)
        z.writestr("3D/3dmodel.model", model)
    print(f"  wrote {path}")


# ---------- main ----------
CREAM = (0.93, 0.88, 0.78)
CRUST = (0.78, 0.55, 0.30)
STEEL = (0.62, 0.66, 0.70)


def main():
    mode = sys.argv[1] if len(sys.argv) > 1 else "preview"
    set_circular_segments(64 if mode == "final" else 24)

    print("building segment A ...")
    trough, lid = build_trough(), build_lid()
    splice = build_splice()
    ok = verify(trough, lid)

    seg_open = trough + lid
    seg_closed = trough + close_lid(lid)

    # assembled closed case: A + mirrored B butted at the mid joint
    seg_b_closed = seg_closed.mirror([0, 1, 0]).translate([0, 2 * SEG_L, 0])
    assembly = seg_closed + seg_b_closed

    print("rendering ...")
    render([(to_trimesh(seg_open), CREAM),
            (to_trimesh(splice.translate([90, 40, 0])), CRUST)],
           OUT_DIR / "baguette_print_plate.png", elev=35, azim=-70)
    render([(to_trimesh(assembly), CREAM)],
           OUT_DIR / "baguette_closed.png", elev=16, azim=-55)
    half = box(-30, -5, -5, X0 + W_OUT + 30, SEG_L / 2, W_OUT + 40)
    render([(to_trimesh(seg_closed - half), CREAM),
            (to_trimesh(seg_closed ^ half.translate([0, 0.01, 0])), CRUST)],
           OUT_DIR / "baguette_section.png", elev=10, azim=-35)

    if mode == "final":
        seg_a = seg_open
        seg_b = seg_open.mirror([0, 1, 0]).translate([0, SEG_L, 0])
        to_trimesh(seg_a).export(OUT_DIR / "baguette_seg_A.stl")
        to_trimesh(seg_b).export(OUT_DIR / "baguette_seg_B.stl")
        to_trimesh(splice).export(OUT_DIR / "baguette_splice.stl")
        print("  wrote baguette_seg_A.stl / baguette_seg_B.stl / baguette_splice.stl")
        write_3mf(OUT_DIR / "baguette_case.3mf",
                  [("Segment A", to_trimesh(seg_a)),
                   ("Segment B", to_trimesh(seg_b.translate([180, 0, 0]))),
                   ("Splice", to_trimesh(splice.translate([-60, 0, 0])))])

    print("OK" if ok else "CHECKS FAILED")
    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
