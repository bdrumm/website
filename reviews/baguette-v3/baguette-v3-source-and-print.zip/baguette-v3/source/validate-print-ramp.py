"""Check leading latch growth against the preceding CAD layer, without supports."""
from pathlib import Path
import hashlib,json,math,sys
import numpy as np
from shapely.geometry import Polygon
from shapely.ops import unary_union
sys.path.insert(0,str(Path(__file__).resolve().parent))
import baguette_v3 as v

def polygons(section):
    result=[]
    for piece in section.decompose():
        rings=piece.to_polygons()
        if not rings:continue
        rings=sorted(rings,key=lambda r:abs(Polygon(r).area),reverse=True)
        result.append(Polygon(rings[0],rings[1:]))
    return unary_union(result)

parts,prints,features,*_=v.build()
rows=[]
for f in features:
    side='B' if f['print_up_y']>0 else 'A';up=f['print_up_y']
    tongue=f['solid'].rotate([90*up,0,0]);lid=parts['lid_'+side].rotate([90*up,0,0])
    step=v.P['layer_mm'];start=math.floor(tongue.bounding_box()[2]/step)*step
    end=abs(f['y'])-2
    samples=[]
    for height in np.arange(start,end+step/2,step):
        current=polygons(tongue.slice(float(height)))
        if current.is_empty:continue
        previous=polygons(lid.slice(float(height-step)))
        # 45 degrees permits one horizontal millimetre per vertical mm.
        unsupported=current.difference(previous.buffer(step,quad_segs=16))
        relaxed=current.difference(previous.buffer(step+.015,quad_segs=16))
        samples.append({'print_axis_height_mm':float(height),'unsupported_at_45_mm2':unsupported.area,'unsupported_with_0p015_mm_allowance_mm2':relaxed.area})
    mesh=v.to_trimesh(f['solid']);down=np.array([0,-up,0])
    mask=(mesh.triangles_center[:,1]*up<end)&(mesh.triangles_center[:,2]<7.5)&(mesh.area_faces>.001)
    cosines=mesh.face_normals[mask]@down
    overhang=np.degrees(np.arcsin(np.clip(cosines,0,1)))
    bad=(overhang>45.1)
    row={'side':side,'sample_count':len(samples),'maximum_leading_face_overhang_degrees':float(overhang.max()),'leading_face_area_above_45_degrees_mm2':float(mesh.area_faces[mask][bad].sum()),'maximum_unsupported_area_mm2':max(s['unsupported_at_45_mm2'] for s in samples),'maximum_unsupported_area_with_allowance_mm2':max(s['unsupported_with_0p015_mm_allowance_mm2'] for s in samples),'worst_layers':sorted(samples,key=lambda s:s['unsupported_at_45_mm2'],reverse=True)[:8]}
    rows.append(row);print(json.dumps(row,indent=2),flush=True)
passed=all(r['leading_face_area_above_45_degrees_mm2']<.01 and r['maximum_unsupported_area_with_allowance_mm2']<.01 for r in rows)
report={'generator_sha256':hashlib.sha256(Path(v.__file__).read_bytes()).hexdigest(),'scope':'Leading latch tongue, hook and grip, through two millimetres before each latch center. Actual unloaded connection-down geometry; no support material included.','layer_mm':v.P['layer_mm'],'horizontal_growth_ratio':1,'numerical_allowance_mm':.015,'passed':passed,'results':rows}
(v.ROOT/'output/print-ramp-review.json').write_text(json.dumps(report,indent=2)+'\n')
assert passed,'The leading latch ramp still has unsupported growth or a face above 45 degrees'
