import * as T from 'three';
import {GLTFExporter} from 'three/addons/exporters/GLTFExporter.js';
import {mergeVertices} from 'three/addons/utils/BufferGeometryUtils.js';
import {readFile,writeFile} from 'node:fs/promises';
import {gzipSync} from 'node:zlib';
globalThis.FileReader=class{readAsArrayBuffer(blob){blob.arrayBuffer().then(result=>{this.result=result;this.onloadend?.();});}};
const data=JSON.parse(await readFile(new URL('../output/assembly.json',import.meta.url),'utf8'));
const review=JSON.parse(await readFile(new URL('../output/review.json',import.meta.url),'utf8'));
const root=new T.Group();root.name='BaguetteV3';const hinge=new T.Group();hinge.name='LidHinge';hinge.position.fromArray(data.axis);root.add(hinge);
const material=new T.MeshPhysicalMaterial({name:'Prototype PLA',color:'#cba567',roughness:.48,metalness:.06,clearcoat:.12});
const socketMaterial=new T.MeshStandardMaterial({name:'Segment B section',color:'#896245',roughness:.55});
// Area weighting prevents tiny fillet triangles from pulling the normals of
// large neighboring shell faces into visible shading fans.
function weightedCreases(raw,angle){
 const p=raw.getAttribute('position'),indices=raw.index.array,faces=[],adjacent=new Map();
 const key=i=>[p.getX(i),p.getY(i),p.getZ(i)].join(',');
 for(let j=0;j<indices.length;j+=3){
  const ids=Array.from(indices.slice(j,j+3));const a=new T.Vector3().fromBufferAttribute(p,ids[0]),b=new T.Vector3().fromBufferAttribute(p,ids[1]),c=new T.Vector3().fromBufferAttribute(p,ids[2]);
  const weighted=b.sub(a).cross(c.sub(a)),normal=weighted.clone().normalize(),f={ids,weighted,normal};faces.push(f);
  for(const i of ids){const k=key(i);if(!adjacent.has(k))adjacent.set(k,[]);adjacent.get(k).push(f);}
 }
 const xyz=[],normals=[],threshold=Math.cos(angle);
 for(const f of faces)for(const i of f.ids){
  const n=new T.Vector3();for(const other of adjacent.get(key(i)))if(f.normal.dot(other.normal)>threshold)n.add(other.weighted);
  n.normalize();xyz.push(p.getX(i),p.getY(i),p.getZ(i));normals.push(n.x,n.y,n.z);
 }
 const g=new T.BufferGeometry();g.setAttribute('position',new T.Float32BufferAttribute(xyz,3));g.setAttribute('normal',new T.Float32BufferAttribute(normals,3));return g;
}
const sections=JSON.parse(await readFile(new URL('../output/hinge-sections.json',import.meta.url),'utf8'));
for(const part of [...data.parts,...sections]){
 const raw=new T.BufferGeometry();
 const positions=part.vertices.map(v=>v.map(x=>Math.round(x*100)/100));
 // Quantization can collapse microscopic CAD triangles. Exclude only those
 // zero-area display faces before they can corrupt neighboring smooth normals.
 const faces=part.triangles.filter(([a,b,c])=>{
  const ab=new T.Vector3().fromArray(positions[b]).sub(new T.Vector3().fromArray(positions[a]));
  const ac=new T.Vector3().fromArray(positions[c]).sub(new T.Vector3().fromArray(positions[a]));
  return ab.cross(ac).lengthSq()>1e-12;
 });
 raw.setAttribute('position',new T.Float32BufferAttribute(positions.flat(),3));raw.setIndex(faces.flat());
 const creased=weightedCreases(raw,T.MathUtils.degToRad(45));const g=mergeVertices(creased,1e-5);g.normalizeNormals();raw.dispose();creased.dispose();
 const normals=g.getAttribute('normal'),packed=new Int8Array(normals.count*3);
 for(let i=0;i<normals.count;i++){const n=new T.Vector3().fromBufferAttribute(normals,i);if(n.lengthSq()<1e-8)n.set(0,1,0);n.normalize();packed[i*3]=Math.round(n.x*127);packed[i*3+1]=Math.round(n.y*127);packed[i*3+2]=Math.round(n.z*127);}
 g.setAttribute('normal',new T.Int8BufferAttribute(packed,3,true));
 const isLid=part.name.startsWith('lid')||part.name.startsWith('sleeve_lid');
 if(part.name.startsWith('lid')&&!part.reviewSection){
  const target=g.attributes.position.clone();
  for(let i=0;i<target.count;i++){
   const x=target.getX(i),y=target.getY(i);let z=target.getZ(i);
   for(const f of review.latches){
    if(Math.abs(x-f.y)<review.parameters.latch_width/2+.1&&z>f.release_min_x&&(!('release_plane_constant' in f)||z+f.print_up_y*x>f.release_plane_constant-.01)){
     const q=T.MathUtils.clamp((f.root_z-y)/(f.root_z-f.tip_z),0,1);z+=(review.release_travel_from_free_mm-f.preload_travel_mm)*q*q*(3-2*q);
    }
   }
   target.setZ(i,z);
  }
  g.morphAttributes.position=[target];
 }
 // Store preview positions as 0.01 mm signed integers. Mesh scale restores
 // millimetres; this preserves the CAD-derived surface while reducing transfer.
 function quantized(attribute){const a=new Int16Array(attribute.count*3);for(let i=0;i<attribute.count;i++)for(let j=0;j<3;j++){const value=Math.round(attribute.array[i*3+j]*100);if(value < -32768 || value >32767)throw new Error('Preview coordinate out of range');a[i*3+j]=value;}return new T.Int16BufferAttribute(a,3);}
 g.setAttribute('position',quantized(g.getAttribute('position')));
 if(g.morphAttributes.position)g.morphAttributes.position=g.morphAttributes.position.map(quantized);
 const mesh=new T.Mesh(g,part.name==='joint_section_B'?socketMaterial:material);mesh.name=part.name;mesh.scale.setScalar(.01);
 mesh.userData={part:part.name,manufacturingGeometry:!part.reviewSection,reviewSection:!!part.reviewSection,sectionType:part.sectionType||null};
 if(isLid){mesh.position.fromArray(data.axis).negate();hinge.add(mesh);}else root.add(mesh);
}
root.userData={revision:review.revision,generatorSha256:review.generator_sha256,maxOpenAngle:review.parameters.max_open_angle,previewToleranceMm:data.preview_tolerance_mm,previewCoordinateResolutionMm:.01,units:'millimetres',manufacturingGeometry:true};
const result=Buffer.from(await new GLTFExporter().parseAsync(root,{binary:true}));
await writeFile(new URL('../review/baguette-v3.glb',import.meta.url),result);
await writeFile(new URL('../review/baguette-v3.glb.gz',import.meta.url),gzipSync(result,{level:9}));
console.log('GLB',result.length,'gzip',gzipSync(result,{level:9}).length);
