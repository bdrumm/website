import * as T from 'three';
import {GLTFExporter} from 'three/addons/exporters/GLTFExporter.js';
import {toCreasedNormals,mergeVertices} from 'three/addons/utils/BufferGeometryUtils.js';
import {readFile,writeFile} from 'node:fs/promises';
import {gzipSync} from 'node:zlib';
globalThis.FileReader=class{readAsArrayBuffer(blob){blob.arrayBuffer().then(result=>{this.result=result;this.onloadend?.();});}};
const data=JSON.parse(await readFile(new URL('../output/assembly.json',import.meta.url),'utf8'));
const review=JSON.parse(await readFile(new URL('../output/review.json',import.meta.url),'utf8'));
const root=new T.Group();root.name='BaguetteV3';const hinge=new T.Group();hinge.name='LidHinge';hinge.position.fromArray(data.axis);root.add(hinge);
const material=new T.MeshPhysicalMaterial({name:'Prototype PLA',color:'#cba567',roughness:.48,metalness:.06,clearcoat:.12});
const socketMaterial=new T.MeshStandardMaterial({name:'Segment B section',color:'#896245',roughness:.55});
const sections=JSON.parse(await readFile(new URL('../output/hinge-sections.json',import.meta.url),'utf8'));
for(const part of [...data.parts,...sections]){
 const raw=new T.BufferGeometry();raw.setAttribute('position',new T.Float32BufferAttribute(part.vertices.flat().map(x=>Math.round(x*1000)/1000),3));raw.setIndex(part.triangles.flat());
 const creased=toCreasedNormals(raw,T.MathUtils.degToRad(45));const g=mergeVertices(creased,1e-5);g.normalizeNormals();raw.dispose();creased.dispose();
 const normals=g.getAttribute('normal'),packed=new Int16Array(normals.count*3);
 for(let i=0;i<normals.count;i++){const n=new T.Vector3().fromBufferAttribute(normals,i);if(n.lengthSq()<1e-8)n.set(0,1,0);n.normalize();packed[i*3]=Math.round(n.x*32767);packed[i*3+1]=Math.round(n.y*32767);packed[i*3+2]=Math.round(n.z*32767);}
 g.setAttribute('normal',new T.Int16BufferAttribute(packed,3,true));
 const isLid=part.name.startsWith('lid')||part.name.startsWith('sleeve_lid');
 if(part.name.startsWith('lid')&&!part.reviewSection){
  const target=g.attributes.position.clone();
  for(let i=0;i<target.count;i++){
   const x=target.getX(i),y=target.getY(i);let z=target.getZ(i);
   for(const f of review.latches){
    if(Math.abs(x-f.y)<review.parameters.latch_width/2+.1&&z>f.release_min_x){
     const q=T.MathUtils.clamp((f.root_z-y)/(f.root_z-f.tip_z),0,1);z+=review.parameters.release_travel*q*q*(3-2*q);
    }
   }
   target.setZ(i,z);
  }
  g.morphAttributes.position=[target];
 }
 const mesh=new T.Mesh(g,part.name==='joint_section_B'?socketMaterial:material);mesh.name=part.name;
 mesh.userData={part:part.name,manufacturingGeometry:!part.reviewSection,reviewSection:!!part.reviewSection,sectionType:part.sectionType||null};
 if(isLid){mesh.position.fromArray(data.axis).negate();hinge.add(mesh);}else root.add(mesh);
}
root.userData={revision:review.revision,generatorSha256:review.generator_sha256,maxOpenAngle:review.parameters.max_open_angle,previewToleranceMm:data.preview_tolerance_mm,units:'millimetres',manufacturingGeometry:true};
const result=Buffer.from(await new GLTFExporter().parseAsync(root,{binary:true}));
await writeFile(new URL('../review/baguette-v3.glb',import.meta.url),result);
await writeFile(new URL('../review/baguette-v3.glb.gz',import.meta.url),gzipSync(result,{level:9}));
console.log('GLB',result.length,'gzip',gzipSync(result,{level:9}).length);
