from pathlib import Path
import sys,json,hashlib,math
sys.path.insert(0,str(Path(__file__).resolve().parent))
import baguette_v3 as v
parts,prints,features,axis,D,joint=v.build()
base=parts['base_A']+parts['base_B'];lid=parts['lid_A']+parts['lid_B'];all_shells=base+lid
report=json.loads((v.ROOT/'output/review.json').read_text())
checks=[]
def check(name,passed,detail):
 checks.append({'name':name,'passed':bool(passed),'detail':detail})
 if not passed:raise AssertionError(name+': '+str(detail))
for name,solid in parts.items():
 m=v.metrics(solid);check(name+' is one closed solid',m['components']==1 and m['watertight'] and m['consistent_winding'],m['components'])
for name,solid in prints.items():
 m=v.metrics(solid);expected=2 if name.startswith('segment') else 1
 check(name+' has the expected printable components',m['components']==expected and m['watertight'],m['components'])
 check(name+' fits a 300 x 320 x 325 mm envelope including 8 mm brim',all(a+pad<b for a,pad,b in zip(m['size_mm'],[16,16,0],[300,320,325])),m['size_mm'])
check('closed lid has no rigid interference',(base^lid).volume()<1e-4,(base^lid).volume())
free=v.released(lid,features,v.P['release_travel'])
# Review the complete joined base and lid, including their integral snap collars.
fixed=base
worst=0.;angle_worst=0
for angle in range(0,v.P['max_open_angle']+1,1):
 vol=(fixed^v.open_lid(free,axis,angle)).volume()
 if vol>worst:worst=vol;angle_worst=angle
check('released hinge sweep clears 0 to 100 degrees with integrated center joints',worst<1e-4,{'maximum_overlap_mm3':worst,'angle':angle_worst,'step_degrees':1})
bore=v.old.capsule(31,600)
blocked=sum((solid^bore).volume() for solid in parts.values())
check('62 mm x 600 mm capsule clearance is retained',blocked<1e-4,blocked)
# Compare with the unmodified outer shell, not the prior protruding barrels.
outer=v.base_geometry(True)[-1]
allowed,_=v.rim_profiles()
barrels=v.Manifold()
for cy in v.P['hinge_centers']:
 barrels+=v.y_cyl(v.P['hinge_radius'],cy-14-v.P['axial_clearance'],cy+14+v.P['axial_clearance'],axis,v.P['hinge_axis_z'])^allowed
check('both compact barrels are fully inside the original exterior',(barrels-outer).volume()<1e-5,(barrels-outer).volume())
hinge_side=(base+lid)^v.box(-150,-400,-100,-30,400,100)
residue=sum(abs(p.volume()) for p in (hinge_side-outer).decompose())
check('hinge side has no added exterior structure',residue<.05,{'absolute_boolean_residue_mm3':residue,'tolerance_mm3':.05})
for side in ('A','B'):
 b=parts['base_'+side];l=v.open_lid(parts['lid_'+side],axis,v.P['max_open_angle'])
 gap=b.min_gap(l,.5)
 check('segment '+side+' retains printable running clearance',gap>.24,{'minimum_gap_mm':gap})
check('exactly two latches, one per printed half',len(features)==2 and features[0]['y']<v.old.JOINT_Y<features[1]['y'],[f['y'] for f in features])
for f in features:
 y=f['y'];z=f['hook_shoulder_z'];label='latch at '+str(y)
 clip=v.box(30,y-12,-12,60,y+12,4)
 retained=((base^v.open_lid(lid,axis,.5))^clip).volume()
 check(label+' blocks opening without release',retained>4,{'rigid_interference_at_half_degree_mm3':retained})
 hook=lid^v.box(30,y-1,z-.2,60,y+1,z-.01)
 catch=base^v.box(30,y-1,z+.36,60,y+1,z+.55)
 overlap=catch.bounding_box()[3]-hook.bounding_box()[0]
 check(label+' has at least 1 mm of measured retaining overlap',overlap>1,{'local_overlap_x_mm':overlap})
 back=base^v.box(30,y-.1,-6.6,60,y+.1,-6.4)
 thickness=back.bounding_box()[3]-back.bounding_box()[0]
 check(label+' has a reinforced catch back wall',thickness>3.5,{'local_back_wall_x_mm':thickness})
 tongue_region=lid^v.box(25,y-12,-12,65,y+12,13)
 thumb_region=v.box(25,y-8.01,-10-v.P['thumb_underhang']-.01,65,y+8.01,-10+v.P['thumb_lip_height']+2.01)
 excess=(tongue_region-outer)-thumb_region
 residue=sum(abs(p.volume()) for p in excess.decompose())
 check(label+' follows the original outer surface except the thumb lip',residue<.01,{'exterior_residue_mm3':residue})
 underside=(lid-outer)^v.box(25,y-5,-12,65,y+5,-10)
 check(label+' has an integrated underside finger catch',underside.volume()>2 and underside.bounding_box()[2]<-10.5,{'underhang_mm':-10-underside.bounding_box()[2],'outside_material_below_original_tip_mm3':underside.volume()})
worst_release=max((base^v.released(lid,features,float(t))).volume() for t in v.np.linspace(0,v.P['release_travel'],22))
check('outward latch release clears the stationary closed base',worst_release<1e-4,{'maximum_overlap_mm3':worst_release,'sample_step_mm':.1})
# A distance bound covers the angles between samples, rather than assuming
# sampled non-intersection proves continuous motion. Rotation is rigid after
# the latches are released; the stationary base includes its integrated center joint.
step=.2
vertices=v.to_trimesh(free).vertices
radius=float(v.np.max(v.np.hypot(vertices[:,0]-axis,vertices[:,2]-v.P['hinge_axis_z'])))
gaps=[float(fixed.min_gap(v.open_lid(free,axis,float(a)),.5)) for a in v.np.linspace(0,v.P['max_open_angle'],501)]
bound=2*radius*math.sin(math.radians(step)/4)
numerical_allowance=.002
certificate={'sample_step_degrees':step,'sample_count':len(gaps),'minimum_sampled_gap_mm':min(gaps),'moving_radius_mm':radius,'between_sample_displacement_bound_mm':bound,'numerical_allowance_mm':numerical_allowance,'certified_minimum_gap_mm':min(gaps)-bound-numerical_allowance}
check('continuous released rotation clears the joined base',certificate['certified_minimum_gap_mm']>0,certificate)

# Close only designed openings for this diagnostic: four bottom vents and
# submillimetre seams. An enclosed air component must surround the bread bore.
# This morphological operation is never exported as manufacturing geometry.
sealed=all_shells
for y in (-200,-80,80,200):
 sealed+=outer^v.box(-4,y-16,-D-1,4,y+16,-D+6)
sealed=sealed.minkowski_sum(v.box(-.36,-.36,-.36,.36,.36,.36))
air=v.box(-100,-350,-100,100,350,100)-sealed
probe=v.box(-1,99,-1,1,101,1)
cavities=[c for c in air.decompose() if c.volume()>100 and c.bounding_box()[0]>-99 and (c^probe).volume()>7.9]
check('closed shell encloses the bread cavity after masking designed vents and seams',len(cavities)==1,{'enclosed_air_components':len(cavities),'analysis_seam_offset_mm':.36,'masked_vents':4,'cavity_volume_mm3':float(cavities[0].volume()) if cavities else 0})

# The bearing ring meets the rim directly, without an intermediate armature.
for cy in v.P['hinge_centers']:
 annulus=v.y_cyl(v.P['hinge_radius'],cy-8,cy+8,axis,v.P['hinge_axis_z'])-v.y_cyl(v.P['pin_radius']+v.P['radial_clearance'],cy-8,cy+8,axis,v.P['hinge_axis_z'])
 original_lid=v.base_geometry()[1]
 attachment=(annulus^original_lid).volume()
 check('hinge at '+str(cy)+' has direct bearing-to-shell attachment',attachment>10,{'bearing_shell_overlap_mm3':attachment,'nominal_bearing_wall_mm':v.P['hinge_radius']-v.P['pin_radius']-v.P['radial_clearance']})
# The analytic profile has matching positions and tangent directions where
# the rim circle meets each fillet, and each fillet meets the flat wall.
R=v.P['hinge_radius'];f=v.P['rim_blend_radius']
for side,d,R in [(-1,v.P['exterior_rim_axis_x']-v.P['rear_wall_outer_x'],v.P['exterior_rim_radius']),(1,v.P['rear_wall_inner_x']-axis,v.P['hinge_radius'])]:
 theta=math.acos((d+f)/(R+f));cz=math.sqrt((R+f)**2-(d+f)**2)
 tangent_circle=v.np.array([side*R*math.cos(theta),R*math.sin(theta)])
 tangent_fillet=v.np.array([side*(d+f-f*math.cos(theta)),cz-f*math.sin(theta)])
 tangent_error=float(v.np.linalg.norm(tangent_circle-tangent_fillet))
 n_circle=tangent_circle/R;n_fillet=(tangent_fillet-v.np.array([side*(d+f),cz]))/f
 alignment=abs(float(v.np.dot(n_circle,n_fillet)))
 check(('outside' if side<0 else 'inside')+' rim blend meets the bearing tangentially',tangent_error<1e-10 and alignment>1-1e-10,{'position_error_mm':tangent_error,'normal_alignment':alignment,'blend_radius_mm':f})
# The same rolled profile continues past the fixed-ear ends. These windows
# exclude the necessary axial working gaps and the lid/base parting seam.
_,wall=v.rim_profiles()
for cy in v.P['hinge_centers']:
 for end in (-1,1):
  yy=cy+end*(14+v.P['axial_clearance'])
  window=v.box(axis-4,yy-.2,-6,axis+4,yy+.2,-v.P['seam_gap']/2)
  expected=wall^outer^window
  missing=(expected-base).volume()
  check('fixed ear merges into the rim at Y '+str(yy),missing<1e-4,{'missing_profile_mm3':missing})
check('only four integral shells and two print objects remain',set(parts)=={'base_A','base_B','lid_A','lid_B'} and set(prints)=={'segment_A','segment_B'},list(parts))
check('eight one-way joint fingers, four per shell',len(joint)==8 and all(sum(f['part']==kind for f in joint)==4 for kind in ('base','lid')),[f['angle'] for f in joint])
socket=v.base_geometry()[4]
join_certificates={}
for kind in ('base','lid'):
 a=parts[kind+'_A'];b=parts[kind+'_B'];compressed=v.deflect_joint(a,socket,v.P['joint_deflection'])
 check(kind+' center joint seats without rigid overlap',(a^b).volume()<1e-4,{'overlap_mm3':(a^b).volume()})
 shift_gaps=[float(compressed.translate([0,float(d),0]).min_gap(b,.5)) for d in v.np.linspace(-v.P['joint_lip_length']-2,0,int((v.P['joint_lip_length']+2)*10)+1)]
 clear=min(shift_gaps)-.05-.002
 check(kind+' center joint has a continuously clear compressed insertion path',clear>0,{'sample_spacing_mm':.1,'minimum_sampled_gap_mm':min(shift_gaps),'between_sample_displacement_bound_mm':.05,'numerical_allowance_mm':.002,'certified_clearance_mm':clear,'modeled_tip_deflection_mm':v.P['joint_deflection']})
 restore_gaps=[float(v.deflect_joint(a,socket,float(t)).min_gap(b,.5)) for t in v.np.linspace(0,v.P['joint_deflection'],16)]
 check(kind+' joint fingers can return into the locking pockets',min(restore_gaps)-.05-.002>0,{'sample_spacing_mm':.1,'minimum_sampled_gap_mm':min(restore_gaps),'certified_clearance_mm':min(restore_gaps)-.05-.002})
 join_certificates[kind]={'insertion_certified_clearance_mm':clear,'restoration_certified_clearance_mm':min(restore_gaps)-.052}
 fingers=[f['finger'] for f in joint if f['part']==kind]
 static=a
 for finger in fingers:static-=finger
 worst_self=0.
 for finger in fingers:
  moved=v.deflect_joint(finger,socket,v.P['joint_deflection'])
  # The root is intentionally joined to its anchor; exclude its first .2 mm.
  clip=v.box(-100,v.old.JOINT_Y+v.P['joint_flex_start']+.2,-100,100,100,100)
  worst_self=max(worst_self,((moved^static)^clip).volume())
 check(kind+' joint fingers have room to flex from the flush root',worst_self<1e-4,{'maximum_self_interference_mm3':worst_self})
for f in joint:
 a=parts[f['part']+'_A'];b=parts[f['part']+'_B'];clip=v.sector(f['angle'],v.P['joint_finger_width_degrees']+1,f['shoulder_y']-2,f['tip_y']+1)
 retained=(a.translate([0,-.5,0])^b^clip).volume()
 check(f['part']+' snap at '+str(f['angle'])+' degrees blocks withdrawal',retained>.5,{'interference_after_half_mm_pull_mm3':retained,'nominal_radial_engagement_mm':f['nominal_radial_engagement_mm']})
 residual=(f['pocket'].minkowski_sum(v.Manifold.sphere(v.P['joint_outer_cover']+.01,32))-outer).volume()
 check(f['part']+' snap pocket at '+str(f['angle'])+' degrees retains exterior wall',residual<1e-4,{'minimum_checked_wall_mm':v.P['joint_outer_cover'],'outside_volume_mm3':residual})
# Covered pockets retain the inner skin and blind end; only the joining face opens.
inner_guard=(v.prof_extrude(socket,38).translate([0,v.old.JOINT_Y-19,0])+v.old.capsule(31,600)).minkowski_sum(v.Manifold.sphere(1.16,32))
for f in joint:
 label=f['part']+' covered snap at '+str(f['angle'])
 cavities=f['pocket']+f['rear_channel']
 breach=(cavities^inner_guard).volume()
 check(label+' keeps the bread-side skin covered',breach<1e-4,{'minimum_checked_inner_cover_mm':1.15,'nominal_inner_cover_mm':f['nominal_inner_cover_mm'],'breach_mm3':breach})
 check(label+' has no recessed channel around the male root',f['rear_channel'].is_empty(),{'removed_male_root_channel_mm3':f['rear_channel'].volume()})
 y=v.old.JOINT_Y+v.P['joint_lip_length']+.4
 end=f['pocket'].translate([0,1.2,0])^v.box(-100,y+.002,-100,100,y+1.2,100)
 missing=(end-parts[f['part']+'_B']).volume()
 check(label+' has a closed socket end',missing<1e-4,{'checked_end_wall_mm':1.2,'missing_end_wall_mm3':missing})
check('all internal ribs are disabled',v.P['ribs_enabled'] is False and report['rib_count']==0,{'rib_count':report['rib_count']})
current_core=v.base_geometry();current_core=current_core[0]+current_core[1]
try:
 v.P['ribs_enabled']=True;prior_core=v.base_geometry();prior_core=prior_core[0]+prior_core[1]
finally:v.P['ribs_enabled']=False
rib_changes=[]
for y in v.old.BULK_Y:
 clip=v.box(-99,y-12,-99,99,y+12,99);old_rib=prior_core^clip;new_rib=current_core^clip
 removed=(old_rib-new_rib).volume();added=(new_rib-old_rib).volume()
 check('rib at '+str(y)+' is completely omitted from the shell construction',removed>1000 and added<.01,{'removed_volume_mm3':removed,'added_boolean_residue_mm3':added,'residue_tolerance_mm3':.01})
 rib_changes.append({'y':y,'removed_volume_mm3':removed})
report['joint_validation']=join_certificates
report['rib_removal']={'rib_count':0,'previous_depth_mm':1.8,'stations':rib_changes,'removed_volume_mm3':sum(x['removed_volume_mm3'] for x in rib_changes)}
for yy in (v.old.JOINT_Y-v.old.JOINT_HL,v.old.JOINT_Y+v.old.JOINT_HL):
 area=0.
 for solid in parts.values():
  mesh=v.to_trimesh(solid);centers=mesh.triangles_center
  mask=(abs(centers[:,1]-yy)<.05)&(abs(mesh.face_normals[:,1])>.98)
  area+=float(mesh.area_faces[mask].sum())
 check('joint shoulder at Y '+str(yy)+' blends without a transverse ledge',area<.1,{'transverse_face_area_mm2':area,'blend_length_mm':v.P['joint_blend_length']})
check('hinge pin has a thicker 3 mm diameter',v.P['pin_radius']==1.5,{'pin_diameter_mm':2*v.P['pin_radius']})
check('outer hinge profile is retained',v.P['exterior_rim_axis_x']==-41 and v.P['exterior_rim_radius']==3.3,{'external_axis_x':v.P['exterior_rim_axis_x'],'external_radius_mm':v.P['exterior_rim_radius']})
check('latch thumb catch is taller and projects farther',v.P['thumb_lip_height']>=3 and v.P['thumb_lip']>=2,{'height_mm':v.P['thumb_lip_height'],'projection_mm':v.P['thumb_lip']})
check('geometry report matches the current generator',report['generator_sha256']==hashlib.sha256(Path(v.__file__).read_bytes()).hexdigest(),report['generator_sha256'])
report['validation']={'checks':checks,'passed':len(checks),'failed':0,'physical_print_tested':False,'continuous_sweep_proven':True,'rotation_clearance_certificate':certificate}
(v.ROOT/'output/review.json').write_text(json.dumps(report,indent=2))
print(f'{len(checks)} geometry checks passed; physical coupon testing remains required.')
