from pathlib import Path
import sys,json,hashlib,math
sys.path.insert(0,str(Path(__file__).resolve().parent))
import baguette_v3 as v
parts,prints,features,axis,D=v.build()
base=parts['base_A']+parts['base_B'];lid=parts['lid_A']+parts['lid_B'];all_shells=base+lid
report=json.loads((v.ROOT/'output/review.json').read_text())
checks=[]
def check(name,passed,detail):
 checks.append({'name':name,'passed':bool(passed),'detail':detail})
 if not passed:raise AssertionError(name+': '+str(detail))
for name,solid in parts.items():
 m=v.metrics(solid);check(name+' is one closed solid',m['components']==1 and m['watertight'] and m['consistent_winding'],m['components'])
for name,solid in prints.items():
 m=v.metrics(solid);expected=2 if name.startswith('segment') else 1
 check(name+' has the expected printable components',m['components']==expected and m['watertight'],m['components'])
 check(name+' fits a 300 x 320 x 325 mm envelope including 8 mm brim',all(a+pad<b for a,pad,b in zip(m['size_mm'],[16,16,0],[300,320,325])),m['size_mm'])
check('closed lid has no rigid interference',(base^lid).volume()<1e-4,(base^lid).volume())
free=v.released(lid,features,v.P['release_travel'])
# Finer than the development sweep, including both bonded moving lid keys.
free+=parts['sleeve_lid_1']+parts['sleeve_lid_2'];fixed=base+parts['sleeve_base']
worst=0.;angle_worst=0
for angle in range(0,v.P['max_open_angle']+1,1):
 vol=(fixed^v.open_lid(free,axis,angle)).volume()
 if vol>worst:worst=vol;angle_worst=angle
check('released hinge sweep clears 0 to 100 degrees with sleeves installed',worst<1e-4,{'maximum_overlap_mm3':worst,'angle':angle_worst,'step_degrees':1})
bore=v.old.capsule(31,600)
blocked=sum((solid^bore).volume() for solid in parts.values())
check('62 mm x 600 mm capsule clearance is retained',blocked<1e-4,blocked)
for name,solid in parts.items():
 if not name.startswith('sleeve'):continue
 gap=solid.min_gap(all_shells,.5)
 check(name+' fits its socket without interference',(solid^all_shells).volume()<1e-4 and gap>.24,{'minimum_gap_mm':gap})
# Compare with the unmodified outer shell, not the prior protruding barrels.
outer=v.base_geometry(True)[-1]
barrels=v.Manifold()
for cy in v.P['hinge_centers']:
 barrels+=v.y_cyl(v.P['hinge_radius'],cy-14-v.P['axial_clearance'],cy+14+v.P['axial_clearance'],axis,v.P['hinge_axis_z'])
check('both compact barrels are fully inside the original exterior',(barrels-outer).volume()<1e-5,(barrels-outer).volume())
hinge_side=(base+lid)^v.box(-150,-400,-100,-30,400,100)
residue=sum(abs(p.volume()) for p in (hinge_side-outer).decompose())
check('hinge side has no added exterior structure',residue<.05,{'absolute_boolean_residue_mm3':residue,'tolerance_mm3':.05})
for side in ('A','B'):
 b=parts['base_'+side];l=v.open_lid(parts['lid_'+side],axis,v.P['max_open_angle'])
 gap=b.min_gap(l,.5)
 check('segment '+side+' retains printable running clearance',gap>.24,{'minimum_gap_mm':gap})
check('exactly two latches, one per printed half',len(features)==2 and features[0]['y']<v.old.JOINT_Y<features[1]['y'],[f['y'] for f in features])
for f in features:
 y=f['y'];z=f['hook_shoulder_z'];label='latch at '+str(y)
 clip=v.box(30,y-12,-12,60,y+12,4)
 retained=((base^v.open_lid(lid,axis,.5))^clip).volume()
 check(label+' blocks opening without release',retained>4,{'rigid_interference_at_half_degree_mm3':retained})
 hook=lid^v.box(30,y-1,z-.2,60,y+1,z-.01)
 catch=base^v.box(30,y-1,z+.36,60,y+1,z+.55)
 overlap=catch.bounding_box()[3]-hook.bounding_box()[0]
 check(label+' has at least 1 mm of measured retaining overlap',overlap>1,{'local_overlap_x_mm':overlap})
 back=base^v.box(30,y-.1,-6.6,60,y+.1,-6.4)
 thickness=back.bounding_box()[3]-back.bounding_box()[0]
 check(label+' has a reinforced catch back wall',thickness>3.5,{'local_back_wall_x_mm':thickness})
 tongue_region=lid^v.box(25,y-12,-12,65,y+12,13)
 thumb_region=v.box(25,y-7.01,-10.01,65,y+7.01,-8.79)
 excess=(tongue_region-outer)-thumb_region
 residue=sum(abs(p.volume()) for p in excess.decompose())
 check(label+' follows the original outer surface except the thumb lip',residue<.01,{'exterior_residue_mm3':residue})
worst_release=max((base^v.released(lid,features,float(t))).volume() for t in v.np.linspace(0,v.P['release_travel'],22))
check('outward latch release clears the stationary closed base',worst_release<1e-4,{'maximum_overlap_mm3':worst_release,'sample_step_mm':.1})
# A distance bound covers the angles between samples, rather than assuming
# sampled non-intersection proves continuous motion. Rotation is rigid after
# the latches are released; the stationary base includes its installed sleeve.
step=.2
vertices=v.to_trimesh(free).vertices
radius=float(v.np.max(v.np.hypot(vertices[:,0]-axis,vertices[:,2]-v.P['hinge_axis_z'])))
gaps=[float(fixed.min_gap(v.open_lid(free,axis,float(a)),.5)) for a in v.np.linspace(0,v.P['max_open_angle'],501)]
bound=2*radius*math.sin(math.radians(step)/4)
numerical_allowance=.002
certificate={'sample_step_degrees':step,'sample_count':len(gaps),'minimum_sampled_gap_mm':min(gaps),'moving_radius_mm':radius,'between_sample_displacement_bound_mm':bound,'numerical_allowance_mm':numerical_allowance,'certified_minimum_gap_mm':min(gaps)-bound-numerical_allowance}
check('continuous released rotation clears the base and installed sleeves',certificate['certified_minimum_gap_mm']>0,certificate)

# Close only designed openings for this diagnostic: four bottom vents and
# submillimetre seams. An enclosed air component must surround the bread bore.
# This morphological operation is never exported as manufacturing geometry.
sealed=all_shells+parts['sleeve_base']+parts['sleeve_lid_1']+parts['sleeve_lid_2']
for y in (-200,-80,80,200):
 sealed+=outer^v.box(-4,y-16,-D-1,4,y+16,-D+6)
sealed=sealed.minkowski_sum(v.box(-.36,-.36,-.36,.36,.36,.36))
air=v.box(-100,-350,-100,100,350,100)-sealed
probe=v.box(-1,99,-1,1,101,1)
cavities=[c for c in air.decompose() if c.volume()>100 and c.bounding_box()[0]>-99 and (c^probe).volume()>7.9]
check('closed shell encloses the bread cavity after masking designed vents and seams',len(cavities)==1,{'enclosed_air_components':len(cavities),'analysis_seam_offset_mm':.36,'masked_vents':4,'cavity_volume_mm3':float(cavities[0].volume()) if cavities else 0})

# The bearing ring meets the rim directly, without an intermediate armature.
for cy in v.P['hinge_centers']:
 annulus=v.y_cyl(v.P['hinge_radius'],cy-8,cy+8,axis,v.P['hinge_axis_z'])-v.y_cyl(v.P['pin_radius']+v.P['radial_clearance'],cy-8,cy+8,axis,v.P['hinge_axis_z'])
 original_lid=v.base_geometry()[1]
 attachment=(annulus^original_lid).volume()
 check('hinge at '+str(cy)+' has direct bearing-to-shell attachment',attachment>10,{'bearing_shell_overlap_mm3':attachment,'nominal_bearing_wall_mm':v.P['hinge_radius']-v.P['pin_radius']-v.P['radial_clearance']})
check('geometry report matches the current generator',report['generator_sha256']==hashlib.sha256(Path(v.__file__).read_bytes()).hexdigest(),report['generator_sha256'])
report['validation']={'checks':checks,'passed':len(checks),'failed':0,'physical_print_tested':False,'continuous_sweep_proven':True,'rotation_clearance_certificate':certificate}
(v.ROOT/'output/review.json').write_text(json.dumps(report,indent=2))
print(f'{len(checks)} geometry checks passed; physical coupon testing remains required.')
