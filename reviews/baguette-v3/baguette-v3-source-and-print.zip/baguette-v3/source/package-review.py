"""Package only final print objects and review artifacts, never cached/debug output."""
from pathlib import Path
import hashlib,json,shutil,zipfile
ROOT=Path(__file__).resolve().parents[1]
out=ROOT/'output';pack=ROOT/'print-pack';pack.mkdir(exist_ok=True)
r=json.loads((out/'review.json').read_text())
files=[]
for name in r['printables']:
 for ext in ('stl','3mf'):files.append((out/f'baguette_v3_{name}.{ext}',Path('parts')/f'baguette_v3_{name}.{ext}'))
for name in json.loads((out/'coupons/coupons.json').read_text()):
 for ext in ('stl','3mf'):files.append((out/'coupons'/f'{name}.{ext}',Path('coupons')/f'{name}.{ext}'))
for name in ('review.json','wall-samples.json','slice-wall-review.json','design-review.json','slice-roof-review.json','all-parts-review.json','baguette_v3_all_parts.3mf','slice-latch-review.json'):files.append((out/name,Path(name)))
files.append((out/'coupons/coupons.json',Path('coupons/coupons.json')))
files.append((ROOT/'review/engineering-review.md',Path('engineering-review.md')))
for name in ('machine','process','filament'):files.append((out/'slicer'/f'{name}.json',Path('slicer-settings')/f'{name}.json'))
for src,dest in files:
 target=pack/dest;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,target)
readme='''# Baguette holder V3.15 — print prototype

Read engineering-review.md before printing. These files have passed geometry
checks and offline slicing, but have not been physically printed or validated.

1. Print hinge_gap_0p4. It reproduces the current internal hinge. The 0p3 and 0p5 coupons use circular test bores as tighter/looser alternatives.
2. Print latch_base and latch_lid; these reproduce the unloaded inward-set latch and beveled receiver. Test retention, release force and repeated flexing before the full case.
3. Print joint_A and joint_B. Test the integrated snaps before committing the full-size parts to permanent assembly.
4. Print strap_eye to check the rounded attachment and clip access. Load testing remains outstanding.
5. Print the two full main segments only after the coupons pass.

The combined baguette_v3_all_parts.3mf project contains three plates: Half A, Half B and eight test pieces, with the H2C/PLA settings embedded. It is unsliced. The two individual final print objects are also in parts/. Keep the supplied upright, open
orientation at 100 degrees; print each large segment separately. The default target is a
Bambu H2C, PLA, 0.4 mm nozzle, 0.20 mm layers, 4 walls, 15% infill and 8 mm brim.
The 3MF files contain oriented geometry, not prepared printer jobs or G-code.
The JSON settings record the offline slicing check and can require adaptation
to your installed Bambu Studio version. Inspect supports, especially at latch
undercuts, and exclude them from narrow working hinge bearings.

The center joint is integrated into the two main objects. Section A has
eight tongues within the shell edge; section B has matching covered blind sockets.
No loose connector or adhesive is required. The blind sockets have 45-degree ceilings above their tab tips for the connection-down print direction. The joint has no release feature:
separation after locking may damage it. Test the coupons first. Align both
base and lid joints at the same hinge angle before pressing the sections
straight together with even support. Inspect the hidden pockets and clear
support material through the joining-face slot openings before assembly. All six interior ribs are removed. Half A has solid snap roots; the joint blends into the inner shell. The revised hinge has a 3 mm pin and the exterior latches have rounded corners, blended underside finger catches and shallow fingernail recesses in the shell below. The raised outer band blends smoothly into the shell and latch face. Strap eyes have rounded edges and coved roots, and each projecting grip includes an underside fingernail inset. Mounting edges are rounded, and the latch side slots remain clear.

Review: https://parametric.space/reviews/baguette-v3/
The CAD/preview dimensions and STL units are millimetres. Do not scale coupons
independently. Model color does not select the printing filament.
'''
(pack/'README.md').write_text(readme)
active=[dest for _,dest in files]+[Path('README.md')]
manifest={str(p):hashlib.sha256((pack/p).read_bytes()).hexdigest() for p in active}
(pack/'sha256.json').write_text(json.dumps(manifest,indent=2));active.append(Path('sha256.json'))
public=ROOT/'review/baguette-v3-print-pack.zip'
with zipfile.ZipFile(public,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in active:z.write(pack/p,str(Path('baguette-v3-print-pack')/p))
source=ROOT.parent/'baguette-v3-source-and-print.zip'
sourcefiles=[p for p in (ROOT/'source').rglob('*') if p.is_file() and '__pycache__' not in p.parts]
sourcefiles += [ROOT/name for name in ('README.md','AGENTS.md','requirements.txt','package.json')]
sourcefiles += [pack/p for p in active]
sourcefiles += [ROOT/'review'/name for name in ('index.html','review.css','viewer.js','entry.js','review.js','inline-fragment.html','engineering-review.md','baguette-v3.glb','baguette-v3.glb.gz','closed.jpg','open.jpg','hinge.jpg','latch.jpg','catch.jpg','rear.jpg','hinge-mid.jpg','hinge-closed.jpg','hinge-section.jpg','joint.jpg','joint-section.jpg','slice-walls.jpg','latch-under.jpg','strap.jpg','strap-tail.jpg','slice-roofs.jpg','latch-bevel.jpg','slice-latches.jpg','baguette-v3-all-parts.3mf')]
with zipfile.ZipFile(source,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sourcefiles:z.write(p,str(Path('baguette-v3')/p.relative_to(ROOT)))
for path in (public,source):
 with zipfile.ZipFile(path) as z:assert z.testzip() is None
 print(path.name,path.stat().st_size,'bytes')

shutil.copy2(source,ROOT/'review'/source.name)
