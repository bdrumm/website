import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import * as T from 'three';
import {GLTFLoader} from 'three/addons/loaders/GLTFLoader.js';
const bytes=await readFile(new URL('../review/baguette-v3.glb',import.meta.url));
const {scene}=await new GLTFLoader().parseAsync(bytes.buffer.slice(bytes.byteOffset,bytes.byteOffset+bytes.byteLength),'');
const hinge=scene.getObjectByName('LidHinge');assert.ok(hinge);
const report=JSON.parse(await readFile(new URL('../output/review.json',import.meta.url),'utf8'));assert.equal(hinge.position.z,report.hinge_axis[0]);assert.equal(hinge.position.x,0);assert.equal(hinge.position.y,report.hinge_axis[2]);
assert.equal(scene.getObjectByName('BaguetteV3').userData.generatorSha256,report.generator_sha256);
const names=['base_A','base_B','lid_A','lid_B'];
for(const name of names){const mesh=scene.getObjectByName(name);assert.ok(mesh?.isMesh);if(name.startsWith('lid'))assert.equal(mesh.parent,hinge);}
for(const name of ['base_hinge_section','lid_hinge_section']){const mesh=scene.getObjectByName(name);assert.ok(mesh.userData.reviewSection);assert.equal(mesh.userData.manufacturingGeometry,false);assert.equal(mesh.parent.name,name.startsWith('lid')?'LidHinge':'BaguetteV3');}
for(const name of ['joint_section_A','joint_section_B']){const mesh=scene.getObjectByName(name);assert.equal(mesh.userData.sectionType,'joint');assert.equal(mesh.parent.name,'BaguetteV3');}
assert.equal(report.joint.length,8);assert.equal(report.rib_count,0);assert.ok(report.joint.every(f=>f.covered_socket&&f.outward_shift_mm===4.6));assert.equal(report.parts.sleeve_base,undefined);
const lid=scene.getObjectByName('lid_B');assert.equal(lid.morphTargetInfluences.length,1);
const rest=new T.Box3().setFromObject(scene);assert.ok(rest.getSize(new T.Vector3()).x>621);
const p=lid.geometry.attributes.position,target=lid.geometry.morphAttributes.position[0];let maxRelease=0;
for(let i=0;i<p.count;i++)maxRelease=Math.max(maxRelease,(target.getZ(i)-(lid.geometry.morphTargetsRelative?0:p.getZ(i)))*lid.scale.z);assert.ok(Math.abs(maxRelease-(report.release_travel_from_free_mm-report.latches[1].preload_travel_mm))<.01);assert.equal(report.latches.length,2);
// The restored diagonal U-slot rim belongs to the stationary lid shell.
// It must stay fixed while the adjacent spring tongue moves outward.
for(const name of ['lid_A','lid_B']){
 const mesh=scene.getObjectByName(name),f=report.latches.find(f=>(f.y>0?'lid_B':'lid_A')===name),pos=mesh.geometry.attributes.position,morph=mesh.geometry.morphAttributes.position[0];let fixedCount=0;
 for(let i=0;i<pos.count;i++){
  const yy=pos.getX(i)*mesh.scale.x,zz=pos.getY(i)*mesh.scale.y,xx=pos.getZ(i)*mesh.scale.z;
  if(yy>f.release_y_min&&yy<f.release_y_max&&zz>.5&&zz<6.5&&xx>35&&f.release_plane_normal[0]*xx+f.release_plane_normal[1]*yy+f.release_plane_normal[2]*zz<f.release_plane_constant-.3){
   const delta=(morph.getZ(i)-(mesh.geometry.morphTargetsRelative?0:pos.getZ(i)))*mesh.scale.z;
   assert.ok(Math.abs(delta)<.001,'Stationary slot rim must not flex');fixedCount++;
  }
 }
 assert.ok(fixedCount>10,'Stationary rim must be represented in the preview');
}
hinge.rotation.x=-T.MathUtils.degToRad(report.parameters.max_open_angle);scene.updateMatrixWorld(true);// Relative morph bounds are conservative; measure the actual resting vertices.
// Compare the exported parent transform with an independently calculated rotation.
const angle=T.MathUtils.degToRad(report.parameters.max_open_angle),c=Math.cos(angle),s=Math.sin(angle);
for(let i=0;i<p.count;i+=97){const world=new T.Vector3().fromBufferAttribute(p,i).applyMatrix4(lid.matrixWorld);const y=p.getY(i)*lid.scale.y-hinge.position.y,z=p.getZ(i)*lid.scale.z-hinge.position.z;assert.ok(Math.abs(world.y-(hinge.position.y+c*y+s*z))<1e-4);assert.ok(Math.abs(world.z-(hinge.position.z-s*y+c*z))<1e-4);}
hinge.rotation.x=0;scene.updateMatrixWorld(true);assert.ok(new T.Box3().setFromObject(scene).equals(rest));
const markup=await readFile(new URL('../review/index.html',import.meta.url),'utf8');for(const attr of ['data-model-stage','data-status','data-angle','data-angle-value','data-explode','data-cutaway'])assert.ok(markup.includes(attr));
console.log('Preview geometry, lid release morph, grouping, closure, and control targets verified.');
