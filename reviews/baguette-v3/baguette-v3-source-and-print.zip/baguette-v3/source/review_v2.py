import json, sys, hashlib
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent/'legacy'))
import baguette_case_v2 as old
old.set_circular_segments(64)
base,lid,lip,axis,D=old.build('final')
report={'source_sha256':hashlib.sha256(Path(old.__file__).read_bytes()).hexdigest(), 'hinge_axis_x':axis,'pin_diameter_mm':2*old.PIN_R,'hinge_radial_clearance_mm':old.PIN_HOLE_R-old.PIN_R,'hinge_relief_radius_mm':old.NOTCH_R,'joint_gap_mm':old.JOINT_GAP,'latch_thickness_mm':old.TAB_T,'latch_length_mm':16,'nominal_latch_beam_strain_estimate':1.5*old.TAB_T*1.15/16**2,'hinge_sweep':[],'parts':{}}
for angle in range(0,181,15):
 report['hinge_sweep'].append({'angle':angle,'overlap_mm3':(base^old.open_about(lid,axis,angle)).volume()})
for name,solid in [('base',base),('lid',lid),('lip',lip),('segment_A',old.segment_A(base,lid,lip,axis)),('segment_B',old.segment_B(base,lid,axis))]:
 mesh=old.to_trimesh(solid);pieces=solid.decompose();bb=solid.bounding_box()
 report['parts'][name]={'triangles':len(mesh.faces),'watertight':mesh.is_watertight,'volume_mm3':solid.volume(),'components':len(pieces),'component_volumes_mm3':[p.volume() for p in pieces], 'bounds_mm':list(bb),'size_mm':[bb[i+3]-bb[i] for i in range(3)]}
 mesh.export(Path(__file__).resolve().parents[1]/'output'/f'baseline-{name}.stl')
p=Path(__file__).resolve().parents[1]/'output'/'baseline-review.json';p.write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
