from pathlib import Path
import base64
from inline_codec import pack,unpack
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'review/inline-fragment.html').read_text()
js=(ROOT/'review/viewer.js').read_text().replace("from 'three'","from 'https://esm.sh/three@0.186.0'")
js=js.replace("from 'three/addons/", "from 'https://esm.sh/three@0.186.0/examples/jsm/")
js=js.replace('export async function','async function')
blob=(ROOT/'review/baguette-v3.glb').read_bytes();packed=pack(blob);assert unpack(packed)==blob
(ROOT/'output/inline-packed.gz').write_bytes(packed)
s=s.replace('/* VIEWER_MODULE */',js).replace('MODEL_GZIP_BASE64',base64.b64encode(packed).decode())
p=ROOT.parent/'baguette-v3-review.html';p.write_text(s);assert p.stat().st_size<1_000_000
print(p,p.stat().st_size)
