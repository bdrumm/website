# Baguette holder V3.11 — print prototype

Read engineering-review.md before printing. These files have passed geometry
checks and offline slicing, but have not been physically printed or validated.

1. Print hinge_gap_0p4. It reproduces the current internal hinge. The 0p3 and 0p5 coupons use circular test bores as tighter/looser alternatives.
2. Print the new latch_base and latch_lid; test retention, release force and repeated flexing before the full case.
3. Print joint_A and joint_B. Test the integrated snaps before committing the full-size parts to permanent assembly.
4. Print the two full main segments only after the coupons pass.

The two final print objects are in parts/. Keep the supplied upright, open
orientation at 100 degrees; print each large segment separately. The default target is a
Bambu H2C, PLA, 0.4 mm nozzle, 0.20 mm layers, 4 walls, 15% infill and 8 mm brim.
The 3MF files contain oriented geometry, not prepared printer jobs or G-code.
The JSON settings record the offline slicing check and can require adaptation
to your installed Bambu Studio version. Inspect supports, especially at latch
undercuts, and exclude them from narrow working hinge bearings.

The center joint is integrated into the two main objects. Section A has
eight tongues within the shell edge; section B has matching covered blind sockets.
No loose connector or adhesive is required. The joint has no release feature:
separation after locking may damage it. Test the coupons first. Align both
base and lid joints at the same hinge angle before pressing the sections
straight together with even support. Inspect the hidden pockets and clear
support material through the joining-face slot openings before assembly. All six interior ribs are removed. Half A has solid snap roots; the joint blends into the inner shell. The revised hinge has a 3 mm pin and the exterior latches have rounded corners, blended underside finger catches and shallow fingernail recesses in the shell below. Mounting edges are rounded, and the latch side slots clear the raised shell band without thin overhanging bridges.

Review: https://parametric.space/reviews/baguette-v3/
The CAD/preview dimensions and STL units are millimetres. Do not scale coupons
independently. Model color does not select the printing filament.
